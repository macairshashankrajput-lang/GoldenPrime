"""
Invoice Generator - Advanced Invoicing Utility
Template management and invoice generation
"""

from sqlalchemy.orm import Session
from database.new_models import InvoiceTemplate, EnhancedInvoice
from database.models import Supplier
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Optional, List, Dict


class InvoiceGenerator:
    """Advanced invoice generation and management"""

    @staticmethod
    def create_invoice_template(session: Session, template_name: str,
                                supplier_id: int, default_tax_rate: float = 0.0) -> Optional[InvoiceTemplate]:
        """Create invoice template"""

        try:
            template = InvoiceTemplate(
                template_name=template_name,
                supplier_id=supplier_id,
                default_tax_rate=default_tax_rate,
                created_date=datetime.utcnow()
            )
            session.add(template)
            session.commit()
            return template

        except Exception:
            session.rollback()
            return None

    @staticmethod
    def get_invoice_templates(session: Session, supplier_id: Optional[int] = None) -> List[InvoiceTemplate]:
        """Get invoice templates"""

        try:
            query = session.query(InvoiceTemplate)
            if supplier_id:
                query = query.filter(
                    InvoiceTemplate.supplier_id == supplier_id)
            return query.all()

        except Exception:
            return []

    @staticmethod
    def create_invoice(session: Session, supplier_id: int, amount: Decimal,
                       tax_rate: float = 0.0, description: str = "",
                       recurring_type: str = "ONCE",
                       recurring_interval: Optional[int] = None) -> Optional[EnhancedInvoice]:
        """Create new invoice"""

        try:
            supplier = session.query(Supplier).get(supplier_id)
            if not supplier:
                return None

            # Calculate totals
            subtotal = Decimal(str(amount))
            tax_amount = subtotal * Decimal(str(tax_rate / 100))
            total = subtotal + tax_amount

            # Calculate next due date
            next_due_date = InvoiceGenerator._calculate_due_date(
                recurring_type, recurring_interval)

            invoice = EnhancedInvoice(
                supplier_id=supplier_id,
                invoice_number=InvoiceGenerator._generate_invoice_number(
                    session),
                amount=subtotal,
                tax_rate=tax_rate,
                tax_amount=tax_amount,
                total_amount=total,
                currency="USD",
                invoice_date=datetime.utcnow(),
                due_date=next_due_date,
                status="DRAFT",
                description=description,
                recurring_type=recurring_type,
                recurring_interval=recurring_interval,
                created_date=datetime.utcnow()
            )
            session.add(invoice)
            session.commit()
            return invoice

        except Exception:
            session.rollback()
            return None

    @staticmethod
    def add_line_item(session: Session, invoice_id: int,
                      item_description: str, quantity: float,
                      unit_price: Decimal) -> bool:
        """Add line item to invoice"""

        try:
            invoice = session.query(EnhancedInvoice).get(invoice_id)
            if not invoice:
                return False

            line_total = Decimal(str(quantity * float(unit_price)))

            # Store as JSON in line_items field
            if not invoice.line_items:
                invoice.line_items = []

            item = {
                "description": item_description,
                "quantity": quantity,
                "unit_price": str(unit_price),
                "total": str(line_total)
            }

            if isinstance(invoice.line_items, str):
                import json
                items = json.loads(invoice.line_items)
                items.append(item)
                invoice.line_items = json.dumps(items)
            else:
                invoice.line_items.append(item)

            session.commit()
            return True

        except Exception:
            session.rollback()
            return False

    @staticmethod
    def calculate_invoice_totals(session: Session, invoice_id: int) -> Dict:
        """Calculate invoice totals"""

        try:
            invoice = session.query(EnhancedInvoice).get(invoice_id)
            if not invoice:
                return {}

            return {
                "subtotal": str(invoice.amount),
                "tax_rate": invoice.tax_rate,
                "tax_amount": str(invoice.tax_amount),
                "total": str(invoice.total_amount),
                "currency": invoice.currency
            }

        except Exception:
            return {}

    @staticmethod
    def update_invoice_status(session: Session, invoice_id: int,
                              status: str) -> bool:
        """Update invoice status"""

        try:
            invoice = session.query(EnhancedInvoice).get(invoice_id)
            if not invoice:
                return False

            invoice.status = status

            if status == "SENT":
                invoice.sent_date = datetime.utcnow()
            elif status == "PAID":
                invoice.paid_date = datetime.utcnow()

            session.commit()
            return True

        except Exception:
            session.rollback()
            return False

    @staticmethod
    def get_pending_invoices(session: Session) -> List[EnhancedInvoice]:
        """Get pending invoices"""

        try:
            invoices = session.query(EnhancedInvoice).filter(
                EnhancedInvoice.status.in_(["DRAFT", "SENT"])
            ).order_by(EnhancedInvoice.due_date).all()
            return invoices

        except Exception:
            return []

    @staticmethod
    def get_overdue_invoices(session: Session) -> List[EnhancedInvoice]:
        """Get overdue invoices"""

        try:
            now = datetime.utcnow()
            invoices = session.query(EnhancedInvoice).filter(
                EnhancedInvoice.status == "SENT",
                EnhancedInvoice.due_date < now
            ).all()
            return invoices

        except Exception:
            return []

    @staticmethod
    def setup_recurring_invoice(session: Session, invoice_id: int,
                                recurring_type: str,
                                recurring_interval: Optional[int] = None) -> bool:
        """Setup recurring invoice"""

        try:
            invoice = session.query(EnhancedInvoice).get(invoice_id)
            if not invoice:
                return False

            invoice.recurring_type = recurring_type
            invoice.recurring_interval = recurring_interval

            # Update next due date
            next_due = InvoiceGenerator._calculate_due_date(
                recurring_type, recurring_interval)
            invoice.due_date = next_due

            session.commit()
            return True

        except Exception:
            session.rollback()
            return False

    @staticmethod
    def generate_recurring_invoices(session: Session) -> List[EnhancedInvoice]:
        """Generate recurring invoices that are due"""

        try:
            recurring_invoices = session.query(EnhancedInvoice).filter(
                EnhancedInvoice.recurring_type != "ONCE",
                EnhancedInvoice.paid_date != None
            ).all()

            generated = []
            now = datetime.utcnow()

            for invoice in recurring_invoices:
                if invoice.due_date and invoice.due_date <= now:
                    # Create new invoice from recurring
                    new_invoice = InvoiceGenerator.create_invoice(
                        session,
                        invoice.supplier_id,
                        invoice.amount,
                        invoice.tax_rate,
                        invoice.description,
                        invoice.recurring_type,
                        invoice.recurring_interval
                    )
                    if new_invoice:
                        generated.append(new_invoice)

            return generated

        except Exception:
            return []

    @staticmethod
    def get_invoice_summary(session: Session) -> Dict:
        """Get invoice summary statistics"""

        try:
            all_invoices = session.query(EnhancedInvoice).all()
            draft = len([i for i in all_invoices if i.status == "DRAFT"])
            sent = len([i for i in all_invoices if i.status == "SENT"])
            paid = len([i for i in all_invoices if i.status == "PAID"])

            total_amount = sum(Decimal(str(i.total_amount))
                               for i in all_invoices)
            paid_amount = sum(Decimal(str(i.total_amount))
                              for i in all_invoices if i.status == "PAID")
            pending_amount = sum(Decimal(str(i.total_amount))
                                 for i in all_invoices if i.status in ["DRAFT", "SENT"])

            return {
                "total_invoices": len(all_invoices),
                "draft": draft,
                "sent": sent,
                "paid": paid,
                "total_amount": str(total_amount),
                "paid_amount": str(paid_amount),
                "pending_amount": str(pending_amount)
            }

        except Exception:
            return {}

    @staticmethod
    def _calculate_due_date(recurring_type: str, interval: Optional[int] = None) -> datetime:
        """Calculate due date based on recurrence"""

        now = datetime.utcnow()

        if recurring_type == "ONCE":
            return now + timedelta(days=30)
        elif recurring_type == "MONTHLY":
            return now + timedelta(days=30)
        elif recurring_type == "QUARTERLY":
            return now + timedelta(days=90)
        elif recurring_type == "ANNUAL":
            return now + timedelta(days=365)
        elif recurring_type == "CUSTOM" and interval:
            return now + timedelta(days=interval)
        else:
            return now + timedelta(days=30)

    @staticmethod
    def _generate_invoice_number(session: Session) -> str:
        """Generate unique invoice number"""

        try:
            last_invoice = session.query(EnhancedInvoice).order_by(
                EnhancedInvoice.id.desc()
            ).first()

            if last_invoice and last_invoice.invoice_number:
                # Extract number and increment
                try:
                    num = int(last_invoice.invoice_number.replace("INV-", ""))
                    return f"INV-{num + 1:06d}"
                except:
                    pass

            return "INV-000001"

        except Exception:
            return "INV-000001"
