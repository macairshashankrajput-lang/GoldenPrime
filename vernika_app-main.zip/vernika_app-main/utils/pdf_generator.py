"""
PDF Generator - Invoice and Document PDF Creation
Generate PDF invoices, salary slips, and other documents locally
"""

from datetime import datetime, date
from decimal import Decimal
from sqlalchemy.orm import Session
from database.new_models import EnhancedInvoice, SalarySlip
from database.models import Employee, Supplier
from typing import Dict, List
import os


class PDFGenerator:
    """Generate PDF documents locally"""

    # PDF generation would use reportlab or similar in production
    # This is a mock implementation

    @staticmethod
    def generate_invoice_pdf(
        session: Session,
        invoice_id: int,
        output_path: str = None
    ) -> str:
        """Generate invoice PDF"""

        invoice = session.query(EnhancedInvoice).get(invoice_id)
        if not invoice:
            return None

        # In production, use reportlab/weasyprint to generate PDF
        # This is a placeholder implementation

        if output_path is None:
            output_path = f"/tmp/invoice_{invoice_id}.pdf"

        pdf_content = PDFGenerator._create_invoice_html(session, invoice)

        # Write to file (in production, convert HTML to PDF)
        with open(output_path, 'w') as f:
            f.write(f"<!-- Generated PDF Invoice {invoice_id} -->\n")
            f.write(pdf_content)

        return output_path

    @staticmethod
    def _create_invoice_html(session: Session, invoice: EnhancedInvoice) -> str:
        """Create HTML representation of invoice"""

        supplier = session.query(Supplier).get(invoice.supplier_id)

        html = f"""
        <html>
        <head>
            <title>Invoice {invoice.invoice_number}</title>
        </head>
        <body>
            <h1>INVOICE</h1>
            <p><strong>Invoice Number:</strong> {invoice.invoice_number}</p>
            <p><strong>Date:</strong> {invoice.invoice_date}</p>
            <p><strong>Due Date:</strong> {invoice.due_date}</p>
            
            <h2>Supplier Details</h2>
            <p><strong>Name:</strong> {supplier.company_name if supplier else 'N/A'}</p>
            
            <h2>Invoice Details</h2>
            <table border="1">
                <tr>
                    <th>Description</th>
                    <th>Amount</th>
                    <th>Status</th>
                </tr>
                <tr>
                    <td>{invoice.description}</td>
                    <td>${invoice.total_amount}</td>
                    <td>{invoice.status.value if invoice.status else 'Pending'}</td>
                </tr>
            </table>
            
            <h2>Summary</h2>
            <p><strong>Subtotal:</strong> ${invoice.subtotal}</p>
            <p><strong>Tax ({invoice.tax_percentage}%):</strong> ${invoice.tax_amount}</p>
            <p><strong>Total:</strong> ${invoice.total_amount}</p>
        </body>
        </html>
        """

        return html

    @staticmethod
    def generate_salary_slip_pdf(
        session: Session,
        slip_id: int,
        output_path: str = None
    ) -> str:
        """Generate salary slip PDF"""

        slip = session.query(SalarySlip).get(slip_id)
        if not slip:
            return None

        employee = session.query(Employee).get(slip.employee_id)

        if output_path is None:
            output_path = f"/tmp/salary_slip_{slip_id}.pdf"

        html = PDFGenerator._create_salary_slip_html(employee, slip)

        # Write to file
        with open(output_path, 'w') as f:
            f.write(f"<!-- Generated PDF Salary Slip {slip_id} -->\n")
            f.write(html)

        return output_path

    @staticmethod
    def _create_salary_slip_html(employee: Employee, slip: SalarySlip) -> str:
        """Create HTML representation of salary slip"""

        html = f"""
        <html>
        <head>
            <title>Salary Slip - {slip.fiscal_month}/{slip.fiscal_year}</title>
        </head>
        <body>
            <h1>SALARY SLIP</h1>
            
            <h2>Employee Details</h2>
            <p><strong>Name:</strong> {employee.first_name} {employee.last_name}</p>
            <p><strong>Employee ID:</strong> {employee.id}</p>
            <p><strong>Department:</strong> {employee.department.name if employee.department else 'N/A'}</p>
            <p><strong>Position:</strong> {employee.position}</p>
            
            <h2>Period</h2>
            <p>Month: {slip.fiscal_month} | Year: {slip.fiscal_year}</p>
            
            <h2>Earnings</h2>
            <table border="1">
                <tr>
                    <td><strong>Base Salary</strong></td>
                    <td>${slip.base_salary}</td>
                </tr>
                <tr>
                    <td><strong>Allowances</strong></td>
                    <td>${slip.allowances}</td>
                </tr>
                <tr>
                    <td><strong>Gross Salary</strong></td>
                    <td><strong>${slip.gross_salary}</strong></td>
                </tr>
            </table>
            
            <h2>Deductions</h2>
            <table border="1">
                <tr>
                    <td><strong>Provident Fund</strong></td>
                    <td>${slip.provident_fund}</td>
                </tr>
                <tr>
                    <td><strong>Health Insurance</strong></td>
                    <td>${slip.health_insurance}</td>
                </tr>
                <tr>
                    <td><strong>Tax Deduction</strong></td>
                    <td>${slip.tax_deduction}</td>
                </tr>
                <tr>
                    <td><strong>Total Deductions</strong></td>
                    <td><strong>${slip.total_deductions}</strong></td>
                </tr>
            </table>
            
            <h2>Summary</h2>
            <p><strong>Gross Salary:</strong> ${slip.gross_salary}</p>
            <p><strong>Total Deductions:</strong> ${slip.total_deductions}</p>
            <p><strong>Net Salary:</strong> ${slip.net_salary}</p>
            <p><strong>Currency:</strong> {slip.currency}</p>
        </body>
        </html>
        """

        return html

    @staticmethod
    def generate_batch_payroll_pdf(
        session: Session,
        fiscal_month: int,
        fiscal_year: int,
        department_id: int = None,
        output_dir: str = "/tmp/payroll"
    ) -> List[str]:
        """Generate payroll PDFs for multiple employees"""

        # Create output directory
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

        # Get salary slips
        query = session.query(SalarySlip).filter(
            SalarySlip.fiscal_month == fiscal_month,
            SalarySlip.fiscal_year == fiscal_year
        )

        if department_id:
            from database.models import Employee as Emp
            employee_ids = [
                e.id for e in session.query(Emp).filter(
                    Emp.department_id == department_id
                ).all()
            ]
            query = query.filter(SalarySlip.employee_id.in_(employee_ids))

        slips = query.all()

        output_paths = []
        for slip in slips:
            output_path = os.path.join(
                output_dir,
                f"salary_slip_{slip.employee_id}_{fiscal_month}_{fiscal_year}.html"
            )

            path = PDFGenerator.generate_salary_slip_pdf(
                session, slip.id, output_path)
            output_paths.append(path)

        return output_paths

    @staticmethod
    def generate_document(
        document_type: str,
        content: Dict,
        output_path: str
    ) -> str:
        """Generate generic document"""

        html = PDFGenerator._create_generic_html(document_type, content)

        with open(output_path, 'w') as f:
            f.write(html)

        return output_path

    @staticmethod
    def _create_generic_html(doc_type: str, content: Dict) -> str:
        """Create generic HTML document"""

        title = content.get("title", doc_type.replace("_", " ").title())

        html = f"""
        <html>
        <head>
            <title>{title}</title>
            <style>
                body {{ font-family: Arial, sans-serif; }}
                .header {{ text-align: center; border-bottom: 2px solid black; }}
                .section {{ margin: 20px 0; }}
                table {{ border-collapse: collapse; width: 100%; }}
                th, td {{ border: 1px solid gray; padding: 8px; text-align: left; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>{title}</h1>
            </div>
            
            <div class="section">
                {PDFGenerator._render_content(content)}
            </div>
        </body>
        </html>
        """

        return html

    @staticmethod
    def _render_content(content: Dict) -> str:
        """Render content dictionary as HTML"""

        html = ""

        for key, value in content.items():
            if key == "title":
                continue

            if isinstance(value, dict):
                html += f"<h2>{key.replace('_', ' ').title()}</h2>"
                for k, v in value.items():
                    html += f"<p><strong>{k}:</strong> {v}</p>"

            elif isinstance(value, list):
                html += f"<h2>{key.replace('_', ' ').title()}</h2>"
                html += "<ul>"
                for item in value:
                    html += f"<li>{item}</li>"
                html += "</ul>"

            else:
                html += f"<p><strong>{key}:</strong> {value}</p>"

        return html
