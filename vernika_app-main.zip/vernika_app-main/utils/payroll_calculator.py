"""
Payroll Calculator - Salary and Tax Calculations
Multi-currency support with configurable tax and deductions
"""

from decimal import Decimal
from datetime import datetime, date
from sqlalchemy.orm import Session
from database.new_models import (
    PayrollConfig, SalarySlip, AUXLog, AUXStatus
)
from database.models import Employee
from typing import Dict, Tuple


class PayrollCalculator:
    """Calculate salaries, taxes, and deductions"""

    @staticmethod
    def get_or_create_config(session: Session) -> PayrollConfig:
        """Get payroll config or create default"""

        config = session.query(PayrollConfig).first()

        if not config:
            config = PayrollConfig(
                base_currency="USD",
                exchange_rates={},
                tax_rate=0.0,
                tax_type="Income Tax",
                provident_fund_rate=0.12,
                health_insurance_rate=0.05,
                payroll_period="monthly",
                payroll_day=1
            )
            session.add(config)
            session.commit()

        return config

    @staticmethod
    def set_exchange_rate(
        session: Session,
        from_currency: str,
        to_currency: str,
        rate: float
    ):
        """Set exchange rate"""

        config = PayrollCalculator.get_or_create_config(session)
        if not config.exchange_rates:
            config.exchange_rates = {}

        key = f"{from_currency}_{to_currency}"
        config.exchange_rates[key] = rate
        session.commit()

    @staticmethod
    def convert_currency(
        session: Session,
        amount: Decimal,
        from_currency: str,
        to_currency: str
    ) -> Decimal:
        """Convert amount between currencies"""

        if from_currency == to_currency:
            return amount

        config = PayrollCalculator.get_or_create_config(session)
        key = f"{from_currency}_{to_currency}"

        rate = config.exchange_rates.get(key, 1.0)
        return amount * Decimal(str(rate))

    @staticmethod
    def calculate_gross_salary(
        base_salary: Decimal,
        allowances: Decimal = Decimal('0')
    ) -> Decimal:
        """Calculate gross salary"""
        return base_salary + allowances

    @staticmethod
    def calculate_provident_fund(
        session: Session,
        gross_salary: Decimal
    ) -> Decimal:
        """Calculate provident fund deduction"""

        config = PayrollCalculator.get_or_create_config(session)
        rate = Decimal(str(config.provident_fund_rate))
        return gross_salary * (rate / 100)

    @staticmethod
    def calculate_health_insurance(
        session: Session,
        gross_salary: Decimal
    ) -> Decimal:
        """Calculate health insurance deduction"""

        config = PayrollCalculator.get_or_create_config(session)
        rate = Decimal(str(config.health_insurance_rate))
        return gross_salary * (rate / 100)

    @staticmethod
    def calculate_tax(
        session: Session,
        taxable_income: Decimal
    ) -> Decimal:
        """Calculate income tax"""

        config = PayrollCalculator.get_or_create_config(session)
        tax_rate = Decimal(str(config.tax_rate))

        return taxable_income * (tax_rate / 100)

    @staticmethod
    def calculate_net_salary(
        session: Session,
        gross_salary: Decimal,
        provident_fund: Decimal = None,
        health_insurance: Decimal = None,
        tax_deduction: Decimal = None
    ) -> Tuple[Decimal, Decimal]:
        """Calculate net salary and total deductions"""

        if provident_fund is None:
            provident_fund = PayrollCalculator.calculate_provident_fund(
                session, gross_salary
            )

        if health_insurance is None:
            health_insurance = PayrollCalculator.calculate_health_insurance(
                session, gross_salary
            )

        # Taxable income is gross minus provident fund
        taxable_income = gross_salary - provident_fund

        if tax_deduction is None:
            tax_deduction = PayrollCalculator.calculate_tax(
                session, taxable_income)

        total_deductions = provident_fund + health_insurance + tax_deduction
        net_salary = gross_salary - total_deductions

        return net_salary, total_deductions

    @staticmethod
    def generate_salary_slip(
        session: Session,
        employee_id: int,
        fiscal_month: int,
        fiscal_year: int
    ) -> SalarySlip:
        """Generate salary slip for employee"""

        # Get employee
        employee = session.query(Employee).get(employee_id)
        if not employee:
            return None

        # Check if slip already exists
        existing = session.query(SalarySlip).filter(
            SalarySlip.employee_id == employee_id,
            SalarySlip.fiscal_month == fiscal_month,
            SalarySlip.fiscal_year == fiscal_year
        ).first()

        if existing:
            return existing

        config = PayrollCalculator.get_or_create_config(session)

        base_salary = Decimal(str(employee.salary or 0))
        allowances = Decimal('0')

        gross = PayrollCalculator.calculate_gross_salary(
            base_salary, allowances)
        pf = PayrollCalculator.calculate_provident_fund(session, gross)
        hi = PayrollCalculator.calculate_health_insurance(session, gross)
        tax = PayrollCalculator.calculate_tax(session, gross - pf)

        net, total_ded = PayrollCalculator.calculate_net_salary(
            session, gross, pf, hi, tax
        )

        slip = SalarySlip(
            employee_id=employee_id,
            fiscal_month=fiscal_month,
            fiscal_year=fiscal_year,
            base_salary=base_salary,
            allowances=allowances,
            gross_salary=gross,
            provident_fund=pf,
            health_insurance=hi,
            tax_deduction=tax,
            total_deductions=total_ded,
            net_salary=net,
            currency=config.base_currency
        )

        session.add(slip)
        session.commit()

        return slip

    @staticmethod
    def get_salary_slip(
        session: Session,
        employee_id: int,
        fiscal_month: int,
        fiscal_year: int
    ) -> SalarySlip:
        """Get or generate salary slip"""

        return session.query(SalarySlip).filter(
            SalarySlip.employee_id == employee_id,
            SalarySlip.fiscal_month == fiscal_month,
            SalarySlip.fiscal_year == fiscal_year
        ).first()

    @staticmethod
    def get_salary_slip_summary(slip: SalarySlip) -> Dict:
        """Get salary slip summary"""

        return {
            "employee_id": slip.employee_id,
            "month": slip.fiscal_month,
            "year": slip.fiscal_year,
            "gross_salary": float(slip.gross_salary),
            "deductions": {
                "provident_fund": float(slip.provident_fund),
                "health_insurance": float(slip.health_insurance),
                "tax": float(slip.tax_deduction),
                "total": float(slip.total_deductions)
            },
            "net_salary": float(slip.net_salary),
            "currency": slip.currency,
            "generated_date": slip.generated_date.isoformat()
        }

    @staticmethod
    def update_tax_configuration(
        session: Session,
        tax_rate: float,
        tax_type: str
    ):
        """Update tax configuration"""

        config = PayrollCalculator.get_or_create_config(session)
        config.tax_rate = tax_rate
        config.tax_type = tax_type
        session.commit()

    @staticmethod
    def update_deduction_rates(
        session: Session,
        provident_fund_rate: float,
        health_insurance_rate: float
    ):
        """Update deduction rates"""

        config = PayrollCalculator.get_or_create_config(session)
        config.provident_fund_rate = provident_fund_rate
        config.health_insurance_rate = health_insurance_rate
        session.commit()

    @staticmethod
    def get_payroll_summary(
        session: Session,
        fiscal_month: int,
        fiscal_year: int,
        department_id: int = None
    ) -> Dict:
        """Get payroll summary for month"""

        query = session.query(SalarySlip).filter(
            SalarySlip.fiscal_month == fiscal_month,
            SalarySlip.fiscal_year == fiscal_year
        )

        if department_id:
            from database.models import Employee as Emp
            employee_ids = [
                e.id for e in session.query(Emp).filter(
                    Emp.department_id == department_id
                ).all()
            ]
            query = query.filter(SalarySlip.employee_id.in_(employee_ids))

        slips = query.all()

        total_gross = sum(s.gross_salary for s in slips)
        total_net = sum(s.net_salary for s in slips)
        total_pf = sum(s.provident_fund for s in slips)
        total_hi = sum(s.health_insurance for s in slips)
        total_tax = sum(s.tax_deduction for s in slips)

        return {
            "fiscal_month": fiscal_month,
            "fiscal_year": fiscal_year,
            "employee_count": len(slips),
            "total_gross_salary": float(total_gross),
            "total_deductions": float(total_pf + total_hi + total_tax),
            "total_net_salary": float(total_net),
            "breakdown": {
                "provident_fund": float(total_pf),
                "health_insurance": float(total_hi),
                "tax": float(total_tax)
            }
        }
