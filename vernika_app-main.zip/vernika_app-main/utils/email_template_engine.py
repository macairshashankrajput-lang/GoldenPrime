"""
Email Template Engine - Template Management and Rendering
Create, manage, and send templated emails with variable substitution
"""

from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from database.new_models import EmailTemplate, ScheduledEmail
from database.models import Employee
from typing import Dict, List
import re


class EmailTemplateEngine:
    """Manage and render email templates"""

    # Template variable patterns
    VARIABLE_PATTERN = r'\{\{\s*(\w+(?:\.\w+)*)\s*\}\}'

    @staticmethod
    def create_template(
        session: Session,
        name: str,
        category: str,
        subject: str,
        body: str,
        description: str = None,
        variables: List[str] = None
    ) -> EmailTemplate:
        """Create email template"""

        # Extract variables from body and subject
        if variables is None:
            variables = EmailTemplateEngine._extract_variables(
                subject + " " + body)

        template = EmailTemplate(
            name=name,
            category=category,
            subject=subject,
            body=body,
            description=description,
            template_variables=variables
        )

        session.add(template)
        session.commit()

        return template

    @staticmethod
    def get_template(session: Session, template_id: int) -> EmailTemplate:
        """Get template by ID"""
        return session.query(EmailTemplate).get(template_id)

    @staticmethod
    def get_templates_by_category(session: Session, category: str) -> List[EmailTemplate]:
        """Get all templates in category"""
        return session.query(EmailTemplate).filter(
            EmailTemplate.category == category,
            EmailTemplate.is_active == True
        ).all()

    @staticmethod
    def _extract_variables(text: str) -> List[str]:
        """Extract variable names from template text"""
        matches = re.findall(EmailTemplateEngine.VARIABLE_PATTERN, text)
        # Return unique variables
        return list(set(matches))

    @staticmethod
    def render_template(
        template: EmailTemplate,
        context: Dict[str, any]
    ) -> tuple:
        """Render template with context variables"""

        rendered_subject = EmailTemplateEngine._render_text(
            template.subject,
            context
        )

        rendered_body = EmailTemplateEngine._render_text(
            template.body,
            context
        )

        return rendered_subject, rendered_body

    @staticmethod
    def _render_text(text: str, context: Dict) -> str:
        """Replace template variables with context values"""

        def replace_var(match):
            var_path = match.group(1)

            # Support nested variables like user.name
            parts = var_path.split('.')
            value = context

            for part in parts:
                if isinstance(value, dict):
                    value = value.get(part, '')
                else:
                    try:
                        value = getattr(value, part, '')
                    except:
                        value = ''

            return str(value) if value else ''

        return re.sub(EmailTemplateEngine.VARIABLE_PATTERN, replace_var, text)

    @staticmethod
    def schedule_email(
        session: Session,
        template_id: int,
        recipient_ids: List[int],
        context_data: Dict,
        scheduled_time: datetime = None,
        is_recurring: bool = False,
        recurrence_pattern: str = None
    ) -> ScheduledEmail:
        """Schedule email for sending"""

        template = EmailTemplateEngine.get_template(session, template_id)
        if not template:
            return None

        # Render template
        subject, body = EmailTemplateEngine.render_template(
            template, context_data)

        scheduled = ScheduledEmail(
            template_id=template_id,
            recipient_ids=recipient_ids,
            subject=subject,
            body=body,
            scheduled_time=scheduled_time or datetime.utcnow(),
            is_recurring=is_recurring,
            recurrence_pattern=recurrence_pattern
        )

        session.add(scheduled)
        session.commit()

        return scheduled

    @staticmethod
    def get_pending_emails(session: Session, limit: int = 100) -> List[ScheduledEmail]:
        """Get emails scheduled for sending"""

        now = datetime.utcnow()

        return session.query(ScheduledEmail).filter(
            ScheduledEmail.scheduled_time <= now,
            ScheduledEmail.sent_at == None
        ).limit(limit).all()

    @staticmethod
    def mark_as_sent(session: Session, email_id: int) -> ScheduledEmail:
        """Mark email as sent"""

        email = session.query(ScheduledEmail).get(email_id)
        if email:
            email.sent_at = datetime.utcnow()
            email.open_count = 0
            email.click_count = 0
            session.commit()

        return email

    @staticmethod
    def mark_as_read(session: Session, email_id: int) -> ScheduledEmail:
        """Record email open"""

        email = session.query(ScheduledEmail).get(email_id)
        if email:
            if email.open_count is None:
                email.open_count = 0
            email.open_count += 1
            email.last_opened_at = datetime.utcnow()
            session.commit()

        return email

    @staticmethod
    def mark_link_clicked(session: Session, email_id: int) -> ScheduledEmail:
        """Record link click in email"""

        email = session.query(ScheduledEmail).get(email_id)
        if email:
            if email.click_count is None:
                email.click_count = 0
            email.click_count += 1
            session.commit()

        return email

    @staticmethod
    def get_email_metrics(email_id: int, total_recipients: int = None) -> Dict:
        """Get email engagement metrics"""

        return {
            "open_rate": "0%",  # Placeholder
            "click_rate": "0%",  # Placeholder
            "read_count": 0,  # Would read from DB
            "unread_count": 0  # Would read from DB
        }

    @staticmethod
    def create_default_templates(session: Session):
        """Create default email templates"""

        defaults = [
            {
                "name": "Welcome Email",
                "category": "Onboarding",
                "subject": "Welcome to {{company_name}}, {{user.first_name}}!",
                "body": """Dear {{user.first_name}} {{user.last_name}},

Welcome to {{company_name}}! We're excited to have you on board.

Your onboarding starts on {{start_date}}.

Department: {{department_name}}
Manager: {{manager_name}}

If you have any questions, please reach out to {{hr_contact}}.

Best regards,
HR Team"""
            },
            {
                "name": "Leave Approval Notification",
                "category": "Notifications",
                "subject": "Leave Request Approved",
                "body": """Hi {{user.first_name}},

Your leave request has been approved.

Leave Type: {{leave_type}}
From: {{start_date}}
To: {{end_date}}
Days: {{total_days}}

Approved By: {{approver_name}}

Have a great leave!

Regards,
HR System"""
            },
            {
                "name": "Expense Report Status",
                "category": "Finance",
                "subject": "Your Expense Report - {{status}}",
                "body": """Hi {{user.first_name}},

Your expense report has been {{status}}.

Amount: {{amount}} {{currency}}
Category: {{category}}
Date: {{submission_date}}

{{status_details}}

Regards,
Finance Team"""
            },
            {
                "name": "Performance Review Reminder",
                "category": "HR",
                "subject": "Performance Review Scheduled",
                "body": """Hi {{user.first_name}},

Your performance review is scheduled for {{review_date}} at {{review_time}}.

Reviewer: {{reviewer_name}}
Location: {{meeting_location}}

Please prepare your self-assessment before the review.

Regards,
HR Team"""
            },
            {
                "name": "Team Meeting Invitation",
                "category": "Meetings",
                "subject": "Team Meeting: {{meeting_title}}",
                "body": """Hi {{user.first_name}},

You're invited to our team meeting.

Title: {{meeting_title}}
Date: {{meeting_date}}
Time: {{meeting_time}}
Location: {{meeting_location}}
Duration: {{meeting_duration}} minutes

Agenda:
{{agenda}}

Looking forward to seeing you there!

Regards,
{{organizer_name}}"""
            }
        ]

        for template_data in defaults:
            existing = session.query(EmailTemplate).filter(
                EmailTemplate.name == template_data["name"]
            ).first()

            if not existing:
                template = EmailTemplateEngine.create_template(
                    session,
                    name=template_data["name"],
                    category=template_data["category"],
                    subject=template_data["subject"],
                    body=template_data["body"]
                )
