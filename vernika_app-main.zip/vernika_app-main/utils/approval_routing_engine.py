"""
Expense Approval Routing Engine
Multi-tier approval workflow with dynamic routing
"""

from datetime import datetime
from decimal import Decimal
from sqlalchemy.orm import Session
from database.new_models import (
    EnhancedExpense,
    ExpenseApprovalStatus,
    ExpenseApprovalConfig
)
from database.models import Employee
from typing import Tuple, List


class ApprovalRoutingEngine:
    """Route expenses through approval workflow"""

    @staticmethod
    def configure_approval_routing(
        session: Session,
        department_id: int,
        tier1_amount_limit: Decimal,
        tier1_approver_id: int,
        tier2_amount_limit: Decimal = None,
        tier2_approver_id: int = None,
        monthly_budget: Decimal = None
    ) -> ExpenseApprovalConfig:
        """Configure approval routing for department"""

        # Remove existing config
        session.query(ExpenseApprovalConfig).filter(
            ExpenseApprovalConfig.department_id == department_id
        ).delete()

        config = ExpenseApprovalConfig(
            department_id=department_id,
            tier1_amount_limit=tier1_amount_limit,
            tier1_approver_id=tier1_approver_id,
            tier2_amount_limit=tier2_amount_limit,
            tier2_approver_id=tier2_approver_id,
            monthly_budget=monthly_budget,
            budget_fiscal_year=datetime.utcnow().year
        )

        session.add(config)
        session.commit()

        return config

    @staticmethod
    def submit_expense(
        session: Session,
        employee_id: int,
        amount: Decimal,
        category: str,
        cost_center: str,
        description: str,
        receipt_path: str = None
    ) -> EnhancedExpense:
        """Submit expense for approval"""

        expense = EnhancedExpense(
            employee_id=employee_id,
            amount=amount,
            category=category,
            cost_center=cost_center,
            description=description,
            receipt_path=receipt_path,
            status=ExpenseApprovalStatus.SUBMITTED
        )

        session.add(expense)
        session.flush()  # Get the ID

        # Route to appropriate approver
        ApprovalRoutingEngine._route_to_approver(session, expense)

        session.commit()

        return expense

    @staticmethod
    def _route_to_approver(session: Session, expense: EnhancedExpense):
        """Determine approval routing based on amount"""

        employee = session.query(Employee).get(expense.employee_id)
        if not employee or not employee.department_id:
            return

        config = session.query(ExpenseApprovalConfig).filter(
            ExpenseApprovalConfig.department_id == employee.department_id
        ).first()

        if not config:
            # No routing configured, mark as approved
            expense.status = ExpenseApprovalStatus.APPROVED
            return

        # Route based on amount
        if expense.amount <= config.tier1_amount_limit:
            # Tier 1 approval only
            expense.status = ExpenseApprovalStatus.TIER1_PENDING
            expense.tier1_approver_id = config.tier1_approver_id

        elif config.tier2_amount_limit and expense.amount <= config.tier2_amount_limit:
            # Tier 1 then Tier 2
            expense.status = ExpenseApprovalStatus.TIER1_PENDING
            expense.tier1_approver_id = config.tier1_approver_id

        else:
            # Tier 2 only
            expense.status = ExpenseApprovalStatus.TIER2_PENDING
            expense.tier2_approver_id = config.tier2_approver_id

    @staticmethod
    def approve_tier1(
        session: Session,
        expense_id: int,
        approver_id: int,
        notes: str = None
    ) -> EnhancedExpense:
        """Approve at tier 1"""

        expense = session.query(EnhancedExpense).get(expense_id)
        if not expense:
            return None

        expense.tier1_approver_id = approver_id
        expense.tier1_approved_date = datetime.utcnow()
        expense.tier1_notes = notes

        # Check if needs tier 2
        config = ApprovalRoutingEngine._get_config_for_expense(
            session, expense)

        if config and config.tier2_amount_limit and expense.amount > config.tier1_amount_limit:
            # Move to tier 2
            expense.status = ExpenseApprovalStatus.TIER2_PENDING
            expense.tier2_approver_id = config.tier2_approver_id
        else:
            # All approvals done
            expense.status = ExpenseApprovalStatus.APPROVED

        session.commit()
        return expense

    @staticmethod
    def reject_tier1(
        session: Session,
        expense_id: int,
        approver_id: int,
        reason: str
    ) -> EnhancedExpense:
        """Reject at tier 1"""

        expense = session.query(EnhancedExpense).get(expense_id)
        if not expense:
            return None

        expense.status = ExpenseApprovalStatus.TIER1_REJECTED
        expense.tier1_approver_id = approver_id
        expense.tier1_approved_date = datetime.utcnow()
        expense.tier1_notes = f"REJECTED: {reason}"

        session.commit()
        return expense

    @staticmethod
    def approve_tier2(
        session: Session,
        expense_id: int,
        approver_id: int,
        notes: str = None
    ) -> EnhancedExpense:
        """Approve at tier 2"""

        expense = session.query(EnhancedExpense).get(expense_id)
        if not expense:
            return None

        expense.tier2_approver_id = approver_id
        expense.tier2_approved_date = datetime.utcnow()
        expense.tier2_notes = notes
        expense.status = ExpenseApprovalStatus.APPROVED

        session.commit()
        return expense

    @staticmethod
    def reject_tier2(
        session: Session,
        expense_id: int,
        approver_id: int,
        reason: str
    ) -> EnhancedExpense:
        """Reject at tier 2"""

        expense = session.query(EnhancedExpense).get(expense_id)
        if not expense:
            return None

        expense.status = ExpenseApprovalStatus.TIER2_REJECTED
        expense.tier2_approver_id = approver_id
        expense.tier2_approved_date = datetime.utcnow()
        expense.tier2_notes = f"REJECTED: {reason}"

        session.commit()
        return expense

    @staticmethod
    def mark_as_paid(
        session: Session,
        expense_id: int
    ) -> EnhancedExpense:
        """Mark expense as paid"""

        expense = session.query(EnhancedExpense).get(expense_id)
        if not expense:
            return None

        if expense.status != ExpenseApprovalStatus.APPROVED:
            return None

        expense.status = ExpenseApprovalStatus.PAID
        expense.paid_date = datetime.utcnow()

        session.commit()
        return expense

    @staticmethod
    def _get_config_for_expense(session: Session, expense: EnhancedExpense) -> ExpenseApprovalConfig:
        """Get approval config for expense"""

        employee = session.query(Employee).get(expense.employee_id)
        if not employee or not employee.department_id:
            return None

        return session.query(ExpenseApprovalConfig).filter(
            ExpenseApprovalConfig.department_id == employee.department_id
        ).first()

    @staticmethod
    def get_pending_approvals(
        session: Session,
        approver_id: int
    ) -> List[EnhancedExpense]:
        """Get expenses pending approval for an employee"""

        return session.query(EnhancedExpense).filter(
            (
                (EnhancedExpense.tier1_approver_id == approver_id) &
                (EnhancedExpense.status == ExpenseApprovalStatus.TIER1_PENDING)
            ) |
            (
                (EnhancedExpense.tier2_approver_id == approver_id) &
                (EnhancedExpense.status == ExpenseApprovalStatus.TIER2_PENDING)
            )
        ).order_by(EnhancedExpense.submitted_date.desc()).all()

    @staticmethod
    def get_budget_status(
        session: Session,
        department_id: int,
        fiscal_year: int = None
    ) -> dict:
        """Get budget vs. actual for department"""

        if fiscal_year is None:
            fiscal_year = datetime.utcnow().year

        config = session.query(ExpenseApprovalConfig).filter(
            ExpenseApprovalConfig.department_id == department_id,
            ExpenseApprovalConfig.budget_fiscal_year == fiscal_year
        ).first()

        if not config or not config.monthly_budget:
            return {"error": "No budget configured"}

        # Get all approved expenses for this department this month
        from database.models import Employee as Emp

        employee_ids = [
            e.id for e in session.query(Emp).filter(
                Emp.department_id == department_id
            ).all()
        ]

        from datetime import datetime as dt
        current_month = dt.utcnow().month

        approved_expenses = session.query(EnhancedExpense).filter(
            EnhancedExpense.employee_id.in_(employee_ids),
            EnhancedExpense.status == ExpenseApprovalStatus.APPROVED
        ).all()

        current_month_expenses = [
            e for e in approved_expenses
            if e.submitted_date.month == current_month
        ]

        spent = sum(e.amount for e in current_month_expenses)
        remaining = config.monthly_budget - spent
        utilization = (spent / config.monthly_budget *
                       100) if config.monthly_budget > 0 else 0

        return {
            "budget": float(config.monthly_budget),
            "spent": float(spent),
            "remaining": float(remaining),
            "utilization_percentage": utilization,
            "expense_count": len(current_month_expenses)
        }
