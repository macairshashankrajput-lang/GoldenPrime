"""
Local AI Assistant - Keyword-Based Search and FAQ
No external APIs needed - uses local keyword matching
"""

from sqlalchemy.orm import Session
from database.new_models import AIFAQEntry
from typing import List, Dict
import re


class LocalAIAssistant:
    """Local AI with semantic keyword matching"""

    # Common action commands
    ACTION_PATTERNS = {
        "leave_request": [
            r"request.*leave",
            r"take.*day.*off",
            r"need.*time.*off",
            r"book.*leave",
            r"apply.*leave"
        ],
        "status_change": [
            r"change.*status",
            r"switch.*to.*meeting",
            r"mark.*on.*break",
            r"set.*status",
            r"i.*on.*break"
        ],
        "find_colleague": [
            r"who.*available",
            r"find.*",
            r"locate.*",
            r"where.*",
            r"who.*is.*managing"
        ],
        "check_attendance": [
            r"my.*attendance",
            r"check.*attendance",
            r"attendance.*record",
            r"present.*absent"
        ],
        "task_update": [
            r"update.*task",
            r"complete.*task",
            r"my.*tasks",
            r"assign.*task"
        ],
        "meeting_schedule": [
            r"schedule.*meeting",
            r"book.*meeting",
            r"meet.*with",
            r"meeting.*time"
        ]
    }

    @staticmethod
    def add_faq_entry(
        session: Session,
        question: str,
        answer: str,
        category: str,
        keywords: List[str] = None,
        source: str = None
    ) -> AIFAQEntry:
        """Add FAQ entry to knowledge base"""

        if keywords is None:
            # Auto-extract keywords from question
            keywords = LocalAIAssistant._extract_keywords(question)

        entry = AIFAQEntry(
            question=question,
            answer=answer,
            category=category,
            keywords=keywords,
            source=source or "Manual Entry"
        )

        session.add(entry)
        session.commit()

        return entry

    @staticmethod
    def search_faq(
        session: Session,
        query: str,
        limit: int = 5
    ) -> List[AIFAQEntry]:
        """Search FAQ entries using keyword matching"""

        keywords = LocalAIAssistant._extract_keywords(query)

        all_entries = session.query(AIFAQEntry).filter(
            AIFAQEntry.is_active == True
        ).all()

        # Score entries based on keyword matches
        scored_entries = []

        for entry in all_entries:
            score = 0

            # Match against question
            for keyword in keywords:
                if keyword.lower() in entry.question.lower():
                    score += 3

            # Match against keywords
            for entry_kw in entry.keywords or []:
                for query_kw in keywords:
                    if query_kw.lower() == entry_kw.lower():
                        score += 2

            # Match against answer
            for keyword in keywords:
                if keyword.lower() in entry.answer.lower():
                    score += 1

            if score > 0:
                scored_entries.append((entry, score))

        # Sort by score descending
        scored_entries.sort(key=lambda x: x[1], reverse=True)

        return [entry for entry, score in scored_entries[:limit]]

    @staticmethod
    def get_faq_by_category(
        session: Session,
        category: str
    ) -> List[AIFAQEntry]:
        """Get all FAQs in a category"""

        return session.query(AIFAQEntry).filter(
            AIFAQEntry.category == category,
            AIFAQEntry.is_active == True
        ).all()

    @staticmethod
    def detect_intent(query: str) -> str:
        """Detect user intent from query"""

        query_lower = query.lower()

        for intent, patterns in LocalAIAssistant.ACTION_PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, query_lower):
                    return intent

        return "general_inquiry"

    @staticmethod
    def get_action_response(intent: str) -> Dict:
        """Get response template for detected intent"""

        responses = {
            "leave_request": {
                "action": "open_leave_form",
                "message": "I'll help you request time off. Opening the leave request form...",
                "form_type": "leave"
            },
            "status_change": {
                "action": "open_status_selector",
                "message": "Let me help you change your status. What status would you like to set?",
                "options": [
                    {"label": "On Production", "value": "on_production"},
                    {"label": "In Meeting", "value": "in_meeting"},
                    {"label": "On Break", "value": "on_break"},
                    {"label": "On Lunch", "value": "on_lunch"},
                ]
            },
            "find_colleague": {
                "action": "open_colleague_search",
                "message": "I can help you find a colleague. Let me search...",
                "search_type": "employee_directory"
            },
            "check_attendance": {
                "action": "open_attendance_view",
                "message": "Opening your attendance records...",
                "view_type": "personal_attendance"
            },
            "task_update": {
                "action": "open_task_view",
                "message": "Let me show you your tasks...",
                "view_type": "my_tasks"
            },
            "meeting_schedule": {
                "action": "open_meeting_form",
                "message": "I'll help you schedule a meeting. Opening the form...",
                "form_type": "meeting"
            },
            "general_inquiry": {
                "action": "search_faq",
                "message": "I'll search our knowledge base for that...",
                "perform_search": True
            }
        }

        return responses.get(intent, responses["general_inquiry"])

    @staticmethod
    def _extract_keywords(text: str) -> List[str]:
        """Extract keywords from text"""

        # Remove common words
        stopwords = {
            "the", "a", "an", "and", "or", "but", "in", "on", "at",
            "to", "for", "of", "with", "by", "from", "as", "is", "are",
            "be", "been", "being", "have", "has", "had", "do", "does",
            "did", "will", "would", "should", "could", "can", "might",
            "may", "must", "i", "you", "he", "she", "it", "we", "they",
            "what", "which", "who", "when", "where", "why", "how"
        }

        # Split and clean
        words = re.findall(r'\b\w+\b', text.lower())
        keywords = [w for w in words if w not in stopwords and len(w) > 2]

        return keywords[:10]  # Return top 10 keywords

    @staticmethod
    def get_suggestions(session: Session, query: str) -> List[str]:
        """Get suggested questions based on partial input"""

        keywords = LocalAIAssistant._extract_keywords(query)

        all_faqs = session.query(AIFAQEntry).filter(
            AIFAQEntry.is_active == True
        ).all()

        suggestions = []

        for faq in all_faqs:
            match_score = 0

            for keyword in keywords:
                if keyword.lower() in faq.question.lower():
                    match_score += 1

            if match_score > 0:
                suggestions.append(faq.question)

        return suggestions[:5]

    @staticmethod
    def format_response(entry: AIFAQEntry) -> Dict:
        """Format FAQ entry as response"""

        return {
            "question": entry.question,
            "answer": entry.answer,
            "category": entry.category,
            "source": entry.source,
            "helpfulness": {
                "helpful": 0,
                "not_helpful": 0
            }
        }

    @staticmethod
    def initialize_default_faqs(session: Session):
        """Initialize default FAQ entries"""

        default_faqs = [
            {
                "question": "How do I request leave?",
                "answer": "To request leave, go to Leave Management > Request Leave. Select the leave type, dates, and reason, then submit for approval.",
                "category": "Leave Management",
                "keywords": ["leave", "request", "time off", "vacation"]
            },
            {
                "question": "What are the different leave types?",
                "answer": "We offer Annual Leave, Sick Leave, Personal Leave, Maternity/Paternity Leave, and Bereavement Leave. Check your policy document for details.",
                "category": "Leave Management",
                "keywords": ["leave types", "annual", "sick", "maternity"]
            },
            {
                "question": "How do I check my attendance?",
                "answer": "Navigate to Attendance > My Attendance to view your daily records, attendance status, and monthly reports.",
                "category": "Attendance",
                "keywords": ["attendance", "check", "records", "present"]
            },
            {
                "question": "How do I change my status?",
                "answer": "Use the status selector in the header to quickly change between On Production, In Meeting, On Break, and On Lunch.",
                "category": "Status Tracking",
                "keywords": ["status", "change", "productive", "break"]
            },
            {
                "question": "Where can I find company policies?",
                "answer": "Company policies are available in Settings > Policies and Procedures, or contact HR for specific policy documents.",
                "category": "Company Policies",
                "keywords": ["policy", "policies", "procedures", "rules"]
            },
            {
                "question": "How do I submit an expense report?",
                "answer": "Go to Finance > Expense Management > Submit Expense. Fill in details, attach receipt, and submit for approval.",
                "category": "Finance",
                "keywords": ["expense", "report", "receipt", "reimbursement"]
            },
        ]

        for faq in default_faqs:
            existing = session.query(AIFAQEntry).filter(
                AIFAQEntry.question == faq["question"]
            ).first()

            if not existing:
                entry = AIFAQEntry(
                    question=faq["question"],
                    answer=faq["answer"],
                    category=faq["category"],
                    keywords=faq["keywords"],
                    source="System Default"
                )
                session.add(entry)

        session.commit()
