"""
Geofence Validator - Shift and Location Verification
Local geofence zone management without actual GPS
"""

from datetime import datetime, time, date
from sqlalchemy.orm import Session
from database.new_models import GeofenceZone, ShiftManagement
from database.models import Employee
import random
import string


class GeofenceValidator:
    """Manage geofence zones and shift verification"""

    @staticmethod
    def create_zone(
        session: Session,
        name: str,
        latitude: float = None,
        longitude: float = None,
        radius_meters: int = 100
    ) -> GeofenceZone:
        """Create a new geofence zone"""

        # Generate unique verification code
        verification_code = ''.join(
            random.choices(string.ascii_uppercase + string.digits, k=8)
        )

        zone = GeofenceZone(
            name=name,
            location_latitude=latitude,
            location_longitude=longitude,
            radius_meters=radius_meters,
            verification_code=verification_code
        )

        session.add(zone)
        session.commit()
        return zone

    @staticmethod
    def verify_code(session: Session, code: str) -> GeofenceZone:
        """Verify by geofence code"""
        return session.query(GeofenceZone).filter(
            GeofenceZone.verification_code == code,
            GeofenceZone.is_active == True
        ).first()

    @staticmethod
    def create_shift(
        session: Session,
        employee_id: int,
        shift_name: str,
        start_time: time,
        end_time: time,
        break_duration_minutes: int = 60,
        grace_period_minutes: int = 5,
        effective_from: date = None
    ) -> ShiftManagement:
        """Create a shift for employee"""

        shift = ShiftManagement(
            employee_id=employee_id,
            shift_name=shift_name,
            start_time=start_time,
            end_time=end_time,
            break_duration_minutes=break_duration_minutes,
            grace_period_minutes=grace_period_minutes,
            effective_from=effective_from or date.today()
        )

        session.add(shift)
        session.commit()
        return shift

    @staticmethod
    def get_active_shift(session: Session, employee_id: int) -> ShiftManagement:
        """Get employee's current active shift"""
        today = date.today()

        return session.query(ShiftManagement).filter(
            ShiftManagement.employee_id == employee_id,
            ShiftManagement.effective_from <= today,
            (ShiftManagement.effective_to == None) |
            (ShiftManagement.effective_to >= today)
        ).first()

    @staticmethod
    def check_in_allowed(session: Session, employee_id: int) -> tuple:
        """Check if employee is within check-in window"""

        shift = GeofenceValidator.get_active_shift(session, employee_id)

        if not shift:
            return False, "No active shift configured"

        now = datetime.utcnow().time()

        # Check if within grace period before shift
        grace_start = datetime.combine(
            date.today(),
            shift.start_time
        ) - __import__('datetime').timedelta(minutes=shift.grace_period_minutes)

        if now < grace_start.time():
            return False, f"Check-in starts at {grace_start.strftime('%H:%M')}"

        # Check if before shift end
        if now > shift.end_time:
            return False, f"Shift ended at {shift.end_time.strftime('%H:%M')}"

        return True, "Check-in allowed"

    @staticmethod
    def calculate_shift_duration(shift: ShiftManagement) -> int:
        """Calculate shift duration in minutes"""
        from datetime import datetime as dt, date as d

        start = dt.combine(d.today(), shift.start_time)
        end = dt.combine(d.today(), shift.end_time)

        if end < start:
            # Overnight shift
            end = end.replace(day=end.day + 1)

        duration = (end - start).total_seconds() / 60
        return int(duration - shift.break_duration_minutes)

    @staticmethod
    def is_overtime(
        session: Session,
        employee_id: int,
        checkout_time: datetime
    ) -> bool:
        """Check if checkout creates overtime"""

        shift = GeofenceValidator.get_active_shift(session, employee_id)
        if not shift:
            return False

        shift_end = datetime.combine(
            checkout_time.date(),
            shift.end_time
        )

        return checkout_time > shift_end

    @staticmethod
    def calculate_overtime_minutes(
        session: Session,
        employee_id: int,
        checkout_time: datetime
    ) -> int:
        """Calculate overtime minutes"""

        shift = GeofenceValidator.get_active_shift(session, employee_id)
        if not shift:
            return 0

        shift_end = datetime.combine(
            checkout_time.date(),
            shift.end_time
        )

        if checkout_time <= shift_end:
            return 0

        overtime_seconds = (checkout_time - shift_end).total_seconds()
        return int(overtime_seconds / 60)

    @staticmethod
    def is_late_checkin(
        session: Session,
        employee_id: int,
        checkin_time: datetime
    ) -> bool:
        """Check if checkin is late"""

        shift = GeofenceValidator.get_active_shift(session, employee_id)
        if not shift:
            return False

        shift_start_with_grace = datetime.combine(
            checkin_time.date(),
            shift.start_time
        )

        return checkin_time > shift_start_with_grace

    @staticmethod
    def calculate_late_minutes(
        session: Session,
        employee_id: int,
        checkin_time: datetime
    ) -> int:
        """Calculate how many minutes late"""

        shift = GeofenceValidator.get_active_shift(session, employee_id)
        if not shift:
            return 0

        shift_start = datetime.combine(
            checkin_time.date(),
            shift.start_time
        )

        if checkin_time <= shift_start:
            return 0

        late_seconds = (checkin_time - shift_start).total_seconds()
        return int(late_seconds / 60)

    @staticmethod
    def get_geofence_zones_by_name(session: Session, name_filter: str = None) -> list:
        """Get geofence zones"""
        query = session.query(GeofenceZone).filter(
            GeofenceZone.is_active == True
        )

        if name_filter:
            query = query.filter(
                GeofenceZone.name.ilike(f"%{name_filter}%")
            )

        return query.all()
