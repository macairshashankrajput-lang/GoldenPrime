"""
Onboarding Manager - Digital Onboarding Utility
Manages onboarding tasks and document workflows
"""

from sqlalchemy.orm import Session
from database.new_models import OnboardingTask, OnboardingDocument
from database.models import Employee
from datetime import datetime, timedelta
from enum import Enum


class OnboardingManager:
    """Manages employee onboarding workflows"""

    @staticmethod
    def create_onboarding_workflow(session: Session, employee_id: int,
                                   template_type: str = "standard") -> list:
        """Create onboarding workflow tasks"""

        try:
            employee = session.query(Employee).get(employee_id)
            if not employee:
                return []

            # Default tasks by template
            standard_tasks = [
                ("Orientation", "Complete HR orientation session", 1),
                ("IT Setup", "Set up computer and access credentials", 1),
                ("Training", "Complete compliance and safety training", 3),
                ("Department Intro", "Meet department team and lead", 2),
                ("Benefits", "Review and enroll in benefits", 5),
                ("Documentation", "Complete and sign required documents", 4)
            ]

            tasks = []
            for idx, (title, description, order) in enumerate(standard_tasks):
                task = OnboardingTask(
                    employee_id=employee_id,
                    title=title,
                    description=description,
                    status="PENDING",
                    sequence_order=order,
                    created_date=datetime.utcnow(),
                    target_completion=datetime.utcnow() + timedelta(days=order * 2)
                )
                session.add(task)
                tasks.append(task)

            session.commit()
            return tasks

        except Exception as ex:
            session.rollback()
            return []

    @staticmethod
    def create_document_requirement(session: Session, employee_id: int,
                                    document_type: str,
                                    template_name: str) -> OnboardingDocument:
        """Create document requirement for employee"""

        try:
            doc = OnboardingDocument(
                employee_id=employee_id,
                document_type=document_type,
                template_name=template_name,
                upload_date=None,
                signature_status="PENDING_SIGNATURE",
                created_date=datetime.utcnow(),
                signed_date=None
            )
            session.add(doc)
            session.commit()
            return doc

        except Exception:
            session.rollback()
            return None

    @staticmethod
    def get_onboarding_progress(session: Session, employee_id: int) -> dict:
        """Get onboarding completion progress"""

        try:
            tasks = session.query(OnboardingTask).filter(
                OnboardingTask.employee_id == employee_id
            ).all()

            if not tasks:
                return {
                    "total_tasks": 0,
                    "completed_tasks": 0,
                    "progress_percent": 0,
                    "tasks": []
                }

            completed = len([t for t in tasks if t.status == "COMPLETED"])
            total = len(tasks)
            progress = int((completed / total * 100)) if total > 0 else 0

            return {
                "total_tasks": total,
                "completed_tasks": completed,
                "progress_percent": progress,
                "tasks": tasks
            }

        except Exception:
            return {
                "total_tasks": 0,
                "completed_tasks": 0,
                "progress_percent": 0,
                "tasks": []
            }

    @staticmethod
    def update_task_status(session: Session, task_id: int,
                           status: str, notes: str = None) -> bool:
        """Update task status"""

        try:
            task = session.query(OnboardingTask).get(task_id)
            if not task:
                return False

            task.status = status
            task.notes = notes

            if status == "COMPLETED":
                task.completion_date = datetime.utcnow()

            session.commit()
            return True

        except Exception:
            session.rollback()
            return False

    @staticmethod
    def upload_document(session: Session, document_id: int,
                        file_path: str, file_name: str) -> bool:
        """Upload onboarding document"""

        try:
            doc = session.query(OnboardingDocument).get(document_id)
            if not doc:
                return False

            doc.file_path = file_path
            doc.file_name = file_name
            doc.upload_date = datetime.utcnow()
            doc.signature_status = "PENDING_SIGNATURE"

            session.commit()
            return True

        except Exception:
            session.rollback()
            return False

    @staticmethod
    def sign_document(session: Session, document_id: int,
                      signature_data: str = None) -> bool:
        """Sign onboarding document"""

        try:
            doc = session.query(OnboardingDocument).get(document_id)
            if not doc:
                return False

            doc.signature_status = "SIGNED"
            doc.signed_date = datetime.utcnow()
            doc.signature_data = signature_data

            session.commit()
            return True

        except Exception:
            session.rollback()
            return False

    @staticmethod
    def get_pending_documents(session: Session, employee_id: int) -> list:
        """Get pending document signatures"""

        try:
            docs = session.query(OnboardingDocument).filter(
                OnboardingDocument.employee_id == employee_id,
                OnboardingDocument.signature_status != "SIGNED"
            ).all()
            return docs

        except Exception:
            return []

    @staticmethod
    def get_onboarding_timeline(session: Session, employee_id: int) -> dict:
        """Get onboarding timeline"""

        try:
            tasks = session.query(OnboardingTask).filter(
                OnboardingTask.employee_id == employee_id
            ).order_by(OnboardingTask.sequence_order).all()

            timeline = {
                "tasks": [],
                "start_date": None,
                "estimated_end": None,
                "current_stage": None
            }

            if not tasks:
                return timeline

            timeline["start_date"] = tasks[0].created_date
            timeline["estimated_end"] = max(t.target_completion for t in tasks)

            # Find current stage
            for task in tasks:
                if task.status == "IN_PROGRESS":
                    timeline["current_stage"] = task.title
                    break

            timeline["tasks"] = [
                {
                    "title": t.title,
                    "status": t.status,
                    "order": t.sequence_order,
                    "target_date": t.target_completion,
                    "completion_date": t.completion_date
                }
                for t in tasks
            ]

            return timeline

        except Exception:
            return {"tasks": [], "start_date": None, "estimated_end": None}

    @staticmethod
    def complete_onboarding(session: Session, employee_id: int) -> bool:
        """Mark entire onboarding as complete"""

        try:
            tasks = session.query(OnboardingTask).filter(
                OnboardingTask.employee_id == employee_id
            ).all()

            for task in tasks:
                task.status = "COMPLETED"
                task.completion_date = datetime.utcnow()

            # Mark all documents as signed
            docs = session.query(OnboardingDocument).filter(
                OnboardingDocument.employee_id == employee_id
            ).all()

            for doc in docs:
                doc.signature_status = "SIGNED"
                doc.signed_date = datetime.utcnow()

            session.commit()
            return True

        except Exception:
            session.rollback()
            return False
