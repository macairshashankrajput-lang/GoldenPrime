"""
OKR Calculator - Objectives and Key Results Tracking
Calculate progress, status, and performance metrics
"""

from datetime import datetime, date
from sqlalchemy.orm import Session
from database.new_models import OKRTracking, OKRStatus
from typing import List, Dict


class OKRCalculator:
    """Manage OKR tracking and calculations"""

    @staticmethod
    def create_okr(
        session: Session,
        level: str,  # company, team, individual
        level_id: int,
        objective: str,
        key_results: List[str],
        owner_id: int,
        start_date: date,
        end_date: date
    ) -> OKRTracking:
        """Create new OKR"""

        okr = OKRTracking(
            level=level,
            level_id=level_id,
            objective=objective,
            owner_id=owner_id,
            start_date=start_date,
            end_date=end_date,
            status=OKRStatus.NOT_STARTED
        )

        # Set key results
        for i, kr in enumerate(key_results[:3]):
            if i == 0:
                okr.key_result_1 = kr
            elif i == 1:
                okr.key_result_2 = kr
            elif i == 2:
                okr.key_result_3 = kr

        session.add(okr)
        session.commit()
        return okr

    @staticmethod
    def update_key_result_progress(
        session: Session,
        okr_id: int,
        kr_number: int,
        current_value: float
    ) -> OKRTracking:
        """Update progress on a key result"""

        okr = session.query(OKRTracking).get(okr_id)
        if not okr:
            return None

        if kr_number == 1:
            okr.kr1_current_value = current_value
        elif kr_number == 2:
            okr.kr2_current_value = current_value
        elif kr_number == 3:
            okr.kr3_current_value = current_value

        # Update status based on progress
        progress = OKRCalculator.calculate_okr_progress(okr)
        if progress >= 100:
            okr.status = OKRStatus.COMPLETED
        elif progress >= 75:
            okr.status = OKRStatus.ON_TRACK
        elif progress >= 50:
            okr.status = OKRStatus.ON_TRACK
        else:
            okr.status = OKRStatus.AT_RISK

        session.commit()
        return okr

    @staticmethod
    def calculate_kr_progress(current: float, target: float) -> float:
        """Calculate single key result progress percentage"""
        if target == 0:
            return 0.0

        progress = (current / target) * 100
        return min(100.0, progress)

    @staticmethod
    def calculate_okr_progress(okr: OKRTracking) -> float:
        """Calculate overall OKR progress (average of KRs)"""

        kr_progresses = []

        if okr.kr1_target_value:
            kr_progresses.append(
                OKRCalculator.calculate_kr_progress(
                    okr.kr1_current_value,
                    okr.kr1_target_value
                )
            )

        if okr.kr2_target_value:
            kr_progresses.append(
                OKRCalculator.calculate_kr_progress(
                    okr.kr2_current_value,
                    okr.kr2_target_value
                )
            )

        if okr.kr3_target_value:
            kr_progresses.append(
                OKRCalculator.calculate_kr_progress(
                    okr.kr3_current_value,
                    okr.kr3_target_value
                )
            )

        if not kr_progresses:
            return 0.0

        return sum(kr_progresses) / len(kr_progresses)

    @staticmethod
    def get_okrs_by_level(
        session: Session,
        level: str,
        level_id: int
    ) -> List[OKRTracking]:
        """Get all OKRs for a level"""

        return session.query(OKRTracking).filter(
            OKRTracking.level == level,
            OKRTracking.level_id == level_id
        ).all()

    @staticmethod
    def get_active_okrs(
        session: Session,
        level: str,
        level_id: int
    ) -> List[OKRTracking]:
        """Get active OKRs"""

        today = date.today()

        return session.query(OKRTracking).filter(
            OKRTracking.level == level,
            OKRTracking.level_id == level_id,
            OKRTracking.start_date <= today,
            OKRTracking.end_date >= today
        ).all()

    @staticmethod
    def complete_okr(session: Session, okr_id: int) -> OKRTracking:
        """Mark OKR as completed"""

        okr = session.query(OKRTracking).get(okr_id)
        if okr:
            okr.status = OKRStatus.COMPLETED
            session.commit()

        return okr

    @staticmethod
    def abandon_okr(session: Session, okr_id: int) -> OKRTracking:
        """Mark OKR as abandoned"""

        okr = session.query(OKRTracking).get(okr_id)
        if okr:
            okr.status = OKRStatus.ABANDONED
            session.commit()

        return okr

    @staticmethod
    def get_cascading_okrs(
        session: Session,
        company_id: int,
        team_id: int = None,
        employee_id: int = None
    ) -> Dict:
        """Get cascading OKRs from company → team → individual"""

        result = {
            "company": [],
            "team": [],
            "individual": []
        }

        # Company OKRs
        result["company"] = OKRCalculator.get_active_okrs(
            session, "company", company_id
        )

        if team_id:
            result["team"] = OKRCalculator.get_active_okrs(
                session, "team", team_id
            )

        if employee_id:
            result["individual"] = OKRCalculator.get_active_okrs(
                session, "individual", employee_id
            )

        return result

    @staticmethod
    def get_okr_summary(okr: OKRTracking) -> Dict:
        """Get OKR summary with progress"""

        progress = OKRCalculator.calculate_okr_progress(okr)

        return {
            "id": okr.id,
            "objective": okr.objective,
            "status": okr.status.value,
            "progress_percentage": progress,
            "confidence_level": okr.confidence_level,
            "key_results": [
                {
                    "title": okr.key_result_1,
                    "current": okr.kr1_current_value,
                    "target": okr.kr1_target_value,
                    "unit": okr.kr1_unit,
                    "progress": OKRCalculator.calculate_kr_progress(
                        okr.kr1_current_value,
                        okr.kr1_target_value
                    ) if okr.kr1_target_value else 0
                } if okr.key_result_1 else None,
                {
                    "title": okr.key_result_2,
                    "current": okr.kr2_current_value,
                    "target": okr.kr2_target_value,
                    "unit": okr.kr2_unit,
                    "progress": OKRCalculator.calculate_kr_progress(
                        okr.kr2_current_value,
                        okr.kr2_target_value
                    ) if okr.kr2_target_value else 0
                } if okr.key_result_2 else None,
                {
                    "title": okr.key_result_3,
                    "current": okr.kr3_current_value,
                    "target": okr.kr3_target_value,
                    "unit": okr.kr3_unit,
                    "progress": OKRCalculator.calculate_kr_progress(
                        okr.kr3_current_value,
                        okr.kr3_target_value
                    ) if okr.kr3_target_value else 0
                } if okr.key_result_3 else None,
            ],
            "start_date": okr.start_date.isoformat(),
            "end_date": okr.end_date.isoformat(),
            "owner_id": okr.owner_id
        }
