"""
Organization Chart Builder - Hierarchical Tree and Graph Building
Build and traverse organizational hierarchies
"""

from sqlalchemy.orm import Session
from database.models import Employee, Department
from typing import Dict, List, Tree


class OrgChartBuilder:
    """Build and manage organizational hierarchies"""

    @staticmethod
    def get_reporting_structure(session: Session, employee_id: int) -> Dict:
        """Get who reports to this employee"""

        employee = session.query(Employee).get(employee_id)
        if not employee:
            return None

        # Get direct reports
        direct_reports = session.query(Employee).filter(
            Employee.manager_id == employee_id
        ).all()

        return {
            "employee_id": employee.id,
            "name": f"{employee.first_name} {employee.last_name}",
            "position": employee.position,
            "department": employee.department.name if employee.department else None,
            "direct_reports": len(direct_reports),
            "reports": [
                {
                    "id": report.id,
                    "name": f"{report.first_name} {report.last_name}",
                    "position": report.position
                }
                for report in direct_reports
            ]
        }

    @staticmethod
    def build_org_tree(session: Session, root_employee_id: int = None) -> Dict:
        """Build complete organizational tree"""

        def build_subtree(emp_id: int) -> Dict:
            emp = session.query(Employee).get(emp_id)
            if not emp:
                return None

            direct_reports = session.query(Employee).filter(
                Employee.manager_id == emp_id
            ).all()

            return {
                "id": emp.id,
                "name": f"{emp.first_name} {emp.last_name}",
                "position": emp.position,
                "department": emp.department.name if emp.department else None,
                "email": emp.email,
                "photo_path": emp.profile_photo_path,
                "children": [
                    build_subtree(report.id)
                    for report in direct_reports
                ]
            }

        if root_employee_id:
            return build_subtree(root_employee_id)

        # Find CEO or top-level employee (no manager)
        root = session.query(Employee).filter(
            Employee.manager_id == None
        ).first()

        if root:
            return build_subtree(root.id)

        return None

    @staticmethod
    def get_team_hierarchy(session: Session, department_id: int) -> Dict:
        """Get organizational hierarchy for a department"""

        department = session.query(Department).get(department_id)
        if not department:
            return None

        # Get all employees in department
        employees = session.query(Employee).filter(
            Employee.department_id == department_id
        ).all()

        # Find department head
        head = None
        for emp in employees:
            if not emp.manager_id:  # No manager in this department
                head = emp
                break

        if not head and employees:
            head = employees[0]

        tree = None
        if head:
            tree = OrgChartBuilder._build_department_tree(
                session, head.id, department_id)

        return {
            "department_id": department.id,
            "department_name": department.name,
            "employee_count": len(employees),
            "tree": tree
        }

    @staticmethod
    def _build_department_tree(session: Session, emp_id: int, dept_id: int) -> Dict:
        """Build tree for department employees"""

        emp = session.query(Employee).get(emp_id)
        if not emp or emp.department_id != dept_id:
            return None

        direct_reports = session.query(Employee).filter(
            Employee.manager_id == emp_id,
            Employee.department_id == dept_id
        ).all()

        return {
            "id": emp.id,
            "name": f"{emp.first_name} {emp.last_name}",
            "position": emp.position,
            "email": emp.email,
            "children": [
                OrgChartBuilder._build_department_tree(
                    session, report.id, dept_id)
                for report in direct_reports
            ]
        }

    @staticmethod
    def get_management_chain(session: Session, employee_id: int) -> List[Dict]:
        """Get management chain for employee (upward)"""

        chain = []
        current = session.query(Employee).get(employee_id)

        while current:
            chain.append({
                "id": current.id,
                "name": f"{current.first_name} {current.last_name}",
                "position": current.position,
                "department": current.department.name if current.department else None
            })

            if current.manager_id:
                current = session.query(Employee).get(current.manager_id)
            else:
                break

        return chain

    @staticmethod
    def get_peer_group(session: Session, employee_id: int) -> List[Dict]:
        """Get peer group (same manager)"""

        employee = session.query(Employee).get(employee_id)
        if not employee or not employee.manager_id:
            return []

        peers = session.query(Employee).filter(
            Employee.manager_id == employee.manager_id,
            Employee.id != employee_id
        ).all()

        return [
            {
                "id": peer.id,
                "name": f"{peer.first_name} {peer.last_name}",
                "position": peer.position,
                "department": peer.department.name if peer.department else None
            }
            for peer in peers
        ]

    @staticmethod
    def get_direct_reports(session: Session, employee_id: int) -> List[Dict]:
        """Get all direct reports"""

        reports = session.query(Employee).filter(
            Employee.manager_id == employee_id
        ).all()

        return [
            {
                "id": report.id,
                "name": f"{report.first_name} {report.last_name}",
                "position": report.position,
                "department": report.department.name if report.department else None,
                "email": report.email
            }
            for report in reports
        ]

    @staticmethod
    def get_depth_from_root(session: Session, employee_id: int) -> int:
        """Calculate depth from root (CEO)"""

        depth = 0
        current = session.query(Employee).get(employee_id)

        while current and current.manager_id:
            depth += 1
            current = session.query(Employee).get(current.manager_id)

        return depth

    @staticmethod
    def get_team_size(session: Session, employee_id: int, include_indirect: bool = True) -> int:
        """Calculate team size (direct reports + optional indirect)"""

        if not include_indirect:
            return len(OrgChartBuilder.get_direct_reports(session, employee_id))

        # Count all subordinates recursively
        def count_subordinates(emp_id: int) -> int:
            direct = session.query(Employee).filter(
                Employee.manager_id == emp_id
            ).all()

            count = len(direct)
            for report in direct:
                count += count_subordinates(report.id)

            return count

        return count_subordinates(employee_id)

    @staticmethod
    def get_org_stats(session: Session) -> Dict:
        """Get organization statistics"""

        all_employees = session.query(Employee).all()

        # Count managers
        managers = [e for e in all_employees if any(
            session.query(Employee).filter(Employee.manager_id == e.id).first()
        )]

        # Count no-manager employees
        roots = [e for e in all_employees if e.manager_id is None]

        # Average team size
        avg_team_size = 0
        if managers:
            total_reports = sum(
                len(OrgChartBuilder.get_direct_reports(session, m.id))
                for m in managers
            )
            avg_team_size = total_reports / len(managers)

        return {
            "total_employees": len(all_employees),
            "total_managers": len(managers),
            "organizations": len(roots),
            "average_team_size": round(avg_team_size, 2),
            "depth": max(
                (OrgChartBuilder.get_depth_from_root(session, e.id)
                 for e in all_employees),
                default=0
            )
        }
