"""
Enhanced Call Logger - Local Call Simulation and Logging
Mock WebRTC calls with full logging and history
"""

from datetime import datetime
from sqlalchemy.orm import Session
from database.new_models import EnhancedCallLog, CallType, CallStatus
from typing import List, Dict


class CallLogger:
    """Manage simulated call logging (local, no actual WebRTC)"""

    @staticmethod
    def initiate_call(
        session: Session,
        initiator_id: int,
        recipient_id: int = None,
        call_type: CallType = CallType.AUDIO,
        participants: List[int] = None
    ) -> EnhancedCallLog:
        """Initiate a new call"""

        call = EnhancedCallLog(
            initiator_id=initiator_id,
            recipient_id=recipient_id,
            call_type=call_type,
            status=CallStatus.INITIATED,
            participants=participants or []
        )

        session.add(call)
        session.commit()
        return call

    @staticmethod
    def update_call_status(session: Session, call_id: int, status: CallStatus) -> EnhancedCallLog:
        """Update call status"""

        call = session.query(EnhancedCallLog).get(call_id)
        if call:
            call.status = status

            if status == CallStatus.CONNECTED and call.start_time is None:
                call.start_time = datetime.utcnow()

            if status == CallStatus.ENDED:
                call.end_time = datetime.utcnow()
                duration = (call.end_time - call.start_time).total_seconds()
                call.duration_seconds = int(duration)

            session.commit()

        return call

    @staticmethod
    def toggle_mute(session: Session, call_id: int, is_muted: bool) -> EnhancedCallLog:
        """Toggle mute on call"""
        call = session.query(EnhancedCallLog).get(call_id)
        if call:
            call.is_muted = is_muted
            session.commit()
        return call

    @staticmethod
    def toggle_video(session: Session, call_id: int, enabled: bool) -> EnhancedCallLog:
        """Toggle video on call"""
        call = session.query(EnhancedCallLog).get(call_id)
        if call:
            call.video_enabled = enabled
            session.commit()
        return call

    @staticmethod
    def add_transcript(session: Session, call_id: int, transcript: str) -> EnhancedCallLog:
        """Add call transcript"""
        call = session.query(EnhancedCallLog).get(call_id)
        if call:
            call.transcript = transcript
            call.recording_available = True
            session.commit()
        return call

    @staticmethod
    def get_call_history(session: Session, employee_id: int, limit: int = 50) -> List[EnhancedCallLog]:
        """Get call history for employee"""
        return session.query(EnhancedCallLog).filter(
            (EnhancedCallLog.initiator_id == employee_id) |
            (EnhancedCallLog.recipient_id == employee_id)
        ).order_by(EnhancedCallLog.created_at.desc()).limit(limit).all()

    @staticmethod
    def get_call_duration_formatted(call: EnhancedCallLog) -> str:
        """Format call duration as HH:MM:SS"""
        seconds = call.duration_seconds
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        secs = seconds % 60
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"

    @staticmethod
    def get_call_stats(session: Session, employee_id: int) -> Dict:
        """Get call statistics for employee"""
        from database.models import Employee

        calls = session.query(EnhancedCallLog).filter(
            (EnhancedCallLog.initiator_id == employee_id) |
            (EnhancedCallLog.recipient_id == employee_id)
        ).all()

        initiated = [c for c in calls if c.initiator_id == employee_id]
        received = [c for c in calls if c.recipient_id == employee_id]

        total_duration = sum(
            c.duration_seconds for c in calls if c.status == CallStatus.ENDED)

        video_calls = len([c for c in calls if c.call_type == CallType.VIDEO])
        audio_calls = len([c for c in calls if c.call_type == CallType.AUDIO])

        return {
            "total_calls": len(calls),
            "initiated_calls": len(initiated),
            "received_calls": len(received),
            "total_duration_seconds": total_duration,
            "total_duration_formatted": f"{total_duration // 3600}h {(total_duration % 3600) // 60}m",
            "average_duration": int(total_duration / len(calls)) if calls else 0,
            "video_calls": video_calls,
            "audio_calls": audio_calls,
            "huddles": len([c for c in calls if c.call_type == CallType.HUDDLE]),
        }

    @staticmethod
    def reject_call(session: Session, call_id: int) -> EnhancedCallLog:
        """Reject an incoming call"""
        call = session.query(EnhancedCallLog).get(call_id)
        if call and call.status in [CallStatus.INITIATED, CallStatus.CONNECTING]:
            call.status = CallStatus.REJECTED
            call.end_time = datetime.utcnow()
            session.commit()
        return call

    @staticmethod
    def miss_call(session: Session, call_id: int) -> EnhancedCallLog:
        """Mark call as missed"""
        call = session.query(EnhancedCallLog).get(call_id)
        if call and call.status in [CallStatus.INITIATED, CallStatus.CONNECTING]:
            call.status = CallStatus.MISSED
            call.end_time = datetime.utcnow()
            session.commit()
        return call
