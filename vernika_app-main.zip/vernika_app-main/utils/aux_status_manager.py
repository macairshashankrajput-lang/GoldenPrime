"""
AUX Status Manager - Real-Time Presence Tracking
Manages employee activity status with automatic tracking and inactivity detection
"""

from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from database.new_models import AUXLog, AUXStatus
from database.models import Employee


class AUXStatusManager:
    """Manage employee AUX (activity) status"""

    # Inactivity threshold (seconds)
    INACTIVITY_THRESHOLD = 60

    STATUS_COLORS = {
        AUXStatus.ON_PRODUCTION: "#4CAF50",      # Green
        AUXStatus.FREE_IDLE: "#2196F3",          # Blue
        AUXStatus.IN_MEETING: "#9C27B0",         # Purple
        AUXStatus.COACHING_TRAINING: "#FFC107",  # Amber
        AUXStatus.ON_BREAK: "#FF9800",           # Orange
        AUXStatus.ON_LUNCH: "#F44336",           # Red
        AUXStatus.LOG_OUT: "#9E9E9E",            # Gray
    }

    STATUS_LABELS = {
        AUXStatus.ON_PRODUCTION: "On Production",
        AUXStatus.FREE_IDLE: "Free / Idle",
        AUXStatus.IN_MEETING: "In Meeting",
        AUXStatus.COACHING_TRAINING: "Coaching / Training",
        AUXStatus.ON_BREAK: "On Break",
        AUXStatus.ON_LUNCH: "On Lunch",
        AUXStatus.LOG_OUT: "Logged Out",
    }

    STATUS_CATEGORY = {
        AUXStatus.ON_PRODUCTION: "productive",
        AUXStatus.FREE_IDLE: "idle",
        AUXStatus.IN_MEETING: "productive",
        AUXStatus.COACHING_TRAINING: "non_productive",
        AUXStatus.ON_BREAK: "non_productive",
        AUXStatus.ON_LUNCH: "non_productive",
        AUXStatus.LOG_OUT: "offline",
    }

    @staticmethod
    def set_status(session: Session, employee_id: int, new_status: AUXStatus, notes: str = None) -> AUXLog:
        """Set employee status and end previous status"""

        # End previous active status
        previous = session.query(AUXLog).filter(
            AUXLog.employee_id == employee_id,
            AUXLog.end_time == None
        ).first()

        now = datetime.utcnow()

        if previous:
            previous.end_time = now
            duration = (now - previous.start_time).total_seconds()
            previous.duration_seconds = int(duration)
            session.add(previous)

        # Create new status log
        new_log = AUXLog(
            employee_id=employee_id,
            status=new_status,
            start_time=now,
            notes=notes
        )

        session.add(new_log)
        session.commit()

        return new_log

    @staticmethod
    def get_current_status(session: Session, employee_id: int) -> AUXLog:
        """Get current active status"""
        return session.query(AUXLog).filter(
            AUXLog.employee_id == employee_id,
            AUXLog.end_time == None
        ).first()

    @staticmethod
    def get_status_duration(session: Session, employee_id: int) -> int:
        """Get duration in seconds of current status"""
        current = AUXStatusManager.get_current_status(session, employee_id)
        if not current:
            return 0

        return int((datetime.utcnow() - current.start_time).total_seconds())

    @staticmethod
    def check_inactivity(session: Session, employee_id: int) -> bool:
        """Check if employee should be marked as idle due to inactivity"""
        current = AUXStatusManager.get_current_status(session, employee_id)

        if not current or current.status in [AUXStatus.FREE_IDLE, AUXStatus.LOG_OUT]:
            return False

        duration = AUXStatusManager.get_status_duration(session, employee_id)
        return duration > AUXStatusManager.INACTIVITY_THRESHOLD

    @staticmethod
    def auto_switch_to_idle(session: Session, employee_id: int) -> AUXLog:
        """Automatically switch employee to idle if inactive"""
        if AUXStatusManager.check_inactivity(session, employee_id):
            return AUXStatusManager.set_status(
                session,
                employee_id,
                AUXStatus.FREE_IDLE,
                notes="Auto-switched due to inactivity"
            )
        return None

    @staticmethod
    def get_daily_timeline(session: Session, employee_id: int, date_obj) -> list:
        """Get all status changes for a specific day"""
        start_of_day = datetime.combine(date_obj, datetime.min.time())
        end_of_day = datetime.combine(date_obj, datetime.max.time())

        return session.query(AUXLog).filter(
            AUXLog.employee_id == employee_id,
            AUXLog.start_time >= start_of_day,
            AUXLog.start_time <= end_of_day
        ).order_by(AUXLog.start_time).all()

    @staticmethod
    def get_productive_time(session: Session, employee_id: int, date_obj) -> int:
        """Calculate total productive time in seconds"""
        productive_statuses = [
            AUXStatus.ON_PRODUCTION,
            AUXStatus.IN_MEETING
        ]

        logs = AUXStatusManager.get_daily_timeline(
            session, employee_id, date_obj)

        total_seconds = 0
        for log in logs:
            if log.status in productive_statuses:
                total_seconds += log.duration_seconds

        return total_seconds

    @staticmethod
    def get_team_status_matrix(session: Session, team_id: int) -> dict:
        """Get current status of all team members"""
        from database.models import Employee

        team_members = session.query(Employee).filter(
            Employee.team_id == team_id
        ).all()

        matrix = {}
        for member in team_members:
            current = AUXStatusManager.get_current_status(session, member.id)
            duration = AUXStatusManager.get_status_duration(session, member.id)

            matrix[member.id] = {
                "name": f"{member.first_name} {member.last_name}",
                "status": current.status.value if current else "unknown",
                "duration": duration,
                "label": AUXStatusManager.STATUS_LABELS.get(current.status if current else None, "Unknown"),
                "color": AUXStatusManager.STATUS_COLORS.get(current.status if current else None, "#999999"),
                "category": AUXStatusManager.STATUS_CATEGORY.get(current.status if current else None, "unknown"),
            }

        return matrix

    @staticmethod
    def get_adherence_score(session: Session, employee_id: int, start_date, end_date) -> float:
        """Calculate production time adherence score (0-100)"""
        from datetime import date as date_type

        current_date = start_date
        total_productive = 0
        working_days = 0

        while current_date <= end_date:
            # Count only weekdays
            if current_date.weekday() < 5:  # Monday=0, Friday=4
                working_days += 1
                productive_seconds = AUXStatusManager.get_productive_time(
                    session, employee_id, current_date
                )
                total_productive += productive_seconds

            current_date += timedelta(days=1)

        if working_days == 0:
            return 0.0

        # Expected 8 hours per day in seconds
        expected_seconds = working_days * 8 * 3600
        adherence = (total_productive / expected_seconds) * \
            100 if expected_seconds > 0 else 0

        return min(100.0, adherence)  # Cap at 100%
