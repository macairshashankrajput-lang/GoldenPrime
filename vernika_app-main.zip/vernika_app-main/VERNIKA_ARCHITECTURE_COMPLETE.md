# VERNIKA - Complete Application Architecture & Documentation
## Industry-Level Human Resource Management System

---

## 📋 TABLE OF CONTENTS
1. [Project Overview](#project-overview)
2. [Technology Stack](#technology-stack)
3. [Architecture & Layers](#architecture--layers)
4. [Database Design](#database-design)
5. [Features & Modules](#features--modules)
6. [UI/UX Design System](#uiux-design-system)
7. [Security Architecture](#security-architecture)
8. [File Structure & Components](#file-structure--components)
9. [API & Integration Points](#api--integration-points)
10. [Deployment & Scalability](#deployment--scalability)
11. [Development Workflow](#development-workflow)

---

## 🎯 PROJECT OVERVIEW

### Application Purpose
**Vernika** is a professional, enterprise-grade Human Resource Management (HRA) system designed for multi-user desktop environments. It provides comprehensive HR management with role-based access control, supporting both administrative and employee-level operations.

### Key Characteristics
- **Multi-User Support**: Handles concurrent users with session management
- **Role-Based Access Control**: Admin and Employee roles with granular permissions
- **Enterprise Database**: PostgreSQL with Row-Level Security (RLS)
- **Desktop Application**: Built with Python Flet for cross-platform compatibility
- **Cloud-Ready**: Supabase integration for cloud-hosted database and storage
- **Modern UI**: Material Design 3 inspired interface with light/dark theme support

### Application Info
- **Name**: Vernika
- **Version**: 1.0.0
- **Type**: Desktop Application (Python + Flet)
- **Target Users**: HR Departments, Enterprises (200+ users capacity)
- **Database**: PostgreSQL (Supabase)

---

## 🛠️ TECHNOLOGY STACK

### Frontend Framework
| Technology | Purpose | Version |
|------------|---------|---------|
| **Flet** | UI Framework (Python) | ≥0.25.0 |
| **Python** | Core Language | 3.8+ |
| **Pillow** | Image Processing | ≥10.0.0 |

### Backend & Database
| Technology | Purpose | Version |
|------------|---------|---------|
| **SQLAlchemy** | ORM (Object-Relational Mapping) | ≥2.0.0 |
| **PostgreSQL** | Relational Database | Latest |
| **Supabase** | Managed PostgreSQL + Auth | Latest |
| **psycopg2-binary** | PostgreSQL Driver (Sync) | ≥2.9.0 |

### Security & Authentication
| Technology | Purpose | Version |
|------------|---------|---------|
| **bcrypt** | Password Hashing | ≥4.0.0 |
| **PyJWT** | JWT Token Management | ≥2.8.0 |
| **python-jose** | JOSE Implementation | ≥3.3.0 |
| **passlib** | Password Hashing Library | ≥1.7.4 |

### Utilities & Integrations
| Technology | Purpose | Version |
|------------|---------|---------|
| **python-dotenv** | Environment Configuration | ≥1.0.0 |
| **pydantic** | Data Validation | ≥2.0.0 |
| **email-validator** | Email Validation | ≥2.0.0 |
| **python-dateutil** | Date/Time Utilities | ≥2.8.2 |
| **requests** | HTTP Requests (APIs) | ≥2.31.0 |
| **reportlab** | PDF Generation | ≥4.0.0 |
| **openpyxl** | Excel Export | ≥3.1.0 |

### Development & Testing
| Technology | Purpose | Version |
|------------|---------|---------|
| **pytest** | Testing Framework | ≥7.0.0 |
| **pytest-cov** | Code Coverage | ≥4.0.0 |
| **black** | Code Formatting | ≥23.0.0 |
| **flake8** | Code Linting | ≥6.0.0 |
| **mypy** | Type Checking | ≥1.0.0 |

---

## 🏗️ ARCHITECTURE & LAYERS

### Layered Architecture Pattern

```
┌─────────────────────────────────────────────────┐
│         PRESENTATION LAYER (UI/UX)              │
│  Flet Components, Screens, Forms, Dialogs       │
├─────────────────────────────────────────────────┤
│       BUSINESS LOGIC LAYER                      │
│Navigation, Theme, Keyboard Shortcuts, Validators│
├─────────────────────────────────────────────────┤
│       DATA ACCESS LAYER                         │
│  Repositories, Operations, Session Management   │
├─────────────────────────────────────────────────┤
│       DATABASE LAYER                            │
│  SQLAlchemy Models, Connections, Migrations     │
├─────────────────────────────────────────────────┤
│       INFRASTRUCTURE LAYER                      │
│  PostgreSQL, Supabase Storage, External APIs    │
└─────────────────────────────────────────────────┘
```

### Layer Responsibilities

#### 1. **Presentation Layer** (`/screens`, `/components`)
- User interface screens and components
- Form handling and validation
- Dialog boxes and popups
- User interactions and event handling
- Screen navigation and routing

#### 2. **Business Logic Layer** (`/core`, `/auth`)
- Application workflow and logic
- Authentication and authorization
- Theme and styling
- Navigation management
- Keyboard shortcuts and accessibility

#### 3. **Data Access Layer** (`/database` - operations, repositories)
- CRUD operations
- Query optimization and caching
- Data repositories and data access patterns
- Session management
- Audit logging

#### 4. **Database Layer** (`/database` - models, connections)
- SQLAlchemy ORM models
- Database connection management
- Database migrations
- Relationship definitions
- Constraints and indexes

#### 5. **Infrastructure Layer** (External Services)
- PostgreSQL database
- Supabase services (Auth, Storage, RLS)
- External APIs (Email, Google Sheets, etc.)
- File storage system

---

## 🗄️ DATABASE DESIGN

### Database Technology Stack
- **Type**: Relational Database (PostgreSQL)
- **Hosted On**: Supabase (Managed PostgreSQL)
- **ORM**: SQLAlchemy 2.0+
- **Security**: Row-Level Security (RLS) enabled
- **Pool Settings**: Optimized for 200+ concurrent users

### Database Configuration
```python
DATABASE_TYPE = "postgresql"
DB_POOL_SIZE = 20                    # Base connections
DB_MAX_OVERFLOW = 40                 # Additional connections
DB_POOL_RECYCLE = 1800              # Connection timeout (30 min)
DB_POOL_TIMEOUT = 30                # Acquire timeout
DB_SSL_MODE = "require"             # SSL encryption
```

### Core Database Models (Entities)

#### **1. User Management & Authentication**
```
User (users table)
├── id (PK)
├── username (UNIQUE)
├── email (UNIQUE)
├── password_hash (bcrypt)
├── role_id (FK → roles)
├── status (active, inactive, locked, pending)
├── last_seen
├── is_online
├── session_token
├── last_login
└── last_ip

Role (roles table)
├── id (PK)
├── name (UNIQUE)
├── display_name
├── description
├── is_active
├── level (permission hierarchy)
└── permissions (JSON)

Company (companies table)
├── id (PK)
├── name
├── email
├── phone
└── address
```

#### **2. Employee & Organization Structure**
```
Employee (employees table)
├── id (PK)
├── user_id (FK → users)
├── department_id (FK → departments)
├── position_id (FK → positions)
├── manager_id (FK → employees - self-referential)
├── first_name
├── last_name
├── date_of_birth
├── gender
├── phone
├── personal_email
├── official_email
├── address
├── joining_date
├── employment_type
├── salary
├── bank_account
├── profile_photo_url
└── is_active

Department (departments table)
├── id (PK)
├── name
├── description
├── head_id (FK → employees)
├── budget
└── created_at

Position (positions table)
├── id (PK)
├── name
├── description
├── department_id (FK → departments)
├── salary_range_min
├── salary_range_max
└── is_active

Team (teams table)
├── id (PK)
├── name
├── description
├── department_id (FK → departments)
├── lead_id (FK → employees)
├── members (JSON array of employee IDs)
└── created_at
```

#### **3. Attendance & Time Tracking**
```
Attendance (attendance table)
├── id (PK)
├── employee_id (FK → employees)
├── date
├── status (present, absent, late, half_day, on_leave)
├── check_in_time
├── check_out_time
├── duration
├── notes
└── created_at

TimeOff (time_off table)
├── id (PK)
├── employee_id (FK → employees)
├── date
├── duration
├── reason
├── approved_by (FK → employees)
└── status
```

#### **4. Leave Management**
```
LeaveRequest (leave_requests table)
├── id (PK)
├── employee_id (FK → employees)
├── leave_type (annual, sick, personal, maternity, etc.)
├── start_date
├── end_date
├── reason
├── status (pending, approved, rejected, cancelled)
├── approved_by (FK → employees)
├── created_at
└── updated_at

LeaveBalance (leave_balances table)
├── id (PK)
├── employee_id (FK → employees)
├── leave_type
├── total_balance
├── used_balance
├── remaining_balance
├── fiscal_year
└── updated_at

LeaveTypeConfig (leave_type_config table)
├── id (PK)
├── leave_type
├── max_days
├── carry_forward_days
├── requires_approval
└── description
```

#### **5. Task & Project Management**
```
Task (tasks table)
├── id (PK)
├── project_id (FK → projects)
├── assigned_to (FK → employees)
├── created_by (FK → employees)
├── title
├── description
├── priority (low, medium, high, urgent)
├── status (todo, in_progress, completed, cancelled)
├── start_date
├── due_date
├── completion_date
├── estimated_hours
├── actual_hours
└── created_at

TaskComment (task_comments table)
├── id (PK)
├── task_id (FK → tasks)
├── author_id (FK → employees)
├── comment
└── created_at

Project (projects table)
├── id (PK)
├── name
├── description
├── owner_id (FK → employees)
├── status
├── start_date
├── end_date
├── budget
└── created_at
```

#### **6. Communication & Collaboration**
```
ChatGroup (chat_groups table)
├── id (PK)
├── name
├── description
├── created_by (FK → employees)
├── is_private
└── created_at

ChatGroupMember (chat_group_members table)
├── id (PK)
├── group_id (FK → chat_groups)
├── employee_id (FK → employees)
└── joined_at

ChatMessage (chat_messages table)
├── id (PK)
├── group_id (FK → chat_groups)
├── sender_id (FK → employees)
├── content
├── message_type (text, file, image, call_invitation)
├── file_url
├── read_by (JSON array)
└── created_at

EmailMessage (email_messages table)
├── id (PK)
├── sender_id (FK → employees)
├── subject
├── body
├── category (general, announcement, resignation, etc.)
├── sent_at
└── created_at

EmailRecipient (email_recipients table)
├── id (PK)
├── email_id (FK → email_messages)
├── recipient_id (FK → employees)
├── read_at
└── status

Meeting (meetings table)
├── id (PK)
├── title
├── description
├── organizer_id (FK → employees)
├── start_time
├── end_time
├── location
├── status (scheduled, in_progress, completed, cancelled)
├── meeting_type
└── created_at

MeetingParticipant (meeting_participants table)
├── id (PK)
├── meeting_id (FK → meetings)
├── participant_id (FK → employees)
├── rsvp_status
└── joined_at

CallLog (call_logs table)
├── id (PK)
├── initiator_id (FK → employees)
├── recipient_id (FK → employees)
├── call_type (audio, video)
├── status (initiated, connected, ended, missed)
├── start_time
├── end_time
├── duration
└── created_at
```

#### **7. CRM (Customer Relationship Management)**
```
Lead (crm_leads table)
├── id (PK)
├── name
├── email
├── phone
├── company
├── source
├── status
├── assigned_to (FK → employees)
├── created_at
└── updated_at

Contact (crm_contacts table)
├── id (PK)
├── name
├── email
├── phone
├── company
├── position
├── address
├── assigned_to (FK → employees)
└── created_at

Supplier (crm_suppliers table)
├── id (PK)
├── name
├── email
├── phone
├── address
├── payment_terms
├── rating
└── created_at

CalendarEvent (crm_calendar_events table)
├── id (PK)
├── title
├── start_date
├── end_date
├── description
├── attendees (JSON)
├── status
└── created_at

Warehouse (crm_warehouses table)
├── id (PK)
├── name
├── location
├── capacity
├── manager_id (FK → employees)
└── created_at

Asset (crm_assets table)
├── id (PK)
├── name
├── asset_type
├── value
├── assigned_to (FK → employees)
├── status
└── created_at

Contract (crm_contracts table)
├── id (PK)
├── title
├── description
├── party_name
├── start_date
├── end_date
├── value
├── status
└── created_at

Invoice (crm_invoices table)
├── id (PK)
├── invoice_number
├── supplier_id (FK → suppliers)
├── issue_date
├── due_date
├── total_amount
├── status (draft, sent, paid, overdue)
├── created_at
└── updated_at

InvoiceItem (crm_invoice_items table)
├── id (PK)
├── invoice_id (FK → invoices)
├── description
├── quantity
├── unit_price
├── tax_rate
└── amount
```

#### **8. Inventory Management**
```
Inventory (inventory table)
├── id (PK)
├── item_name
├── category
├── sku
├── quantity
├── warehouse_id (FK → warehouses)
├── reorder_level
├── unit_price
└── last_updated

Transaction (inventory_transactions table)
├── id (PK)
├── inventory_id (FK → inventory)
├── transaction_type (in, out, adjustment)
├── quantity
├── reference_id
├── notes
└── created_at
```

#### **9. Billing & Expense Management**
```
BillingRequest (billing_requests table)
├── id (PK)
├── employee_id (FK → employees)
├── amount
├── status (pending, approved, rejected)
├── submitted_date
├── description
└── approved_by (FK → employees)

BillingRequestAttachment (billing_attachments table)
├── id (PK)
├── billing_id (FK → billing_requests)
├── file_url
├── file_type
└── uploaded_at
```

#### **10. Document & Asset Management**
```
Document (documents table)
├── id (PK)
├── title
├── description
├── file_url
├── uploaded_by (FK → employees)
├── category
├── access_level
└── created_at

UserPermission (user_permissions table)
├── id (PK)
├── user_id (FK → users)
├── resource
├── permission_type (read, write, delete, admin)
└── granted_at
```

#### **11. Audit & Logging**
```
AuditLog (audit_logs table)
├── id (PK)
├── user_id (FK → users)
├── action (LOGIN, LOGOUT, CREATE, UPDATE, DELETE, etc.)
├── resource
├── resource_id
├── details (JSON)
├── ip_address
├── user_agent
├── status (success, failure)
├── created_at
└── timestamp
```

### Database Indexes
```sql
-- Performance optimization indexes
CREATE INDEX idx_user_username ON users(username);
CREATE INDEX idx_user_email ON users(email);
CREATE INDEX idx_employee_user_id ON employees(user_id);
CREATE INDEX idx_employee_department_id ON employees(department_id);
CREATE INDEX idx_attendance_employee_date ON attendance(employee_id, date);
CREATE INDEX idx_leave_request_employee_date ON leave_requests(employee_id, start_date);
CREATE INDEX idx_task_status ON tasks(status);
CREATE INDEX idx_task_assigned_to ON tasks(assigned_to);
CREATE INDEX idx_chat_message_group ON chat_messages(group_id, created_at);
CREATE INDEX idx_audit_log_user_date ON audit_logs(user_id, created_at);
```

### Row-Level Security (RLS)
- Employees can only view their own data
- Managers can view their team's data
- Admins have unrestricted access
- All queries enforce RLS at database level

---

## ✨ FEATURES & MODULES

### 1. **Authentication & Authorization Module**
**Location**: `/auth/`
**Components**: `login.py`, `session.py`, `role_check.py`, `models.py`

**Features**:
- ✅ Multi-user login with username/password
- ✅ Password hashing using bcrypt (12 rounds)
- ✅ JWT-based session management
- ✅ Session tokens for concurrent login handling
- ✅ Access token generation (8-hour expiration)
- ✅ Refresh token management (7-day expiration)
- ✅ Failed login attempt tracking
- ✅ Account lockout after 5 failed attempts (15-minute duration)
- ✅ Last login timestamp tracking
- ✅ IP address logging
- ✅ Role-based access control (Admin, Employee)
- ✅ Permission matrix system
- ✅ Decorators for function-level access control

**Security Features**:
- Bcrypt password hashing with configurable rounds
- JWT token with HS256 algorithm
- Session token generation with secrets module
- Login attempt rate limiting
- Account lockout mechanism
- Audit logging for all authentication events

**UI Components**:
- Login screen with email/password fields
- Error messaging and validation
- Session state management
- "Remember me" functionality (optional)

---

### 2. **Employee Management Module**
**Location**: `/screens/employee_screen.py`, `employees_screen.py`, `/database/models.py`

**Features**:
- ✅ Complete employee profile management
- ✅ Employee directory with search and filtering
- ✅ Hierarchical organization tree
- ✅ Department assignment
- ✅ Position management
- ✅ Reporting manager assignment (hierarchical)
- ✅ Contact information management (official & personal)
- ✅ Profile photo upload and management
- ✅ Employment type tracking (Full-time, Part-time, Contract)
- ✅ Salary information management
- ✅ Bank account details
- ✅ Employee status management (Active, Inactive)
- ✅ Bulk employee operations
- ✅ Employee CSV export
- ✅ Employee performance tracking

**Data Fields**:
- First Name, Last Name, Date of Birth
- Gender (Male, Female, Other)
- Personal Email, Official Email, Phone
- Address and Contact Information
- Employee ID, Department, Position
- Manager/Reporting Officer
- Salary, Employment Type
- Bank Account Number and Branch
- Joining Date, Status
- Profile Photo URL

**UI/UX Features**:
- List view with sorting and filtering
- Detailed employee profile card
- Form-based data entry
- Image upload interface
- Hierarchical tree visualization
- Real-time search

---

### 3. **Attendance & Time Tracking Module**
**Location**: `/screens/attendance_screen.py`, `time_tracking_screen.py`, `/database/models.py`

**Features**:
- ✅ Daily attendance marking
- ✅ Check-in/Check-out time tracking
- ✅ Automatic duration calculation
- ✅ Attendance status tracking
  - Present
  - Absent
  - Late (with grace period configurable)
  - Half-day
  - On Leave
- ✅ Attendance history and reports
- ✅ Monthly attendance summary
- ✅ Absenteeism tracking
- ✅ Late arrival tracking
- ✅ Bulk attendance import
- ✅ Manual attendance correction (Admin only)
- ✅ Attendance patterns analysis

**Time Tracking Features**:
- Real-time check-in/check-out
- Daily time duration tracking
- Overtime calculation
- Work hour flexibility settings
- Time off tracking
- Break management
- Activity logging per employee

**Reports**:
- Daily attendance report
- Monthly attendance summary
- Employee-wise attendance
- Department-wise attendance
- Absenteeism report
- Late arrival trends

**UI/UX Features**:
- Calendar-based attendance view
- Quick attendance marking
- Attendance status badges with color coding
- Historical attendance chart
- Filter by date range, department, employee

---

### 4. **Leave Management Module**
**Location**: `/screens/leaves_screen.py`, `/database/models.py`

**Features**:
- ✅ Leave request creation and submission
- ✅ Multiple leave types
  - Annual Leave
  - Sick Leave
  - Personal Leave
  - Maternity Leave
  - Paternity Leave
  - Bereavement Leave
  - Unpaid Leave
- ✅ Leave balance tracking per employee
- ✅ Fiscal year-based leave allocation
- ✅ Leave approval workflow
- ✅ Manager approval with comments
- ✅ Rejection workflow with reason
- ✅ Leave history and tracking
- ✅ Remaining balance display
- ✅ Carry-forward rules configuration
- ✅ Maximum leave limit per type
- ✅ Leave cancellation
- ✅ Holiday calendar integration
- ✅ Leave conflict detection
- ✅ Bulk leave allocation for new employees

**Leave Types Configuration**:
- Max days per type
- Carry-forward percentage
- Approval requirements
- Documentation requirements

**Workflow**:
1. Employee submits leave request
2. Manager receives notification
3. Manager approves/rejects
4. System updates leave balance
5. Attendance auto-marked as "On Leave"

**Reports**:
- Leave utilization report
- Department leave status
- Employee leave history
- Planned vs. taken leaves
- Leave carry-forward report

**UI/UX Features**:
- Calendar view for leave selection
- Leave balance display card
- Request form with validations
- Approval/rejection interface
- Leave history timeline
- Color-coded leave types

---

### 5. **Project & Task Management Module**
**Location**: `/screens/projects_screen.py`, `tasks_screen.py`, `/database/models.py`

**Features**:
- ✅ Project creation and management
- ✅ Project assignment to teams
- ✅ Project status tracking
  - Planning
  - Active
  - On Hold
  - Completed
  - Cancelled
- ✅ Task creation within projects
- ✅ Task assignment to employees
- ✅ Task priority levels (Low, Medium, High, Urgent)
- ✅ Task status management
  - To Do
  - In Progress
  - Completed
  - Cancelled
- ✅ Task due date tracking
- ✅ Task comments and discussions
- ✅ Time estimation and tracking
- ✅ Task dependencies
- ✅ Progress percentage tracking
- ✅ Task filtering and search
- ✅ Project timeline view (Gantt chart)
- ✅ Workload distribution view
- ✅ Task history and audit trail
- ✅ Bulk task operations

**Project Information**:
- Project name, description, owner
- Start date, end date, deadline
- Budget allocation
- Team assignment
- Project status and progress

**Task Information**:
- Task title, description
- Assigned to (single or multiple employees)
- Priority level
- Status and progress percentage
- Estimated hours vs. actual hours
- Comments and attachments
- Subtasks support

**Reports**:
- Project status report
- Task completion report
- Employee workload distribution
- Project timeline view
- Burn-down chart
- Resource utilization

**UI/UX Features**:
- Card view for projects
- Kanban board for tasks (To Do → In Progress → Done)
- List view with sorting/filtering
- Timeline/Gantt chart
- Task detail modal
- Comment thread display
- Drag-and-drop task movement
- Progress bar visualization

---

### 6. **Team Management Module**
**Location**: `/screens/teams_screen.py`, `/database/models.py`

**Features**:
- ✅ Team creation and management
- ✅ Team member assignment
- ✅ Team lead designation
- ✅ Department association
- ✅ Team-level permissions
- ✅ Team communication channels
- ✅ Team performance metrics
- ✅ Team composition view
- ✅ Team member roles within team
- ✅ Team activity tracking

**Team Management**:
- Create, edit, delete teams
- Assign and remove members
- Designate team leads
- Associate with departments
- Set team visibility (Public/Private)

**Team Features**:
- Team chat/collaboration
- Team task dashboard
- Team member directory
- Team leave status
- Team attendance tracking
- Team performance metrics
- Team-level reporting

**UI/UX Features**:
- Team card with member count
- Team member list with roles
- Team hierarchy view
- Team activity feed
- Team settings panel

---

### 7. **Communication Module** (Chat, Email, Meetings)
**Location**: `/screens/chat_screen.py`, `mail_screen.py`, `meetings_screen.py`, `/database/models.py`

#### A. **Chat/Messaging System**
**Features**:
- ✅ Real-time chat messaging
- ✅ Group chat creation
- ✅ Private direct messages
- ✅ Message history (searchable)
- ✅ File sharing in chats
- ✅ Image sharing and preview
- ✅ Message read receipts
- ✅ Message status (sent, delivered, read)
- ✅ Chat notifications
- ✅ Typing indicators
- ✅ Message reactions/emojis
- ✅ Chat archiving
- ✅ Chat search functionality
- ✅ User online/offline status

**Message Types**:
- Text messages
- File attachments
- Image attachments
- Video call invitations
- Meeting invitations
- System messages (user joined, left, etc.)

**Chat Features**:
- Group chat with multiple participants
- Private one-on-one chats
- Chat rooms for departments/teams
- Chat notifications and @ mentions
- Rich text formatting

**UI/UX Features**:
- Chat list sidebar
- Message thread display
- Typing indicator animation
- Read receipt indicators
- Message timestamps
- User avatar display
- Online status indicator
- Search bar for chat history

#### B. **Email System**
**Features**:
- ✅ Email message composition
- ✅ Email recipients (individual/group)
- ✅ Email categories
  - General
  - Announcement
  - Resignation
  - Promotion
  - Meeting Request
  - HR Communication
- ✅ Email sending and receipt tracking
- ✅ Email read status
- ✅ Email history and archive
- ✅ Email templates
- ✅ Bulk email sending
- ✅ Email attachments
- ✅ Email scheduling (future)
- ✅ Email groups for distribution lists
- ✅ Email verification

**Email Features**:
- Compose email with rich text editor
- Email templates for common communications
- Distribution lists/groups
- Email delivery status tracking
- Read status notifications
- Email search and filtering
- Archive and delete functionality

**UI/UX Features**:
- Email composition form
- Email list view
- Email detail view
- Email read/unread indicator
- Recipient groups management
- Email template selector
- Attachment upload preview

#### C. **Meeting Management**
**Features**:
- ✅ Meeting scheduling
- ✅ Meeting type management (In-person, Virtual, Hybrid)
- ✅ Meeting organizer assignment
- ✅ Participant management
- ✅ Meeting invitations
- ✅ RSVP tracking
- ✅ Meeting status tracking
  - Scheduled
  - In Progress
  - Completed
  - Cancelled
- ✅ Meeting history and recordings
- ✅ Meeting agendas
- ✅ Meeting notes
- ✅ Recurring meetings
- ✅ Meeting reminders
- ✅ Virtual meeting links integration
- ✅ Meeting calendar integration
- ✅ Participant attendance tracking

**Meeting Information**:
- Meeting title, description, agenda
- Date, time, duration
- Location (for in-person)
- Video conference link (for virtual)
- Organizer and participants
- Meeting status and notes
- Attendee list with RSVP status

**Reports**:
- Meeting attendance report
- Meeting participation frequency
- Meeting duration analytics
- Participant engagement metrics

**UI/UX Features**:
- Meeting calendar view
- Meeting creation form
- Participant list with RSVP status
- Meeting detail modal
- Invitation notification
- Reminder notifications
- Color-coded meeting types
- Calendar integration display

#### D. **Call/Video Conferencing**
**Features**:
- ✅ Call initiation (audio/video)
- ✅ Call status tracking (initiated, connected, ended, missed)
- ✅ Call duration recording
- ✅ Call history log
- ✅ Missed call notifications
- ✅ Call types (audio, video)
- ✅ Conference call support
- ✅ Call recording capability

**Call Information**:
- Initiator and recipient
- Call type (audio/video)
- Start/end times
- Duration
- Status

---

### 8. **CRM (Customer Relationship Management) Module**
**Location**: `/screens/crm_screen.py`, `/database/models.py`, `/database/crm_repository.py`

**Features**:
- ✅ Unified tabbed CRM interface
- ✅ Comprehensive CRM data management

#### A. **Lead Management**
**Features**:
- ✅ Lead creation and tracking
- ✅ Lead assignment to employees
- ✅ Lead source tracking
- ✅ Lead status management
- ✅ Lead conversion to contact
- ✅ Lead scoring system
- ✅ Lead history and activity tracking
- ✅ Lead contact information
- ✅ Company association

#### B. **Contact Management**
**Features**:
- ✅ Contact information management
- ✅ Contact categorization
- ✅ Contact assignment
- ✅ Relationship tracking
- ✅ Contact communication history
- ✅ Company/organization mapping
- ✅ Contact details (email, phone, address)
- ✅ Contact interactions log

#### C. **Calendar & Events**
**Features**:
- ✅ Event scheduling
- ✅ Event status tracking (scheduled, in-progress, completed, cancelled)
- ✅ Event reminder notifications
- ✅ Event participant management
- ✅ Recurring events
- ✅ Event color coding by status
- ✅ Calendar view (day, week, month)
- ✅ Event search and filtering

#### D. **Vendor Management**
**Features**:
- ✅ Vendor profile management
- ✅ Vendor contact information
- ✅ Payment terms tracking
- ✅ Vendor rating system
- ✅ Vendor communication history
- ✅ Vendor contract tracking
- ✅ Vendor performance metrics

**Vendor Information**:
- Vendor name, contact details
- Address, payment terms
- Rating, status
- Associated contracts
- Communication history

#### E. **Warehouse Management**
**Features**:
- ✅ Warehouse location tracking
- ✅ Warehouse capacity management
- ✅ Manager assignment
- ✅ Inventory association
- ✅ Warehouse status monitoring
- ✅ Warehouse location mapping
- ✅ Storage capacity utilization

**Warehouse Information**:
- Warehouse name, location
- Capacity, available space
- Manager assignment
- Associated inventory items
- Status and operations

#### F. **Asset Management**
**Features**:
- ✅ Asset registration and tracking
- ✅ Asset assignment to employees
- ✅ Asset status management
- ✅ Asset depreciation tracking
- ✅ Asset location tracking
- ✅ Asset maintenance history
- ✅ Asset QR code generation
- ✅ Asset lifecycle management

**Asset Information**:
- Asset name, type, serial number
- Asset value, depreciation
- Assigned to (employee/location)
- Status (active, inactive, disposed)
- Purchase date, warranty expiration
- Maintenance records

#### G. **Contract Management**
**Features**:
- ✅ Contract creation and storage
- ✅ Contract parties tracking
- ✅ Contract date management (start, end)
- ✅ Contract value tracking
- ✅ Contract status monitoring
- ✅ Contract renewal alerts
- ✅ Contract document storage
- ✅ Milestone tracking
- ✅ Contract performance metrics

**Contract Information**:
- Contract title, description
- Parties involved (vendor, supplier)
- Start date, end date
- Contract value
- Terms and conditions
- Status (draft, active, expired, terminated)
- Associated documents

#### H. **Invoice Management**
**Features**:
- ✅ Invoice creation and issuance
- ✅ Invoice item line management
- ✅ Tax calculation
- ✅ Invoice status tracking (draft, sent, paid, overdue)
- ✅ Payment tracking
- ✅ Invoice due date management
- ✅ Invoice history
- ✅ Invoice search and filtering
- ✅ Invoice PDF generation
- ✅ Automated invoice reminders
- ✅ Payment history

**Invoice Information**:
- Invoice number, date
- Supplier/customer information
- Line items (description, qty, unit price, tax)
- Total amount, tax amount
- Due date, payment status
- Payment terms
- Associated documents

**Invoice Items**:
- Item description
- Quantity, unit price
- Tax rate, total amount
- Line item notes

**Reports**:
- Outstanding invoices
- Paid invoices
- Overdue invoices
- Supplier payment history
- Invoice aging report

**UI/UX Features**:
- Tabbed interface (Leads, Contacts, Calendar, Vendors, etc.)
- List view with search/filter
- Detail modal for each entity
- Form-based creation/editing
- Status color coding
- Timeline/activity view
- Bulk operations
- Data export functionality

---

### 9. **Inventory Management Module**
**Location**: `/screens/inventory_screen.py`, `/database/models.py`

**Features**:
- ✅ Inventory item management
- ✅ Stock level tracking
- ✅ Warehouse association
- ✅ SKU management
- ✅ Reorder level alerts
- ✅ Inventory transactions (in, out, adjustment)
- ✅ Unit price tracking
- ✅ Inventory valuation
- ✅ Low stock alerts
- ✅ Inventory history and audit
- ✅ Barcode/QR code support
- ✅ Multi-warehouse support
- ✅ Stock movement tracking
- ✅ Inventory forecasting

**Inventory Features**:
- Create and manage inventory items
- Track quantity by warehouse
- Monitor stock levels in real-time
- Generate low stock alerts
- Record inventory transactions
- Calculate inventory value
- Search and filter inventory

**Inventory Transactions**:
- Inbound (Purchases, Returns)
- Outbound (Sales, Transfers)
- Adjustments (Reconciliation, Damage)
- Transaction history with timestamps

**Reports**:
- Current inventory levels
- Low stock report
- Inventory value report
- Inventory movement report
- Warehouse-wise inventory
- ABC analysis

**UI/UX Features**:
- Inventory list with quantity display
- Stock level indicator/bar chart
- Quick quantity update
- Transaction history view
- Warehouse filter dropdown
- Search by item name/SKU
- Low stock alerts with color coding

---

### 10. **Billing & Expense Management Module**
**Location**: `/screens/transactions_screen.py`, `/database/models.py`

**Features**:
- ✅ Billing request creation
- ✅ Expense tracking
- ✅ Receipt/invoice attachment
- ✅ Billing request approval workflow
- ✅ Amount tracking
- ✅ Status management (pending, approved, rejected)
- ✅ Approval chain
- ✅ Reimbursement tracking
- ✅ Expense categorization
- ✅ Budget tracking
- ✅ Transaction history
- ✅ Payment status

**Billing Request Workflow**:
1. Employee submits billing request with amount and description
2. Receipts/attachments uploaded
3. Manager approval
4. Finance approval (if required)
5. Payment/reimbursement

**Expense Tracking**:
- Employee expenses
- Departmental expenses
- Project-based expenses
- Category-wise expenses
- Cost center tracking

**Reports**:
- Expense summary by employee
- Department-wise expenses
- Expense by category
- Pending reimbursements
- Budget utilization
- Expense trend analysis

**UI/UX Features**:
- Billing request form with file upload
- Transaction list with status
- Approval/rejection interface
- Receipt preview
- Status filter and search
- Amount summary card

---

### 11. **Announcement Module**
**Location**: `/screens/announcements_screen.py`, `/database/models.py`

**Features**:
- ✅ Announcement creation and publishing
- ✅ Target audience selection
- ✅ Announcement scheduling
- ✅ Announcement archiving
- ✅ Read status tracking
- ✅ Announcement search
- ✅ Category management
- ✅ Pin important announcements
- ✅ Announcement analytics
- ✅ Bulk announcements

**Announcement Features**:
- Create announcements for all employees
- Schedule announcement for future publishing
- Category-based announcements
- Priority level (high, normal, low)
- Read receipt tracking
- Announcement archive
- Announcement search

**UI/UX Features**:
- Announcement list view
- Detail view with full content
- Creation form
- Search and filter
- Read/unread indicator
- Pin/unpin functionality
- Archive management

---

### 12. **Organization & Structure Module**
**Location**: `/screens/organization_tree_screen.py`, `/screens/departments_screen.py`, `/screens/positions_screen.py`, `/database/models.py`

#### A. **Organization Tree**
**Features**:
- ✅ Hierarchical organization chart
- ✅ Reporting relationships visualization
- ✅ Department structure
- ✅ Role hierarchy
- ✅ Employee-manager mapping
- ✅ Interactive tree navigation
- ✅ Drill-down by department
- ✅ Organization overview

**UI/UX Features**:
- Tree structure visualization
- Expandable/collapsible nodes
- Employee card on click
- Department grouping
- Search by employee name
- Role color coding

#### B. **Department Management**
**Features**:
- ✅ Department creation and management
- ✅ Department head assignment
- ✅ Budget allocation per department
- ✅ Employee assignment to departments
- ✅ Department description
- ✅ Department status

**Department Information**:
- Department name
- Head/Manager
- Description
- Budget allocation
- Employee count
- Status

#### C. **Position/Job Titles**
**Features**:
- ✅ Position creation and management
- ✅ Salary range definition
- ✅ Department association
- ✅ Position description
- ✅ Required qualifications
- ✅ Reporting line definition

**Position Information**:
- Position title, description
- Department
- Salary range (min-max)
- Required skills/qualifications
- Reporting to position

**UI/UX Features**:
- Department list view
- Position dropdown in employee form
- Department-wise employee count
- Organizational hierarchy view

---

### 13. **Data Entry Module**
**Location**: `/screens/data_entry_screen.py`

**Features**:
- ✅ Bulk data import/export
- ✅ CSV file handling
- ✅ Data validation on import
- ✅ Error reporting
- ✅ Data reconciliation
- ✅ Batch operations
- ✅ Template download
- ✅ Import history

**Data Entry Features**:
- CSV import for employees
- CSV import for attendance
- CSV import for leave requests
- CSV export all data
- Template generation
- Validation rules
- Error report generation

**UI/UX Features**:
- File upload interface
- Progress indicator
- Error messages with line numbers
- Validation report
- Import history view
- Template download button

---

### 14. **Profile Management Module**
**Location**: `/screens/profile_screen.py`

**Features**:
- ✅ Personal profile view
- ✅ Profile information editing
- ✅ Profile photo upload
- ✅ Password change
- ✅ Contact information update
- ✅ Personal information update
- ✅ Notification preferences
- ✅ Theme preferences
- ✅ Language preferences

**Profile Features**:
- View personal information
- Edit basic profile details
- Upload profile picture
- Change password
- Update contact information
- Set notification preferences
- Theme selection (Light/Dark)
- Security settings

**UI/UX Features**:
- Profile card display
- Edit form modal
- Image upload with preview
- Password change form
- Settings panel
- Preference toggles

---

### 15. **Admin Panel & Settings**
**Location**: `/screens/admin_screen.py`, `/screens/settings_screen.py`

**Features**:
- ✅ User management (create, edit, delete, deactivate)
- ✅ Role management
- ✅ Permission configuration
- ✅ System configuration
- ✅ Database health monitoring
- ✅ Audit log viewing
- ✅ System statistics
- ✅ Backup management
- ✅ Error log monitoring
- ✅ Performance metrics
- ✅ License management
- ✅ API configuration

**Admin Features**:
- User account management
- Role and permission setup
- System configuration
- Audit trail review
- System health dashboard
- User activity monitoring
- Database management
- Backup and restore
- System logs
- Settings management

**Settings Features**:
- Company information
- Application settings
- Email configuration
- Notification settings
- API keys management
- Backup settings
- Security policies
- Theme configuration
- User preferences

**Admin Dashboard**:
- Total users/employees
- Active sessions
- System health status
- Recent activities
- System alerts
- Database statistics
- Storage usage

**UI/UX Features**:
- Admin sidebar navigation
- User management table
- Settings form
- Audit log table with filtering
- System status dashboard
- Configuration panels
- Toggle switches for features

---

### 16. **AI Assistant Module (Optional)**
**Location**: `/screens/vernikaai.py`

**Features**:
- ✅ AI-powered chatbot assistant
- ✅ Employee query resolution
- ✅ HR policy guidance
- ✅ Leave request assistance
- ✅ Performance feedback
- ✅ Career guidance
- ✅ Natural language processing
- ✅ Integration with company knowledge base

---

## 🎨 UI/UX DESIGN SYSTEM

### Design Philosophy
**Modern, Clean, Professional** - Material Design 3 inspired interface with enterprise-level polish

### Color Palette

#### Light Theme (Default)
```python
PRIMARY = "#2E86AB"                    # Teal Blue
SECONDARY = "#A23B72"                 # Pink/Magenta
TERTIARY = "#0B6E99"                  # Darker Teal
SUCCESS = "#28A745"                   # Green
WARNING = "#FFC107"                   # Amber
ERROR = "#DC3545"                     # Red
INFO = "#17A2B8"                       # Cyan

BACKGROUND = "#F8F9FA"                # Light Gray
SURFACE = "#FFFFFF"                   # White
TEXT_PRIMARY = "#1A1C1E"              # Dark Gray/Black
TEXT_SECONDARY = "#6C757D"            # Medium Gray
BORDER = "#E0E0E0"                    # Border Gray
```

#### Dark Theme
```python
DARK_PRIMARY = "#86D1FF"              # Light Blue
DARK_BACKGROUND = "#121212"           # Near Black
DARK_SURFACE = "#1E1E1E"              # Dark Gray
DARK_TEXT_PRIMARY = "#E2E2E6"         # Off White
DARK_TEXT_SECONDARY = "#B0B0B5"       # Medium Gray
```

### Typography
```
Font Family: System Default (Platform specific)

Headings:
- H1: 32px, Bold, Line Height 40px
- H2: 28px, Bold, Line Height 36px
- H3: 24px, Bold, Line Height 32px
- H4: 20px, Bold, Line Height 28px

Body:
- Large: 16px, Regular, Line Height 24px
- Medium: 14px, Regular, Line Height 20px
- Small: 12px, Regular, Line Height 16px

Caption: 11px, Regular, Line Height 16px
```

### Spacing System
```
xs: 4px
sm: 8px
md: 16px
lg: 24px
xl: 32px
xxl: 48px
```

### Component Library

#### Buttons
```python
# Primary Button (Main Actions)
ElevatedButton(
    text="Action",
    bgcolor="#2E86AB",
    color="white",
    width=120,
    height=48
)

# Secondary Button (Alternative Actions)
OutlinedButton(
    text="Cancel",
    bgcolor="transparent",
    color="#2E86AB"
)

# Text Button (Tertiary Actions)
TextButton(text="Learn More")

# Icon Button (Quick Actions)
IconButton(icon="delete", icon_color="#DC3545")
```

#### Cards
```python
# Data Card
Container(
    content=Column([
        Text("Title", size=16, weight="bold"),
        Text("Subtitle", size=12, color=TEXT_SECONDARY),
        Divider(),
        Row([...content...])
    ]),
    bgcolor=SURFACE,
    border_radius=12,
    padding=16,
    shadow=BoxShadow(blur_radius=4, spread_radius=2)
)
```

#### Forms
```python
# Text Input
TextField(
    label="Field Name",
    value="",
    border_color=BORDER,
    focused_border_color=PRIMARY,
    hint_text="Placeholder text"
)

# Select/Dropdown
Dropdown(
    options=[
        dropdown.Option("Option 1"),
        dropdown.Option("Option 2"),
    ]
)

# Checkbox
Checkbox(label="I agree", value=False)

# Radio Button
Radio(value="option1", label="Option 1")
```

#### Navigation
```
# Sidebar Navigation (Collapsed: 64px, Expanded: 260px)
Nav Items: Icon + Label + Indicator

# Top App Bar
Company Logo | Page Title | User Menu | Settings

# Tab Navigation
Horizontal tabs for main content sections
```

#### Lists
```python
# List Item
Row([
    Avatar(initials="JD"),
    Column([
        Text("John Doe", weight="bold"),
        Text("Employee", size=12, color=TEXT_SECONDARY)
    ]),
    Icon("chevron_right")
])
```

#### Dialogs & Modals
```python
# Confirmation Dialog
AlertDialog(
    title="Confirm Action",
    content="Are you sure?",
    actions=[
        TextButton("Cancel"),
        ElevatedButton("Confirm")
    ]
)
```

#### Status Badges
```python
# Status Chip
Container(
    content=Text("Active", color="white"),
    bgcolor=SUCCESS,
    border_radius=16,
    padding=Row([4, 8])
)
```

### Responsive Design
```python
# Mobile (< 600px)
- Single column layout
- Full-width cards
- Bottom navigation

# Tablet (600px - 1024px)
- Two-column layout
- Compact sidebar
- Adjusted spacing

# Desktop (> 1024px)
- Three-column layout
- Full sidebar
- Optimized spacing
```

### Accessibility Features
- ✅ Color contrast ratios > 4.5:1 (WCAG AA)
- ✅ Keyboard navigation support
- ✅ Screen reader compatibility
- ✅ Focus indicators visible
- ✅ Alternative text for images
- ✅ Font size scalability (min 12px)
- ✅ Touch target size minimum 44x44px

### Dark Mode Support
```python
# Dynamic theme switching
class ThemeManager:
    def switch_theme(self, mode: ThemeMode):
        # Update all color variables
        # Refresh all screens
        # Save preference
        pass
```

### Loading & Feedback States
```python
# Loading Spinner
ProgressRing(color=PRIMARY)

# Loading Skeleton
Container(height=20, bgcolor=SURFACE_VARIANT, border_radius=4)

# Success Notification
SnackBar(Text("Action successful", color="white"), bgcolor=SUCCESS)

# Error Notification
SnackBar(Text("Error occurred", color="white"), bgcolor=ERROR)
```

---

## 🔐 SECURITY ARCHITECTURE

### Authentication Security

#### Password Management
```python
# Algorithm: Bcrypt
# Rounds: 12 (configurable in config.py)
# Salt Length: Auto-generated per password
# Minimum Requirements:
#   - Length: 8 characters
#   - Uppercase: 1+ character
#   - Lowercase: 1+ character
#   - Digits: 1+ character
#   - Special Characters: Optional
```

#### Session Management
```python
# Session Token: Generated using secrets.token_urlsafe(32)
# Session Timeout: 30 minutes (configurable)
# Token Refresh: Via refresh token (7-day expiration)
# Concurrent Sessions: Limited per user (configurable)
# Token Storage: Secure session storage (not localStorage)
```

#### JWT Tokens
```python
# Algorithm: HS256 (HMAC SHA-256)
# Secret Key: Environment variable (SECRET_KEY)
# Claims:
#   - sub: username
#   - role: user role
#   - user_id: user ID
#   - exp: expiration time (8 hours)
#   - iat: issued at time
```

### Authorization & Access Control

#### Role-Based Access Control (RBAC)
```python
# Roles: Admin, Employee (extensible)
# Permissions: Stored as JSON in database
# Decorators: @require_role, @require_admin, @require_employee

# Permission Matrix:
User Management:
  - Admin: Create, Read, Update, Delete, Deactivate
  - Employee: Read Own Profile, Update Own Profile

Employee Management:
  - Admin: Full Access
  - Employee: Read Own Profile, Limited Team View

Attendance:
  - Admin: Create, Read, Update, All Records
  - Employee: Read Own Records

Leave:
  - Admin: Create, Read, Update, Delete, Approve
  - Employee: Create Own, Read Own, Cancel Own

Tasks:
  - Admin: Full Access
  - Employee: Read/Update Assigned, Create Own

Finance/Billing:
  - Admin: Full Access
  - Employee: Submit Own Requests

CRM:
  - Admin: Full Access
  - Employee: View/Edit Assigned Leads/Contacts
```

#### Row-Level Security (RLS)
```sql
-- Database-level access control
-- All SELECT queries filtered by user role
-- Employees see only:
  - Own profile and personal data
  - Own tasks and projects
  - Own leave requests and attendance
  - Public announcements
  - Assigned contacts/leads (CRM)
  - Own chat messages

-- Managers see:
  - Team members' data (department scope)
  - Team tasks and projects
  - Team attendance and leave

-- Admins see:
  - All data (no RLS filtering)
```

### Data Security

#### Encryption
```python
# In Transit:
#   - HTTPS/SSL for all network communication
#   - PostgreSQL SSL Mode: "require"
#   - JWT Token: Signed, Not Encrypted

# At Rest:
#   - Database: Supabase managed encryption
#   - Passwords: Bcrypt hashing
#   - Sensitive Fields: Consider encryption at app level
#   - File Storage: Supabase Storage with RLS
```

#### Data Privacy
```python
# Sensitive Fields (Bcrypt hashed):
#   - Passwords
#   - API keys
#   - Session tokens

# Masked Fields (in logs):
#   - Passwords: Never logged
#   - API Keys: Logged as [REDACTED]
#   - Phone Numbers: Logged as ****1234
#   - Email: Logged as j***@example.com
```

### Audit Logging

#### Audit Trail System
```python
# Logged Events:
#   - LOGIN (success/failure)
#   - LOGOUT
#   - CREATE (any record)
#   - UPDATE (any record)
#   - DELETE (any record)
#   - APPROVE (approvals)
#   - REJECT (rejections)
#   - ACCESS_DENIED
#   - PERMISSION_CHANGE
#   - ROLE_CHANGE

# Audit Log Fields:
#   - user_id: Who performed the action
#   - action: Type of action
#   - resource: What was affected
#   - resource_id: ID of affected resource
#   - details: Additional context (JSON)
#   - ip_address: Source IP
#   - user_agent: Browser/client info
#   - status: Success/Failure
#   - created_at: Timestamp
#   - timestamp: UTC timestamp

# Retention: Minimum 1 year (configurable)
# Access: Admin only
# Tampering Protection: Append-only log structure
```

### Security Best Practices Implemented

✅ **Input Validation**
- All user inputs validated before processing
- SQL injection prevention via SQLAlchemy ORM
- XSS prevention via Flet framework
- CSRF protection via token validation

✅ **Error Handling**
- Generic error messages to users
- Detailed errors logged on backend only
- No sensitive information in error messages
- Graceful error recovery

✅ **Session Security**
- Session tokens invalidated on logout
- Session timeout enforcement
- Failed login attempt tracking
- Account lockout mechanism (5 attempts, 15 min)

✅ **API Security**
- Request validation
- Rate limiting (if applicable)
- API key management
- Token expiration

✅ **Dependency Security**
- Regular dependency updates
- Security vulnerability scanning
- Minimal dependency footprint
- Version pinning in requirements.txt

---

## 📁 FILE STRUCTURE & COMPONENTS

### Directory Hierarchy
```
Vernika/
│
├── 📄 main.py                          # Application entry point
├── 📄 web_main.py                      # Web version entry point
├── 📄 config.py                        # Application configuration
├── 📄 requirements.txt                 # Python dependencies
├── 📄 README.md                        # Project documentation
├── 📄 Procfile                         # Deployment configuration
├── 📄 render.yaml                      # Render.com deployment
├── 📄 Spacefile                        # Deno Space deployment
│
├── 📁 auth/                            # Authentication Module
│   ├── __init__.py
│   ├── login.py                        # Login logic & authentication
│   ├── session.py                      # Session management
│   ├── role_check.py                   # RBAC decorators & checks
│   └── models.py                       # Auth-related models
│
├── 📁 database/                        # Database Layer
│   ├── __init__.py
│   ├── connection.py                   # Database connection setup
│   ├── models.py                       # SQLAlchemy ORM models
│   ├── operations.py                   # CRUD operations (main)
│   ├── operations.py.backup            # Backup of operations
│   ├── repositories.py                 # Data repository pattern
│   ├── crm_repository.py               # CRM-specific operations
│   ├── session_manager.py              # Database session management
│   ├── migrations.py                   # Database migrations
│   └── ...
│
├── 📁 screens/                         # UI Screens
│   ├── __init__.py
│   ├── login_screen.py                 # Login UI
│   ├── admin_screen.py                 # Admin dashboard
│   ├── employee_screen.py              # Employee dashboard
│   ├── dashboard_screen.py             # Main dashboard
│   ├── employees_screen.py             # Employee list/management
│   ├── departments_screen.py           # Department management
│   ├── positions_screen.py             # Position/Job titles
│   ├── attendance_screen.py            # Attendance tracking
│   ├── time_tracking_screen.py         # Time tracking UI
│   ├── leaves_screen.py                # Leave management
│   ├── projects_screen.py              # Project management
│   ├── tasks_screen.py                 # Task management
│   ├── teams_screen.py                 # Team management
│   ├── chat_screen.py                  # Chat/messaging
│   ├── mail_screen.py                  # Email management
│   ├── meetings_screen.py              # Meeting scheduling
│   ├── announcements_screen.py         # Announcements
│   ├── crm_screen.py                   # CRM (unified)
│   ├── inventory_screen.py             # Inventory management
│   ├── transactions_screen.py          # Billing/transactions
│   ├── data_entry_screen.py            # Data import/export
│   ├── profile_screen.py               # User profile
│   ├── settings_screen.py              # Settings/configuration
│   ├── organization_tree_screen.py     # Org chart
│   ├── vernikaai.py                    # AI Assistant
│   ├── base_screen.py                  # Base screen class
│   └── as.py                           # Assistant screen (?)
│
├── 📁 core/                            # Core Functionality
│   ├── __init__.py
│   ├── navigation.py                   # Screen navigation logic
│   ├── navigation_v2.py                # Navigation v2
│   ├── theme.py                        # Theme configuration
│   ├── theme_constants.py              # Theme constants
│   ├── colors_compat.py                # Color compatibility
│   ├── base_screen.py                  # Base screen utilities
│   ├── keyboard_shortcuts.py           # Keyboard shortcuts
│   ├── keyboard_shortcuts_v2.py        # Keyboard shortcuts v2
│   ├── flet_compat.py                  # Flet compatibility
│   └── ...
│
├── 📁 components/                      # Reusable UI Components
│   ├── __init__.py
│   ├── ui_components.py                # Common UI components
│   ├── forms.py                        # Form components
│   ├── dialogs.py                      # Dialog components
│   └── ...
│
├── 📁 utils/                           # Utility Functions
│   ├── __init__.py
│   ├── helpers.py                      # General helpers
│   ├── audit.py                        # Audit logging
│   ├── cache.py                        # Caching utilities
│   ├── db_helpers.py                   # Database helpers
│   ├── validators.py                   # Input validation
│   ├── notification_manager.py         # Notifications
│   ├── notifications.py                # Notification types
│   ├── excel_export.py                 # Excel export utilities
│   ├── supabase_storage.py             # Supabase storage integration
│   ├── screen_access.py                # Screen access control
│   ├── navigation_helpers.py           # Navigation utilities
│   ├── ui_helpers.py                   # UI utility functions
│   ├── session_fix.py                  # Session fixes
│   ├── overlay_cleanup.py              # Overlay management
│   ├── scroll_fix_helpers.py           # Scroll utilities
│   ├── google_sheets.py                # Google Sheets integration
│   ├── web_helpers.py                  # Web-specific helpers
│   ├── access_polling.py               # Access polling
│   ├── access_sync.py                  # Access synchronization
│   ├── constants.py                    # Application constants
│   └── ...
│
├── 📁 assets/                          # Static Assets
│   ├── logo/                           # Company logos
│   ├── billing_qr_codes/               # QR codes for billing
│   ├── profile_photos/                 # User profile photos
│   └── ...
│
├── 📁 scripts/                         # Database & Setup Scripts
│   ├── check_db_data.py                # Database data verification
│   ├── add_performance_indexes.py      # Index optimization
│   ├── apply_migration.py              # Migration runner
│   ├── create_bucket.py                # Supabase bucket setup
│   ├── enable_rls.py                   # RLS setup
│   ├── setup_storage_and_rls.py        # Storage and security setup
│   ├── create_crm_test_data.py         # Test data for CRM
│   ├── fix_crm_schema.py               # CRM schema fixes
│   ├── invoice_schema_fix.py           # Invoice schema fixes
│   ├── manage_migrations.py            # Migration management
│   ├── run_crm_migration.sh            # CRM migration script
│   ├── run_invoice_fix.py              # Invoice fix script
│   ├── complete_crm_fix.py             # Complete CRM fix
│   └── ...
│
├── 📁 supabase/                        # Supabase Configuration
│   ├── migrations/                     # SQL migrations
│   ├── config.json                     # Supabase config
│   └── ...
│
└── 📁 Vernika Application Clicks/      # QA/Testing (Clicks recorded)
    └── ...
```

### Key Component Descriptions

#### auth/login.py
- User authentication logic
- Password verification (bcrypt)
- JWT token generation
- Login attempt tracking
- Audit logging

#### auth/session.py
- Session state management
- Current user tracking
- Session token validation
- Session timeout handling

#### auth/role_check.py
- RBAC decorators
- Permission validation
- Feature access control
- Custom exceptions

#### database/connection.py
- SQLAlchemy engine setup
- Connection pooling configuration
- Session factory creation
- Connection health checks

#### database/models.py
- 20+ SQLAlchemy ORM models
- User, Employee, Department, Position
- Attendance, Leave, Task, Project
- Chat, Email, Meeting, CallLog
- CRM entities (Lead, Contact, etc.)
- Audit logs, Permissions
- Relationship definitions
- Constraints and indexes

#### database/operations.py
- 50+ CRUD operations
- Caching layer integration
- Query optimization
- Bulk operations
- Data validation

#### screens/admin_screen.py
- Admin dashboard
- User management interface
- System configuration
- Statistics and monitoring

#### screens/dashboard_screen.py
- Main application dashboard
- Quick statistics
- Recent activities
- Quick action buttons

#### components/ui_components.py
- Reusable UI building blocks
- Logo component
- Sidebar navigation
- Common containers and layouts

#### components/forms.py
- Form fields (date, time, etc.)
- Form validation
- Submit handlers

#### core/navigation.py
- Screen routing logic
- Navigation state management
- Back button handling
- Deep linking

#### core/theme.py
- Color constants
- Theme management
- Dark/Light mode support
- Typography constants

#### utils/notification_manager.py
- Toast notifications
- SnackBar messages
- Push notifications (if applicable)

#### utils/cache.py
- Query result caching
- Cache invalidation
- TTL management
- Thread-safe cache

#### utils/excel_export.py
- Excel file generation
- Data formatting
- Formula support
- Multi-sheet export

#### utils/supabase_storage.py
- File upload/download
- Storage bucket management
- Public URL generation
- Access control

---

## 🔗 API & INTEGRATION POINTS

### Internal APIs (Python Functions)

#### Database Operations API
```python
# User Operations
get_user_by_username(session, username) → User
get_user_by_id(session, user_id) → User
create_user(session, user_data) → User
update_user(session, user_id, user_data) → User
delete_user(session, user_id) → bool

# Employee Operations
get_all_employees(session) → List[Employee]
get_employee_by_id(session, employee_id) → Employee
create_employee(session, employee_data) → Employee
get_employee_org_tree(session) → Dict
get_team_members(session, team_id) → List[Employee]

# Attendance Operations
get_attendance_records(session, employee_id, start_date, end_date) → List[Attendance]
mark_attendance(session, employee_id, date, status) → Attendance
get_attendance_stats(session, employee_id) → Dict

# Leave Operations
submit_leave_request(session, employee_id, leave_data) → LeaveRequest
get_leave_balance(session, employee_id, year) → LeaveBalance
approve_leave_request(session, request_id, manager_id) → LeaveRequest
calculate_leave_days(start_date, end_date, holidays) → int

# Task Operations
create_task(session, project_id, task_data) → Task
update_task_status(session, task_id, status) → Task
get_employee_tasks(session, employee_id) → List[Task]
get_project_tasks(session, project_id) → List[Task]

# CRM Operations
get_leads(session, filters) → List[Lead]
create_lead(session, lead_data) → Lead
convert_lead_to_contact(session, lead_id) → Contact
get_invoices(session, status) → List[Invoice]
create_invoice(session, invoice_data) → Invoice

# Audit Operations
create_audit_log(session, user_id, action, details) → AuditLog
get_audit_logs(session, filters) → List[AuditLog]
```

#### Authentication API
```python
authenticate_user(username, password) → LoginResult
create_access_token(data, expires_delta) → str
verify_token(token) → Dict
check_password(password, hash) → bool
hash_password(password) → str
```

#### Notification API
```python
send_notification(user_id, title, message) → bool
show_snackbar(page, message, status) → None
show_dialog(page, title, content, actions) → None
show_toast(message, duration) → None
```

#### File Management API
```python
upload_file(file_path, bucket, destination) → str
download_file(url, destination) → bool
delete_file(bucket, file_path) → bool
get_file_url(bucket, file_path) → str
```

### External API Integrations (Future)

#### Email Service
```
Provider: Sendgrid/SMTP
Endpoints:
  - Send email
  - Send bulk emails
  - Email templates
  - Email verification
```

#### Video Conference
```
Provider: Google Meet/Zoom API
Endpoints:
  - Create meeting
  - Get meeting link
  - Send invitations
  - Recording management
```

#### Storage Service
```
Provider: Supabase Storage
Endpoints:
  - Upload file
  - Download file
  - Delete file
  - List files
  - Generate signed URL
```

#### Google Sheets Integration
```
Provider: Google Sheets API
Endpoints:
  - Read sheet data
  - Append data
  - Update cells
  - Delete rows
```

---

## 🚀 DEPLOYMENT & SCALABILITY

### Deployment Platforms

#### 1. **Render.com** (Current)
**Configuration File**: `render.yaml`
```yaml
services:
  - name: vernika-app
    type: web
    runtime: python
    buildCommand: pip install -r requirements.txt
    startCommand: python main.py
    envVars:
      - key: DATABASE_URL
        scope: run
```

#### 2. **Deno Deploy** (Alternative)
**Configuration File**: `Spacefile`
```spacefile
services:
  api:
    src: ./main.py
    runtime: python3.11
```

### Scalability Considerations

#### Database Scalability
```python
# Connection Pooling
DB_POOL_SIZE = 20              # Connections in pool
DB_MAX_OVERFLOW = 40           # Extra connections
DB_POOL_RECYCLE = 1800         # Connection timeout
DB_POOL_TIMEOUT = 30           # Acquire timeout

# Suitable for 200+ concurrent users
# For higher load: Consider read replicas, caching layers
```

#### Application Scaling Strategies
1. **Horizontal Scaling**
   - Multiple app instances behind load balancer
   - Shared PostgreSQL database
   - Distributed session management

2. **Caching Layer**
   - Query result caching (30s TTL)
   - Employee directory caching
   - Permission caching
   - Redis (optional for production)

3. **Database Optimization**
   - Performance indexes on frequently queried columns
   - Query optimization
   - Connection pooling
   - Read replicas for reporting

#### Load Testing
```
Expected Capacity:
- Concurrent Users: 200+
- Database Connections: 60 (20 + 40 overflow)
- Response Time: < 500ms for typical queries
- Throughput: 1000+ requests/minute
```

### Environment Configuration

#### Development
```
DATABASE_URL: Local or dev PostgreSQL
DEBUG: true
LOG_LEVEL: DEBUG
THEME_MODE: light
```

#### Staging
```
DATABASE_URL: Staging PostgreSQL
DEBUG: false
LOG_LEVEL: INFO
THEME_MODE: light
BCRYPT_ROUNDS: 10 (faster for testing)
```

#### Production
```
DATABASE_URL: Production PostgreSQL (Supabase)
DEBUG: false
LOG_LEVEL: WARNING
THEME_MODE: light (user configurable)
BCRYPT_ROUNDS: 12 (secure)
SSL_MODE: require
```

### Backup & Disaster Recovery

#### Database Backup Strategy
- Daily automated backups (Supabase managed)
- Point-in-time recovery
- Retention: 30 days minimum
- Testing: Weekly restore drills

#### Data Export
```python
# CSV export of all entities
export_employees_csv()
export_attendance_csv()
export_leave_requests_csv()
export_tasks_csv()
export_financial_data_csv()
```

#### Recovery Procedures
1. Database restore from backup
2. File storage recovery
3. Session invalidation
4. Audit log verification
5. User notification

---

## 🔄 DEVELOPMENT WORKFLOW

### Version Control
- Repository: Git (GitHub/GitLab)
- Branch Strategy: Git Flow
  - `main`: Production ready
  - `develop`: Development branch
  - `feature/*`: Feature branches
  - `hotfix/*`: Critical fixes
  - `release/*`: Release preparation

### Code Quality Standards

#### Formatting
```bash
black . --line-length 100
```

#### Linting
```bash
flake8 . --max-line-length 100 --ignore E501,W503
```

#### Type Checking
```bash
mypy . --ignore-missing-imports
```

#### Testing
```bash
pytest tests/ --cov=. --cov-report=html
```

### Development Process
1. Create feature branch from `develop`
2. Make changes following code standards
3. Add tests for new functionality
4. Run local testing and linting
5. Create pull request with description
6. Code review by team
7. Merge to `develop` after approval
8. Release management from `develop` to `main`

### Dependencies Management
```
Production:
- Python 3.8+
- flet >= 0.25.0
- sqlalchemy >= 2.0.0
- psycopg2-binary >= 2.9.0
- bcrypt >= 4.0.0
- pydantic >= 2.0.0

Development:
- pytest >= 7.0.0
- black >= 23.0.0
- flake8 >= 6.0.0
- mypy >= 1.0.0

Optional:
- reportlab >= 4.0.0 (PDF)
- openpyxl >= 3.1.0 (Excel)
```

### Debugging & Logging

#### Logging Configuration
```python
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# Per-module logging
logger = logging.getLogger(__name__)
logger.debug("Debug message")
logger.info("Info message")
logger.warning("Warning message")
logger.error("Error message")
logger.critical("Critical message")
```

#### Performance Monitoring
- Query execution time tracking
- Cache hit/miss rates
- Screen load times
- Memory usage monitoring

---

## 📊 ARCHITECTURE SUMMARY DIAGRAM

```
┌─────────────────────────────────────────────────────────────┐
│                    VERNIKA ECOSYSTEM                         │
└─────────────────────────────────────────────────────────────┘

                        ┌──────────────┐
                        │ Desktop User │
                        │ (Flet App)   │
                        └──────┬───────┘
                               │
                    ┌──────────┴──────────┐
                    │   Presentation    │
                    │   Layer (Screens) │
                    └──────────┬────────┘
                               │
        ┌──────────────────────┼──────────────────────┐
        │                      │                      │
    ┌─────────┐          ┌──────────┐          ┌──────────┐
    │  Auth   │          │  Core    │          │Components│
    │ Module  │          │ Module   │          │ Module   │
    └────┬────┘          └────┬─────┘          └────┬─────┘
         │                    │                      │
         └────────┬───────────┴──────────────────────┘
                  │
         ┌────────▼─────────┐
         │  Business Logic  │
         │     & Utils      │
         └────────┬─────────┘
                  │
         ┌────────▼─────────┐
         │   Data Access    │
         │  (Operations,    │
         │  Repositories)   │
         └────────┬─────────┘
                  │
         ┌────────▼─────────┐
         │   Database       │
         │   Models &       │
         │   Connections    │
         └────────┬─────────┘
                  │
         ┌────────▼──────────────┐
         │   PostgreSQL via      │
         │   Supabase Cloud      │
         └───────────────────────┘
                  │
    ┌─────────────┼─────────────┐
    │             │             │
┌───▼──┐    ┌────▼────┐    ┌──▼───┐
│Data  │    │Storage  │    │Auth  │
│Base  │    │(Bucket) │    │      │
└──────┘    └─────────┘    └──────┘
```

---

## 🎯 SUMMARY

**Vernika** is a comprehensive, enterprise-grade HR management system built with:
- **Modern Architecture**: Layered design with clear separation of concerns
- **Secure Authentication**: Multi-user login with JWT and bcrypt
- **Rich Features**: 16+ modules covering all HR operations
- **Professional UI**: Material Design 3 inspired with light/dark themes
- **Scalable Database**: PostgreSQL with RLS for 200+ users
- **Production-Ready**: Deployment configuration for Render, Deno Space
- **Maintainable Code**: Clear structure, logging, audit trails

This document provides complete understanding of Vernika's architecture, features, and technical implementation for developers, stakeholders, and users.

---

**Last Updated**: 2024
**Document Version**: 1.0
**Application Version**: 1.0.0

