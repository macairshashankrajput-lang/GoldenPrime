"""
Vernika - Database Models for New Features
Additions to database/models.py
"""

from datetime import datetime, date
from typing import Optional, List
import enum
from sqlalchemy import (
    Column, Integer, String, Boolean, DateTime, Date, Text,
    ForeignKey, Float, Enum, JSON, UniqueConstraint, Index,
    Time, LargeBinary, Numeric
)
from sqlalchemy.orm import relationship
from database.connection import Base


# ==================== NEW ENUMS ====================

class AUXStatus(str, enum.Enum):
    """Employee activity status"""
    ON_PRODUCTION = "on_production"      # 🟢 Productive
    FREE_IDLE = "free_idle"              # 🔵 Idle
    IN_MEETING = "in_meeting"            # 🟣 Productive
    COACHING_TRAINING = "coaching"       # 🟡 Non-Production
    ON_BREAK = "on_break"                # 🟠 Non-Production
    ON_LUNCH = "on_lunch"                # 🔴 Non-Production
    LOG_OUT = "log_out"                  # ⚪ Offline


class CallType(str, enum.Enum):
    """Call type"""
    AUDIO = "audio"
    VIDEO = "video"
    HUDDLE = "huddle"


class CallStatus(str, enum.Enum):
    """Call status"""
    INITIATED = "initiated"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    ENDED = "ended"
    MISSED = "missed"
    REJECTED = "rejected"


class OnboardingStatus(str, enum.Enum):
    """Onboarding status"""
    NOT_STARTED = "not_started"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    ON_HOLD = "on_hold"


class DocumentSignatureStatus(str, enum.Enum):
    """Document signature status"""
    PENDING = "pending"
    SIGNED = "signed"
    REJECTED = "rejected"


class InvoiceRecurrenceType(str, enum.Enum):
    """Invoice recurrence"""
    ONE_TIME = "one_time"
    MONTHLY = "monthly"
    QUARTERLY = "quarterly"
    YEARLY = "yearly"


class PerformanceReviewCycle(str, enum.Enum):
    """Review cycle type"""
    QUARTERLY = "quarterly"
    SEMI_ANNUAL = "semi_annual"
    ANNUAL = "annual"
    CONTINUOUS = "continuous"


class OKRStatus(str, enum.Enum):
    """OKR status"""
    NOT_STARTED = "not_started"
    IN_PROGRESS = "in_progress"
    ON_TRACK = "on_track"
    AT_RISK = "at_risk"
    COMPLETED = "completed"
    ABANDONED = "abandoned"


class ExpenseApprovalStatus(str, enum.Enum):
    """Expense approval status"""
    SUBMITTED = "submitted"
    TIER1_PENDING = "tier1_pending"
    TIER1_APPROVED = "tier1_approved"
    TIER1_REJECTED = "tier1_rejected"
    TIER2_PENDING = "tier2_pending"
    TIER2_APPROVED = "tier2_approved"
    TIER2_REJECTED = "tier2_rejected"
    APPROVED = "approved"
    REJECTED = "rejected"
    PAID = "paid"


# ==================== NEW MODELS ====================

class AUXLog(Base):
    """Employee activity status history"""
    __tablename__ = "aux_logs"

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.id"), nullable=False)
    status = Column(Enum(AUXStatus), nullable=False)
    start_time = Column(DateTime, default=datetime.utcnow)
    end_time = Column(DateTime, nullable=True)
    duration_seconds = Column(Integer, default=0)
    notes = Column(Text, nullable=True)
    # Auto-switched by inactivity
    auto_switched = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    employee = relationship("Employee", backref="aux_logs")


class EnhancedCallLog(Base):
    """Enhanced call logging with local mock"""
    __tablename__ = "enhanced_call_logs"

    id = Column(Integer, primary_key=True, index=True)
    initiator_id = Column(Integer, ForeignKey("employees.id"), nullable=False)
    recipient_id = Column(Integer, ForeignKey("employees.id"), nullable=True)
    call_type = Column(Enum(CallType), nullable=False)
    status = Column(Enum(CallStatus), default=CallStatus.INITIATED)
    start_time = Column(DateTime, default=datetime.utcnow)
    end_time = Column(DateTime, nullable=True)
    duration_seconds = Column(Integer, default=0)

    # Local mock data (no actual WebRTC)
    is_muted = Column(Boolean, default=False)
    video_enabled = Column(Boolean, default=False)
    recording_available = Column(Boolean, default=False)
    transcript = Column(Text, nullable=True)

    # Participants JSON for group calls
    participants = Column(JSON, default=list)  # List of employee IDs
    notes = Column(Text, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)

    initiator = relationship("Employee", foreign_keys=[
                             initiator_id], backref="initiated_calls")
    recipient = relationship("Employee", foreign_keys=[
                             recipient_id], backref="received_calls")


class GeofenceZone(Base):
    """Geofence verification zones"""
    __tablename__ = "geofence_zones"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    location_latitude = Column(Float)
    location_longitude = Column(Float)
    radius_meters = Column(Integer, default=100)
    verification_code = Column(String(50), unique=True)  # QR code alternative
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class DeviceTrust(Base):
    """Device trust and session management"""
    __tablename__ = "device_trust"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    device_name = Column(String(100))
    device_type = Column(String(50))  # mobile, desktop, tablet
    device_id = Column(String(200), unique=True)
    trust_token = Column(String(255), unique=True)
    is_trusted = Column(Boolean, default=False)
    last_used = Column(DateTime)
    ip_address = Column(String(50))
    user_agent = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", backref="devices")


class ShiftManagement(Base):
    """Shift and working hours configuration"""
    __tablename__ = "shift_management"

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.id"), nullable=False)
    shift_name = Column(String(100))  # Morning, Evening, Night
    start_time = Column(Time, nullable=False)
    end_time = Column(Time, nullable=False)
    break_duration_minutes = Column(Integer, default=60)
    grace_period_minutes = Column(Integer, default=5)
    is_flexible = Column(Boolean, default=False)
    effective_from = Column(Date)
    effective_to = Column(Date, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    employee = relationship("Employee", backref="shifts")


class OnboardingTask(Base):
    """Digital onboarding checklist"""
    __tablename__ = "onboarding_tasks"

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.id"), nullable=False)
    task_name = Column(String(200), nullable=False)
    description = Column(Text)
    category = Column(String(50))  # HR, IT, Facilities, etc.
    assigned_to = Column(Integer, ForeignKey(
        "employees.id"))  # Who performs the task
    status = Column(String(20), default="pending")  # pending, completed
    due_date = Column(Date)
    completed_date = Column(Date, nullable=True)
    notes = Column(Text)
    order_index = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

    employee = relationship("Employee", foreign_keys=[
                            employee_id], backref="onboarding_tasks")
    assigned_person = relationship("Employee", foreign_keys=[assigned_to])


class OnboardingDocument(Base):
    """Documents for onboarding"""
    __tablename__ = "onboarding_documents"

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.id"), nullable=False)
    document_name = Column(String(200), nullable=False)
    document_type = Column(String(50))  # contract, nda, policy, etc.
    file_path = Column(String(500))  # Local file path
    file_size = Column(Integer)
    signature_status = Column(
        Enum(DocumentSignatureStatus), default=DocumentSignatureStatus.PENDING)
    signed_by = Column(Integer, ForeignKey("employees.id"))
    signature_image = Column(LargeBinary)  # Signature canvas image
    signed_date = Column(DateTime, nullable=True)
    uploaded_at = Column(DateTime, default=datetime.utcnow)

    employee = relationship("Employee", foreign_keys=[
                            employee_id], backref="onboarding_documents")
    signer = relationship("Employee", foreign_keys=[signed_by])


class InvoiceTemplate(Base):
    """Invoice templates for quick creation"""
    __tablename__ = "invoice_templates"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    description = Column(Text)
    supplier_id = Column(Integer, ForeignKey(
        "crm_suppliers.id"), nullable=True)
    template_data = Column(JSON)  # Stored template structure
    is_active = Column(Boolean, default=True)
    created_by = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.utcnow)


class EnhancedInvoice(Base):
    """Enhanced invoice with recurrence support"""
    __tablename__ = "enhanced_invoices"

    id = Column(Integer, primary_key=True, index=True)
    invoice_number = Column(String(50), unique=True)
    supplier_id = Column(Integer, ForeignKey("crm_suppliers.id"))
    issue_date = Column(Date, nullable=False)
    due_date = Column(Date, nullable=False)

    # Recurrence setup
    recurrence_type = Column(Enum(InvoiceRecurrenceType),
                             default=InvoiceRecurrenceType.ONE_TIME)
    next_recurrence_date = Column(Date, nullable=True)
    recurrence_end_date = Column(Date, nullable=True)

    # Amount and tax
    subtotal = Column(Numeric(12, 2))
    tax_rate = Column(Float, default=0.0)  # Tax percentage
    tax_amount = Column(Numeric(12, 2))
    total_amount = Column(Numeric(12, 2))

    status = Column(String(20), default="draft")  # draft, sent, paid, overdue
    paid_date = Column(Date, nullable=True)
    notes = Column(Text)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)

    supplier = relationship("Supplier")


class EmailTemplate(Base):
    """Email templates library"""
    __tablename__ = "email_templates"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    category = Column(String(50))  # announcement, resignation, etc.
    subject = Column(String(200))
    body = Column(Text, nullable=False)
    # List of template variables {{name}}, etc.
    variables = Column(JSON, default=list)
    is_active = Column(Boolean, default=True)
    created_by = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.utcnow)


class ScheduledEmail(Base):
    """Scheduled email sending"""
    __tablename__ = "scheduled_emails"

    id = Column(Integer, primary_key=True, index=True)
    sender_id = Column(Integer, ForeignKey("users.id"))
    recipients = Column(JSON)  # List of recipient emails
    subject = Column(String(200))
    body = Column(Text)
    scheduled_time = Column(DateTime)
    sent_time = Column(DateTime, nullable=True)
    status = Column(String(20), default="scheduled")  # scheduled, sent, failed
    read_receipts = Column(JSON, default=dict)  # {email: read_status}
    created_at = Column(DateTime, default=datetime.utcnow)


class ExpenseApprovalConfig(Base):
    """Configure approval routing for expenses"""
    __tablename__ = "expense_approval_config"

    id = Column(Integer, primary_key=True, index=True)
    department_id = Column(Integer, ForeignKey("departments.id"))

    # Approval tiers
    # Amount requiring tier1 approval
    tier1_amount_limit = Column(Numeric(12, 2))
    tier1_approver_id = Column(Integer, ForeignKey("employees.id"))

    # Amount requiring tier2 approval
    tier2_amount_limit = Column(Numeric(12, 2))
    tier2_approver_id = Column(Integer, ForeignKey("employees.id"))

    # Budget
    monthly_budget = Column(Numeric(12, 2))
    budget_fiscal_year = Column(Integer)

    created_at = Column(DateTime, default=datetime.utcnow)

    department = relationship("Department")
    tier1_approver = relationship("Employee", foreign_keys=[tier1_approver_id])
    tier2_approver = relationship("Employee", foreign_keys=[tier2_approver_id])


class EnhancedExpense(Base):
    """Enhanced expense with approval routing"""
    __tablename__ = "enhanced_expenses"

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.id"))
    amount = Column(Numeric(12, 2))
    category = Column(String(50))  # travel, meals, office_supplies, etc.
    cost_center = Column(String(50))
    description = Column(Text)

    # Approval workflow
    status = Column(Enum(ExpenseApprovalStatus),
                    default=ExpenseApprovalStatus.SUBMITTED)
    tier1_approver_id = Column(Integer, ForeignKey("employees.id"))
    tier1_approved_date = Column(DateTime, nullable=True)
    tier1_notes = Column(Text)

    tier2_approver_id = Column(Integer, ForeignKey("employees.id"))
    tier2_approved_date = Column(DateTime, nullable=True)
    tier2_notes = Column(Text)

    receipt_path = Column(String(500))
    submitted_date = Column(DateTime, default=datetime.utcnow)
    paid_date = Column(DateTime, nullable=True)

    employee = relationship("Employee", foreign_keys=[employee_id])
    tier1_approver = relationship("Employee", foreign_keys=[tier1_approver_id])
    tier2_approver = relationship("Employee", foreign_keys=[tier2_approver_id])


class OKRTracking(Base):
    """OKR (Objectives and Key Results) tracking"""
    __tablename__ = "okr_tracking"

    id = Column(Integer, primary_key=True, index=True)

    # OKR hierarchy
    level = Column(String(20))  # company, team, individual
    level_id = Column(Integer)  # company_id, team_id, employee_id

    objective = Column(String(300), nullable=False)
    key_result_1 = Column(String(300))
    key_result_2 = Column(String(300))
    key_result_3 = Column(String(300))

    # Progress tracking
    kr1_current_value = Column(Float, default=0)
    kr1_target_value = Column(Float)
    kr1_unit = Column(String(50))  # %, count, currency, etc.

    kr2_current_value = Column(Float, default=0)
    kr2_target_value = Column(Float)
    kr2_unit = Column(String(50))

    kr3_current_value = Column(Float, default=0)
    kr3_target_value = Column(Float)
    kr3_unit = Column(String(50))

    # Metadata
    status = Column(Enum(OKRStatus), default=OKRStatus.NOT_STARTED)
    confidence_level = Column(Integer, default=0)  # 0-100
    owner_id = Column(Integer, ForeignKey("employees.id"))
    start_date = Column(Date)
    end_date = Column(Date)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)

    owner = relationship("Employee")


class PerformanceReview(Base):
    """Performance review cycles"""
    __tablename__ = "performance_reviews"

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.id"))
    reviewer_id = Column(Integer, ForeignKey("employees.id"))

    review_cycle = Column(Enum(PerformanceReviewCycle))
    fiscal_year = Column(Integer)

    # Review scores
    technical_skills = Column(Integer)  # 1-5
    communication = Column(Integer)     # 1-5
    teamwork = Column(Integer)          # 1-5
    leadership = Column(Integer)        # 1-5
    initiative = Column(Integer)        # 1-5

    overall_rating = Column(Float)  # Average of above

    # Feedback
    strengths = Column(Text)
    areas_for_improvement = Column(Text)
    goals_for_next_period = Column(Text)
    manager_comments = Column(Text)

    review_date = Column(Date)
    reviewed_date = Column(DateTime, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)

    employee = relationship("Employee", foreign_keys=[
                            employee_id], backref="reviews_received")
    reviewer = relationship("Employee", foreign_keys=[
                            reviewer_id], backref="reviews_given")


class FeedbackEntry(Base):
    """360-degree feedback"""
    __tablename__ = "feedback_entries"

    id = Column(Integer, primary_key=True, index=True)
    review_id = Column(Integer, ForeignKey("performance_reviews.id"))
    from_employee_id = Column(Integer, ForeignKey("employees.id"))
    feedback_text = Column(Text)
    rating = Column(Integer)  # 1-5

    created_at = Column(DateTime, default=datetime.utcnow)


class AIFAQEntry(Base):
    """Local AI FAQ knowledge base"""
    __tablename__ = "ai_faq_entries"

    id = Column(Integer, primary_key=True, index=True)
    question = Column(String(500), nullable=False)
    answer = Column(Text, nullable=False)
    category = Column(String(100))  # HR policies, leave, etc.
    keywords = Column(JSON)  # For keyword matching
    source = Column(String(200))  # Policy document, manual page
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class AsyncVideoEntry(Base):
    """Async video recording metadata"""
    __tablename__ = "async_videos"

    id = Column(Integer, primary_key=True, index=True)
    task_id = Column(Integer, ForeignKey("tasks.id"), nullable=True)
    comment_id = Column(Integer, nullable=True)

    creator_id = Column(Integer, ForeignKey("employees.id"))
    title = Column(String(200))
    description = Column(Text)

    # File info
    file_path = Column(String(500))
    file_size = Column(Integer)
    duration_seconds = Column(Integer)
    thumbnail_path = Column(String(500))

    # Metadata
    is_screen_recording = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    creator = relationship("Employee")


class AsyncAnnotation(Base):
    """Annotations on async videos"""
    __tablename__ = "async_annotations"

    id = Column(Integer, primary_key=True, index=True)
    video_id = Column(Integer, ForeignKey("async_videos.id"))
    author_id = Column(Integer, ForeignKey("employees.id"))

    timestamp_seconds = Column(Integer)  # When in video
    comment = Column(Text)
    is_resolved = Column(Boolean, default=False)

    created_at = Column(DateTime, default=datetime.utcnow)


class DailyStandupEntry(Base):
    """Daily standup bot entries"""
    __tablename__ = "daily_standups"

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.id"))
    date = Column(Date, default=date.today)

    yesterday_accomplishments = Column(Text)
    today_plans = Column(Text)
    blockers = Column(Text)

    submitted_time = Column(DateTime, default=datetime.utcnow)
    team_id = Column(Integer, ForeignKey("teams.id"))


class PayrollConfig(Base):
    """Payroll configuration"""
    __tablename__ = "payroll_config"

    id = Column(Integer, primary_key=True, index=True)

    # Currency
    base_currency = Column(String(3), default="USD")  # ISO 4217
    exchange_rates = Column(JSON)  # {currency: rate}

    # Tax
    tax_rate = Column(Float, default=0.0)
    tax_type = Column(String(50))  # VAT, GST, Income Tax

    # Deductions
    provident_fund_rate = Column(Float, default=0.0)
    health_insurance_rate = Column(Float, default=0.0)

    # Payroll period
    payroll_period = Column(String(20))  # monthly, bi-weekly
    payroll_day = Column(Integer, default=1)  # Day of month

    created_at = Column(DateTime, default=datetime.utcnow)


class SalarySlip(Base):
    """Generated salary slips"""
    __tablename__ = "salary_slips"

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.id"))
    fiscal_month = Column(Integer)  # 1-12
    fiscal_year = Column(Integer)

    # Gross
    base_salary = Column(Numeric(12, 2))
    allowances = Column(Numeric(12, 2), default=0)
    gross_salary = Column(Numeric(12, 2))

    # Deductions
    provident_fund = Column(Numeric(12, 2), default=0)
    health_insurance = Column(Numeric(12, 2), default=0)
    tax_deduction = Column(Numeric(12, 2), default=0)
    total_deductions = Column(Numeric(12, 2))

    # Net
    net_salary = Column(Numeric(12, 2))

    currency = Column(String(3), default="USD")
    generated_date = Column(DateTime, default=datetime.utcnow)

    employee = relationship("Employee")
