"""
Email Templates Screen - Template Management and Scheduling
Create, edit, and schedule templated emails
"""

import flet as ft
from datetime import datetime
from sqlalchemy.orm import Session
from database.new_models import EmailTemplate, ScheduledEmail
from database.models import Employee
from utils.email_template_engine import EmailTemplateEngine
from core.base_screen import BaseScreen


class EmailTemplatesScreen(BaseScreen):
    """Email template management and scheduling"""

    def __init__(self, *args, **kwargs):
        page = kwargs.pop('page', None)
        user = kwargs.pop('user', None)
        session = kwargs.pop('session', None)
        employee_id = kwargs.pop('employee_id', None)

        if len(args) > 0:
            if isinstance(args[0], ft.Page):
                page = args[0]
            elif hasattr(args[0], 'query') or hasattr(args[0], 'add'):
                session = args[0]
        if len(args) > 1:
            if isinstance(args[1], (dict, object)) and not isinstance(args[1], int):
                user = args[1]
            elif isinstance(args[1], int):
                employee_id = args[1]

        super().__init__(page=page, **kwargs)

        if session is None:
            try:
                from database.session_manager import get_db_session
                session = get_db_session()
            except Exception:
                session = None
        self.session = session

        self.user = user
        if employee_id is None and user is not None:
            user_id = user.get('id') if isinstance(user, dict) else getattr(user, 'id', None)
            if user_id and session:
                try:
                    from database.session_manager import get_employee_by_user_id
                    emp = get_employee_by_user_id(session, user_id)
                    employee_id = emp.id if emp else user_id
                except Exception:
                    employee_id = user_id or 1
        if not employee_id:
            employee_id = 1
        self.employee_id = employee_id

        self.view_mode = "templates"

        main_content = self.build_screen()
        if main_content:
            self.controls = [main_content]

    def build_screen(self):
        """Build email templates screen"""

        # Tab selector
        tabs = ft.Tabs(
            selected_index=0,
            on_change=lambda e: self._on_tab_change(e),
            tabs=[
                ft.Tab(text="Templates", content=ft.Text("")),
                ft.Tab(text="Scheduled", content=ft.Text(""))
            ]
        )

        # Content container
        self.content_container = ft.Column(
            scroll=ft.ScrollMode.AUTO, expand=True)
        self._refresh_templates()

        # Action buttons
        action_buttons = ft.Row(
            controls=[
                ft.ElevatedButton(
                    text="Create Template",
                    on_click=self._show_create_template_dialog,
                    icon=ft.icons.CREATE
                ),
                ft.ElevatedButton(
                    text="Schedule Email",
                    on_click=self._show_schedule_dialog,
                    icon=ft.icons.SCHEDULE_SEND
                )
            ],
            spacing=10
        )

        main_content = ft.Column(
            controls=[
                ft.Container(
                    content=ft.Text("Email Templates", size=24, weight="bold"),
                    padding=10
                ),
                tabs,
                ft.Divider(),
                action_buttons,
                ft.Divider(),
                self.content_container
            ],
            expand=True
        )

        return main_content

    def _on_tab_change(self, e):
        """Handle tab change"""
        self.view_mode = "templates" if e.control.selected_index == 0 else "scheduled"
        self._refresh_content()

    def _refresh_content(self):
        """Refresh content based on view mode"""
        if self.view_mode == "templates":
            self._refresh_templates()
        else:
            self._refresh_scheduled()

    def _refresh_templates(self):
        """Refresh template list"""

        self.content_container.controls.clear()

        templates = self.session.query(EmailTemplate).filter(
            EmailTemplate.is_active == True
        ).all()

        if not templates:
            self.content_container.controls.append(
                ft.Text("No templates available", color="gray")
            )
            return

        for template in templates:
            card = self._build_template_card(template)
            self.content_container.controls.append(card)

    def _refresh_scheduled(self):
        """Refresh scheduled emails"""

        self.content_container.controls.clear()

        scheduled = self.session.query(ScheduledEmail).all()

        if not scheduled:
            self.content_container.controls.append(
                ft.Text("No scheduled emails", color="gray")
            )
            return

        for email in scheduled:
            card = self._build_scheduled_email_card(email)
            self.content_container.controls.append(card)

    def _build_template_card(self, template: EmailTemplate) -> ft.Container:
        """Build template card"""

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            ft.Column(
                                controls=[
                                    ft.Text(template.name, size=16,
                                            weight="bold"),
                                    ft.Text(
                                        f"Category: {template.category}",
                                        size=12,
                                        color="gray"
                                    )
                                ],
                                expand=True
                            ),
                            ft.Chip(label=template.category)
                        ]
                    ),
                    ft.Divider(height=10),
                    ft.Text("Subject:", weight="bold", size=12),
                    ft.Text(template.subject, size=11),
                    ft.Divider(height=10),
                    ft.Text("Variables:", weight="bold", size=12),
                    ft.Row(
                        controls=[
                            ft.Chip(label=v)
                            for v in (template.template_variables or [])[:5]
                        ],
                        spacing=5,
                        wrap=True
                    ),
                    ft.Row(
                        controls=[
                            ft.IconButton(
                                icon=ft.icons.EDIT,
                                tooltip="Edit",
                                on_click=lambda e: self._show_edit_template_dialog(
                                    template)
                            ),
                            ft.IconButton(
                                icon=ft.icons.DELETE,
                                tooltip="Delete",
                                on_click=lambda e: self._delete_template(
                                    template.id)
                            ),
                            ft.IconButton(
                                icon=ft.icons.SCHEDULE_SEND,
                                tooltip="Use Template",
                                on_click=lambda e: self._show_schedule_with_template(
                                    template)
                            )
                        ]
                    )
                ]
            ),
            padding=10,
            border=ft.border.all(1, ft.Colors.OUTLINE),
            border_radius=8
        )

    def _build_scheduled_email_card(self, email: ScheduledEmail) -> ft.Container:
        """Build scheduled email card"""

        status_color = "#4CAF50" if email.sent_at else "#FF9800"
        status_text = "Sent" if email.sent_at else "Pending"

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            ft.Column(
                                controls=[
                                    ft.Text(email.subject, size=14,
                                            weight="bold"),
                                    ft.Text(
                                        f"Recipients: {len(email.recipient_ids)}",
                                        size=12,
                                        color="gray"
                                    )
                                ],
                                expand=True
                            ),
                            ft.Container(
                                content=ft.Text(
                                    status_text, color=status_color),
                                padding=5,
                                bgcolor=ft.Colors.SURFACE_VARIANT,
                                border_radius=5
                            )
                        ]
                    ),
                    ft.Divider(height=10),
                    ft.Row(
                        controls=[
                            ft.Column(
                                controls=[
                                    ft.Text("Scheduled", size=10,
                                            color="gray"),
                                    ft.Text(
                                        email.scheduled_time.strftime(
                                            "%d %b, %H:%M"),
                                        size=12
                                    )
                                ]
                            ),
                            ft.Column(
                                controls=[
                                    ft.Text("Opens", size=10, color="gray"),
                                    ft.Text(
                                        str(email.open_count or 0),
                                        size=12,
                                        weight="bold"
                                    )
                                ]
                            ),
                            ft.Column(
                                controls=[
                                    ft.Text("Clicks", size=10, color="gray"),
                                    ft.Text(
                                        str(email.click_count or 0),
                                        size=12,
                                        weight="bold"
                                    )
                                ]
                            )
                        ],
                        spacing=40
                    ),
                    ft.Row(
                        controls=[
                            ft.IconButton(
                                icon=ft.icons.VISIBILITY,
                                tooltip="View",
                                on_click=lambda e: self._show_email_details(
                                    email)
                            )
                        ]
                    )
                ]
            ),
            padding=10,
            border=ft.border.all(1, ft.Colors.OUTLINE),
            border_radius=8
        )

    def _show_create_template_dialog(self, e):
        """Show create template dialog"""

        name_field = ft.TextField(label="Template Name")
        category_dropdown = ft.Dropdown(
            label="Category",
            options=[
                ft.dropdown.Option("Onboarding"),
                ft.dropdown.Option("Notifications"),
                ft.dropdown.Option("Finance"),
                ft.dropdown.Option("HR"),
                ft.dropdown.Option("Meetings"),
                ft.dropdown.Option("Custom")
            ]
        )
        subject_field = ft.TextField(label="Subject")
        body_field = ft.TextField(
            label="Body",
            multiline=True,
            min_lines=5
        )

        info_text = ft.Text(
            "Use {{variable_name}} for dynamic content",
            size=10,
            color="gray"
        )

        def save_template(e):
            try:
                if not all([name_field.value, category_dropdown.value, subject_field.value, body_field.value]):
                    self.page.snack_bar = ft.SnackBar(
                        ft.Text("All fields required"))
                    self.page.snack_bar.open = True
                    self.page.update()
                    return

                EmailTemplateEngine.create_template(
                    self.session,
                    name_field.value,
                    category_dropdown.value,
                    subject_field.value,
                    body_field.value
                )

                self.page.snack_bar = ft.SnackBar(
                    ft.Text("Template created successfully"))
                self.page.snack_bar.open = True
                self._refresh_templates()
                self._close_dialog()
                self.page.update()

            except Exception as ex:
                self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
                self.page.snack_bar.open = True
                self.page.update()

        dialog = ft.AlertDialog(
            title=ft.Text("Create Email Template"),
            content=ft.Column(
                controls=[
                    name_field,
                    category_dropdown,
                    subject_field,
                    body_field,
                    info_text
                ],
                spacing=10
            ),
            actions=[
                ft.TextButton(
                    "Cancel", on_click=lambda e: self._close_dialog()),
                ft.TextButton("Create", on_click=save_template)
            ]
        )

        self.page.dialog = dialog
        dialog.open = True
        self.page.update()

    def _show_schedule_dialog(self, e):
        """Show schedule email dialog"""

        template_dropdown = ft.Dropdown(label="Select Template")
        self._load_template_options(template_dropdown)

        recipient_field = ft.TextField(
            label="Recipients (comma-separated emails)",
            multiline=True,
            min_lines=2
        )

        date_field = ft.TextField(label="Date (YYYY-MM-DD)")
        time_field = ft.TextField(label="Time (HH:MM)")

        def schedule_email(e):
            try:
                if not template_dropdown.value or not recipient_field.value:
                    self.page.snack_bar = ft.SnackBar(
                        ft.Text("Template and recipients required"))
                    self.page.snack_bar.open = True
                    self.page.update()
                    return

                # Find template
                template_id = None
                for opt in template_dropdown.options:
                    if opt.label == template_dropdown.value:
                        template_id = int(opt.key)
                        break

                if not template_id:
                    return

                template = self.session.query(EmailTemplate).get(template_id)

                # Parse recipients
                recipients = [e.strip()
                              for e in recipient_field.value.split(",")]

                scheduled_time = datetime.now()
                if date_field.value and time_field.value:
                    try:
                        scheduled_time = datetime.strptime(
                            f"{date_field.value} {time_field.value}",
                            "%Y-%m-%d %H:%M"
                        )
                    except:
                        pass

                EmailTemplateEngine.schedule_email(
                    self.session,
                    template_id,
                    recipients,
                    {},  # Empty context
                    scheduled_time
                )

                self.page.snack_bar = ft.SnackBar(
                    ft.Text("Email scheduled successfully"))
                self.page.snack_bar.open = True
                self._refresh_scheduled()
                self._close_dialog()
                self.page.update()

            except Exception as ex:
                self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
                self.page.snack_bar.open = True
                self.page.update()

        dialog = ft.AlertDialog(
            title=ft.Text("Schedule Email"),
            content=ft.Column(
                controls=[
                    template_dropdown,
                    recipient_field,
                    date_field,
                    time_field
                ],
                spacing=10
            ),
            actions=[
                ft.TextButton(
                    "Cancel", on_click=lambda e: self._close_dialog()),
                ft.TextButton("Schedule", on_click=schedule_email)
            ]
        )

        self.page.dialog = dialog
        dialog.open = True
        self.page.update()

    def _load_template_options(self, dropdown):
        """Load templates into dropdown"""
        templates = self.session.query(EmailTemplate).all()
        dropdown.options = [
            ft.dropdown.Option(t.name, key=str(t.id))
            for t in templates
        ]

    def _show_edit_template_dialog(self, template: EmailTemplate, e=None):
        """Show edit template dialog"""
        pass

    def _show_schedule_with_template(self, template: EmailTemplate, e=None):
        """Show schedule dialog with template pre-selected"""
        self._show_schedule_dialog(None)

    def _show_email_details(self, email: ScheduledEmail, e=None):
        """Show email details"""

        content = ft.Column(
            controls=[
                ft.Text("Subject:", weight="bold"),
                ft.Text(email.subject),
                ft.Divider(),
                ft.Text("Body:", weight="bold"),
                ft.Text(email.body, selectable=True),
                ft.Divider(),
                ft.Text("Status:", weight="bold"),
                ft.Text("Sent" if email.sent_at else "Pending"),
                ft.Divider(),
                ft.Text("Engagement:", weight="bold"),
                ft.Row(
                    controls=[
                        ft.Column(
                            controls=[
                                ft.Text("Opens", size=12, color="gray"),
                                ft.Text(str(email.open_count or 0),
                                        weight="bold")
                            ]
                        ),
                        ft.Column(
                            controls=[
                                ft.Text("Clicks", size=12, color="gray"),
                                ft.Text(str(email.click_count or 0),
                                        weight="bold")
                            ]
                        )
                    ]
                )
            ],
            spacing=10
        )

        dialog = ft.AlertDialog(
            title=ft.Text("Email Details"),
            content=content,
            actions=[
                ft.TextButton("Close", on_click=lambda e: self._close_dialog())
            ]
        )

        self.page.dialog = dialog
        dialog.open = True
        self.page.update()

    def _delete_template(self, template_id: int):
        """Delete template"""
        try:
            template = self.session.query(EmailTemplate).get(template_id)
            if template:
                template.is_active = False
                self.session.commit()
                self._refresh_templates()
                self.page.update()
        except Exception as ex:
            self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
            self.page.snack_bar.open = True
            self.page.update()

    def _close_dialog(self):
        """Close dialog"""
        self.page.dialog.open = False
        self.page.update()

    def on_screen_load(self):
        """Called when screen loads"""
        # Initialize default templates if needed
        try:
            EmailTemplateEngine.initialize_default_faqs(self.session)
        except:
            pass
        self._refresh_content()

    def on_screen_unload(self):
        """Called when screen unloads"""
        pass
