"""
Expense Approval Workflow Screen - Multi-Tier Expense Approvals
Dynamic routing with budget tracking and approval status visualization
"""

import flet as ft
from datetime import datetime
from decimal import Decimal
from sqlalchemy.orm import Session
from database.new_models import EnhancedExpense, ExpenseApprovalStatus
from database.models import Employee, Department
from utils.approval_routing_engine import ApprovalRoutingEngine
from core.base_screen import BaseScreen


class ExpenseApprovalWorkflowScreen(BaseScreen):
    """Expense approval workflow management"""

    def __init__(self, *args, **kwargs):
        page = kwargs.pop('page', None)
        user = kwargs.pop('user', None)
        session = kwargs.pop('session', None)
        employee_id = kwargs.pop('employee_id', None)

        if len(args) > 0:
            if isinstance(args[0], ft.Page):
                page = args[0]
            elif hasattr(args[0], 'query') or hasattr(args[0], 'add'):
                session = args[0]
        if len(args) > 1:
            if isinstance(args[1], (dict, object)) and not isinstance(args[1], int):
                user = args[1]
            elif isinstance(args[1], int):
                employee_id = args[1]

        super().__init__(page=page, **kwargs)

        if session is None:
            try:
                from database.session_manager import get_db_session
                session = get_db_session()
            except Exception:
                session = None
        self.session = session

        self.user = user
        if employee_id is None and user is not None:
            user_id = user.get('id') if isinstance(user, dict) else getattr(user, 'id', None)
            if user_id and session:
                try:
                    from database.session_manager import get_employee_by_user_id
                    emp = get_employee_by_user_id(session, user_id)
                    employee_id = emp.id if emp else user_id
                except Exception:
                    employee_id = user_id or 1
        if not employee_id:
            employee_id = 1
        self.employee_id = employee_id

        self.view_mode = "pending"

        main_content = self.build_screen()
        if main_content:
            self.controls = [main_content]

    def build_screen(self):
        """Build expense approval screen"""

        # View selector
        view_selector = self._build_view_selector()

        # Budget status
        budget_panel = self._build_budget_panel()

        # Expense list
        self.expense_list = ft.Column(spacing=10)
        self._refresh_expenses()

        # Submit new expense button
        submit_btn = ft.ElevatedButton(
            text="Submit Expense",
            on_click=self._show_submit_dialog,
            icon=ft.icons.ADD_BOX
        )

        main_content = ft.Column(
            controls=[
                ft.Container(
                    content=ft.Text("Expense Management",
                                    size=24, weight="bold"),
                    padding=10
                ),
                view_selector,
                ft.Divider(),
                budget_panel,
                ft.Divider(),
                submit_btn,
                ft.Divider(),
                ft.Container(
                    content=self.expense_list,
                    expand=True
                )
            ],
            scroll=ft.ScrollMode.AUTO,
            expand=True
        )

        return main_content

    def _build_view_selector(self) -> ft.Container:
        """Build view selector"""

        def on_view_change(e):
            self.view_mode = e.control.selected_tab_index
            self._refresh_expenses()

        tabs = ft.Tabs(
            selected_index=0,
            on_change=lambda e: on_view_change(e),
            tabs=[
                ft.Tab(text="Pending", content=ft.Text("")),
                ft.Tab(text="Approved", content=ft.Text("")),
                ft.Tab(text="All", content=ft.Text(""))
            ]
        )

        return ft.Container(content=tabs, padding=5)

    def _build_budget_panel(self) -> ft.Container:
        """Build budget status panel"""

        self.budget_info = ft.Column(spacing=10)
        self._refresh_budget_info()

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Text("Budget Status", size=16, weight="bold"),
                    self.budget_info
                ]
            ),
            padding=10,
            bgcolor=ft.Colors.SURFACE_VARIANT,
            border_radius=10
        )

    def _refresh_budget_info(self):
        """Refresh budget information"""

        employee = self.session.query(Employee).get(self.employee_id)
        if not employee or not employee.department_id:
            return

        budget_data = ApprovalRoutingEngine.get_budget_status(
            self.session,
            employee.department_id
        )

        if "error" in budget_data:
            self.budget_info.controls.clear()
            self.budget_info.controls.append(
                ft.Text("No budget configured", color="gray")
            )
            return

        # Build budget display
        controls = []

        # Budget bar
        utilization = budget_data['utilization_percentage']
        controls.append(
            ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            ft.Text("Monthly Budget Usage", weight="bold"),
                            ft.Text(f"{utilization:.0f}%")
                        ]
                    ),
                    ft.ProgressBar(value=min(100, utilization) / 100)
                ]
            )
        )

        # Budget details
        controls.append(
            ft.Row(
                controls=[
                    ft.Column(
                        controls=[
                            ft.Text("Budget", size=12, color="gray"),
                            ft.Text(
                                f"${budget_data['budget']:,.2f}", weight="bold")
                        ]
                    ),
                    ft.Column(
                        controls=[
                            ft.Text("Spent", size=12, color="gray"),
                            ft.Text(
                                f"${budget_data['spent']:,.2f}", weight="bold")
                        ]
                    ),
                    ft.Column(
                        controls=[
                            ft.Text("Remaining", size=12, color="gray"),
                            ft.Text(
                                f"${budget_data['remaining']:,.2f}",
                                weight="bold",
                                color="#4CAF50" if budget_data['remaining'] > 0 else "#F44336"
                            )
                        ]
                    )
                ],
                spacing=40
            )
        )

        self.budget_info.controls = controls

    def _refresh_expenses(self):
        """Refresh expense list"""

        self.expense_list.controls.clear()

        # Get expenses based on view mode
        if self.view_mode == "pending":
            expenses = ApprovalRoutingEngine.get_pending_approvals(
                self.session,
                self.employee_id
            )
        else:
            # Get all or approved
            expenses = self.session.query(EnhancedExpense).filter(
                EnhancedExpense.employee_id == self.employee_id
            ).all()

            if self.view_mode == "approved":
                expenses = [e for e in expenses if e.status ==
                            ExpenseApprovalStatus.APPROVED]

        if not expenses:
            self.expense_list.controls.append(
                ft.Text("No expenses found", color="gray")
            )
            return

        for expense in expenses:
            card = self._build_expense_card(expense)
            self.expense_list.controls.append(card)

    def _build_expense_card(self, expense: EnhancedExpense) -> ft.Container:
        """Build expense card"""

        # Status color
        status_colors = {
            ExpenseApprovalStatus.SUBMITTED: "#2196F3",
            ExpenseApprovalStatus.TIER1_PENDING: "#FF9800",
            ExpenseApprovalStatus.TIER1_APPROVED: "#4CAF50",
            ExpenseApprovalStatus.TIER1_REJECTED: "#F44336",
            ExpenseApprovalStatus.TIER2_PENDING: "#FF9800",
            ExpenseApprovalStatus.TIER2_APPROVED: "#4CAF50",
            ExpenseApprovalStatus.TIER2_REJECTED: "#F44336",
            ExpenseApprovalStatus.APPROVED: "#4CAF50",
            ExpenseApprovalStatus.PAID: "#2E7D32"
        }

        status_color = status_colors.get(expense.status, "#CCCCCC")

        # Approval flow indicator
        approval_flow = self._build_approval_flow(expense)

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            ft.Column(
                                controls=[
                                    ft.Text(
                                        expense.category or "Expense",
                                        size=14,
                                        weight="bold"
                                    ),
                                    ft.Text(
                                        expense.description[:50] + "..."
                                        if len(expense.description or "") > 50
                                        else expense.description,
                                        size=12,
                                        color="gray"
                                    )
                                ],
                                expand=True
                            ),
                            ft.Column(
                                controls=[
                                    ft.Text(
                                        f"${expense.amount:,.2f}",
                                        size=16,
                                        weight="bold",
                                        color=status_color
                                    ),
                                    ft.Text(
                                        expense.status.value,
                                        size=10,
                                        color=status_color
                                    )
                                ]
                            )
                        ],
                        spacing=10
                    ),
                    ft.Divider(height=10),
                    approval_flow,
                    ft.Row(
                        controls=[
                            ft.IconButton(
                                icon=ft.icons.VISIBILITY,
                                tooltip="Details",
                                on_click=lambda e: self._show_details(expense)
                            ),
                            ft.IconButton(
                                icon=ft.icons.EDIT,
                                tooltip="Edit",
                                on_click=lambda e: self._show_edit_dialog(
                                    expense)
                            )
                        ]
                    )
                ]
            ),
            padding=10,
            border=ft.border.all(1, ft.Colors.OUTLINE),
            border_radius=8
        )

    def _build_approval_flow(self, expense: EnhancedExpense) -> ft.Row:
        """Build approval flow indicator"""

        # Determine tier 1 status
        tier1_status = "pending"
        if expense.status in [
            ExpenseApprovalStatus.TIER1_APPROVED,
            ExpenseApprovalStatus.TIER2_PENDING,
            ExpenseApprovalStatus.TIER2_APPROVED,
            ExpenseApprovalStatus.APPROVED,
            ExpenseApprovalStatus.PAID
        ]:
            tier1_status = "approved"
        elif expense.status == ExpenseApprovalStatus.TIER1_REJECTED:
            tier1_status = "rejected"

        # Tier 2 status
        tier2_status = "pending"
        if expense.status in [ExpenseApprovalStatus.TIER2_APPROVED, ExpenseApprovalStatus.APPROVED, ExpenseApprovalStatus.PAID]:
            tier2_status = "approved"
        elif expense.status == ExpenseApprovalStatus.TIER2_REJECTED:
            tier2_status = "rejected"

        color_map = {
            "pending": "#FFC107",
            "approved": "#4CAF50",
            "rejected": "#F44336"
        }

        return ft.Row(
            controls=[
                ft.Column(
                    controls=[
                        ft.Text("Tier 1", size=10),
                        ft.Container(
                            width=30,
                            height=30,
                            bgcolor=color_map[tier1_status],
                            border_radius=15,
                            alignment=ft.alignment.center,
                            content=ft.Icon(
                                ft.icons.CHECK if tier1_status == "approved" else ft.icons.CLOSE if tier1_status == "rejected" else ft.icons.SCHEDULE,
                                color="white",
                                size=16
                            )
                        )
                    ],
                    alignment=ft.MainAxisAlignment.CENTER
                ),
                ft.Divider(),
                ft.Column(
                    controls=[
                        ft.Text("Tier 2", size=10),
                        ft.Container(
                            width=30,
                            height=30,
                            bgcolor=color_map[tier2_status],
                            border_radius=15,
                            alignment=ft.alignment.center,
                            content=ft.Icon(
                                ft.icons.CHECK if tier2_status == "approved" else ft.icons.CLOSE if tier2_status == "rejected" else ft.icons.SCHEDULE,
                                color="white",
                                size=16
                            )
                        )
                    ],
                    alignment=ft.MainAxisAlignment.CENTER
                )
            ],
            spacing=20
        )

    def _show_submit_dialog(self, e):
        """Show submit expense dialog"""

        category_field = ft.TextField(label="Category")
        amount_field = ft.TextField(
            label="Amount",
            keyboard_type=ft.KeyboardType.NUMBER
        )
        cost_center_field = ft.TextField(label="Cost Center")
        description_field = ft.TextField(
            label="Description",
            multiline=True,
            min_lines=3
        )

        def save_expense(e):
            try:
                if not category_field.value or not amount_field.value:
                    self.page.snack_bar = ft.SnackBar(
                        ft.Text("Required fields missing"))
                    self.page.snack_bar.open = True
                    self.page.update()
                    return

                ApprovalRoutingEngine.submit_expense(
                    self.session,
                    self.employee_id,
                    Decimal(amount_field.value),
                    category_field.value,
                    cost_center_field.value,
                    description_field.value
                )

                self.page.snack_bar = ft.SnackBar(
                    ft.Text("Expense submitted for approval"))
                self.page.snack_bar.open = True
                self._refresh_expenses()
                self._refresh_budget_info()
                self._close_dialog()
                self.page.update()

            except Exception as ex:
                self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
                self.page.snack_bar.open = True
                self.page.update()

        dialog = ft.AlertDialog(
            title=ft.Text("Submit Expense"),
            content=ft.Column(
                controls=[
                    category_field,
                    amount_field,
                    cost_center_field,
                    description_field
                ],
                spacing=10
            ),
            actions=[
                ft.TextButton(
                    "Cancel", on_click=lambda e: self._close_dialog()),
                ft.TextButton("Submit", on_click=save_expense)
            ]
        )

        self.page.dialog = dialog
        dialog.open = True
        self.page.update()

    def _show_details(self, expense: EnhancedExpense, e=None):
        """Show expense details"""

        content = ft.Column(
            controls=[
                ft.Row(
                    controls=[
                        ft.Text("Category", weight="bold"),
                        ft.Text(expense.category)
                    ]
                ),
                ft.Row(
                    controls=[
                        ft.Text("Amount", weight="bold"),
                        ft.Text(f"${expense.amount:,.2f}")
                    ]
                ),
                ft.Row(
                    controls=[
                        ft.Text("Cost Center", weight="bold"),
                        ft.Text(expense.cost_center)
                    ]
                ),
                ft.Divider(),
                ft.Text("Description", weight="bold"),
                ft.Text(expense.description),
                ft.Divider(),
                ft.Text("Status", weight="bold"),
                ft.Text(expense.status.value)
            ],
            spacing=10
        )

        dialog = ft.AlertDialog(
            title=ft.Text("Expense Details"),
            content=content,
            actions=[
                ft.TextButton("Close", on_click=lambda e: self._close_dialog())
            ]
        )

        self.page.dialog = dialog
        dialog.open = True
        self.page.update()

    def _show_edit_dialog(self, expense: EnhancedExpense, e=None):
        """Show edit expense dialog"""
        # Implementation similar to submit
        pass

    def _close_dialog(self):
        """Close dialog"""
        self.page.dialog.open = False
        self.page.update()

    def on_screen_load(self):
        """Called when screen loads"""
        self._refresh_expenses()
        self._refresh_budget_info()

    def on_screen_unload(self):
        """Called when screen unloads"""
        pass
