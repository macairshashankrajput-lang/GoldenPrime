import flet as ft
import time


class Message:
    def __init__(self, user_name: str, text: str, message_type: str):
        self.user_name = user_name
        self.text = text
        self.message_type = message_type


class ChatMessage(ft.Row):
    def __init__(self, message: Message):
        super().__init__()
        self.vertical_alignment = ft.CrossAxisAlignment.START
        self.controls = [
            ft.CircleAvatar(
                content=ft.Text(self.get_initials(message.user_name)),
                color=ft.Colors.WHITE,
                bgcolor=self.get_avatar_color(message.message_type),
            ),
            ft.Column(
                [
                    ft.Text(message.user_name, weight="bold"),
                    ft.Text(message.text, selectable=True),
                ],
                tight=True,
                spacing=5,
            ),
        ]

    def get_initials(self, user_name: str):
        return user_name[:1].upper()

    def get_avatar_color(self, message_type: str):
        if message_type == "assistant":
            return ft.Colors.BLUE_700
        return ft.Colors.ORANGE_700


def get_ai_assistant_view(page: ft.Page):
    chat = ft.ListView(
        expand=True,
        spacing=10,
        auto_scroll=True,
    )

    new_message = ft.TextField(
        hint_text="Type your message here...",
        autofocus=True,
        shift_enter=True,
        min_lines=1,
        max_lines=5,
        filled=True,
        expand=True,
        on_submit=lambda e: send_message_click(e),
    )

    def send_message_click(e):
        if new_message.value == "":
            return

        # User message
        user_msg = Message("You", new_message.value, "user")
        chat.controls.append(ChatMessage(user_msg))

        user_input = new_message.value
        new_message.value = ""
        new_message.focus()
        page.update()

        # Simulate AI thinking
        time.sleep(0.5)

        # AI response placeholder
        ai_response_text = f"I am your Vernika AI Assistant. You said: '{user_input}'. How can I help you further?"
        ai_msg = Message("AI Assistant", ai_response_text, "assistant")
        chat.controls.append(ChatMessage(ai_msg))
        page.update()

    # Main layout for the screen
    return ft.Column(
        [
            ft.Container(
                content=ft.Row(
                    [
                        ft.Icon(ft.Icons.ASSISTANT, color=ft.Colors.WHITE),
                        ft.Text("Vernika AI Assistant", size=20,
                                weight="bold", color=ft.Colors.WHITE),
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                ),
                bgcolor=ft.Colors.BLUE_900,
                padding=10,
                border_radius=ft.border_radius.all(5),
            ),
            ft.Container(
                content=chat,
                border=ft.border.all(1, ft.Colors.OUTLINE),
                border_radius=5,
                padding=10,
                expand=True,
            ),
            ft.Row(
                [
                    new_message,
                    ft.IconButton(
                        icon=ft.Icons.SEND_ROUNDED,
                        tooltip="Send message",
                        on_click=send_message_click,
                    ),
                ]
            ),
        ],
        expand=True,
    )


def main(page: ft.Page):
    page.title = "Vernika AI Assistant"
    page.theme_mode = ft.ThemeMode.LIGHT

    # This is how you would add it to your existing app
    # For demonstration, we just add it to the page directly
    page.add(get_ai_assistant_view(page))


if __name__ == "__main__":
    ft.app(target=main, view=ft.AppView.WEB_BROWSER, port=8551)
