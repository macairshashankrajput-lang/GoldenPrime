"""
Device Trust Management Screen - Security and Trusted Devices
Manage trusted devices with authentication history
"""

import flet as ft
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from database.new_models import DeviceTrust
from database.models import Employee
from core.base_screen import BaseScreen


class DeviceTrustScreen(BaseScreen):
    """Device trust and security management"""

    def __init__(self, *args, **kwargs):
        page = kwargs.pop('page', None)
        user = kwargs.pop('user', None)
        session = kwargs.pop('session', None)
        employee_id = kwargs.pop('employee_id', None)

        if len(args) > 0:
            if isinstance(args[0], ft.Page):
                page = args[0]
            elif hasattr(args[0], 'query') or hasattr(args[0], 'add'):
                session = args[0]
        if len(args) > 1:
            if isinstance(args[1], (dict, object)) and not isinstance(args[1], int):
                user = args[1]
            elif isinstance(args[1], int):
                employee_id = args[1]

        super().__init__(page=page, **kwargs)

        if session is None:
            try:
                from database.session_manager import get_db_session
                session = get_db_session()
            except Exception:
                session = None
        self.session = session

        self.user = user
        if employee_id is None and user is not None:
            user_id = user.get('id') if isinstance(user, dict) else getattr(user, 'id', None)
            if user_id and session:
                try:
                    from database.session_manager import get_employee_by_user_id
                    emp = get_employee_by_user_id(session, user_id)
                    employee_id = emp.id if emp else user_id
                except Exception:
                    employee_id = user_id or 1
        if not employee_id:
            employee_id = 1
        self.employee_id = employee_id

        main_content = self.build_screen()
        if main_content:
            self.controls = [main_content]

    def build_screen(self):
        """Build device trust screen"""

        # Security summary
        security_summary = self._build_security_summary()

        # Trusted devices list
        self.devices_container = ft.Column(spacing=10)
        self._refresh_devices()

        # Recent activity
        activity_panel = self._build_activity_panel()

        main_content = ft.Column(
            controls=[
                ft.Container(
                    content=ft.Text("Device Security", size=24, weight="bold"),
                    padding=10
                ),
                security_summary,
                ft.Divider(),
                ft.Text("Active Devices", size=16,
                        weight="bold", padding_left=10),
                ft.Container(
                    content=self.devices_container,
                    expand=True
                ),
                ft.Divider(),
                activity_panel
            ],
            scroll=ft.ScrollMode.AUTO,
            expand=True
        )

        return main_content

    def _build_security_summary(self) -> ft.Container:
        """Build security status summary"""

        employee = self.session.query(Employee).get(self.employee_id)
        trusted_devices = self.session.query(DeviceTrust).filter(
            DeviceTrust.employee_id == self.employee_id,
            DeviceTrust.is_trusted == True
        ).all()

        total_devices = self.session.query(DeviceTrust).filter(
            DeviceTrust.employee_id == self.employee_id
        ).all()

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            ft.Column(
                                controls=[
                                    ft.Text("Trusted Devices",
                                            size=12, color="gray"),
                                    ft.Text(str(len(trusted_devices)),
                                            size=20, weight="bold")
                                ]
                            ),
                            ft.Column(
                                controls=[
                                    ft.Text("Total Devices",
                                            size=12, color="gray"),
                                    ft.Text(str(len(total_devices)),
                                            size=20, weight="bold")
                                ]
                            ),
                            ft.Column(
                                controls=[
                                    ft.Text("Security Status",
                                            size=12, color="gray"),
                                    ft.Text("Good", size=16,
                                            weight="bold", color="#4CAF50")
                                ]
                            )
                        ],
                        spacing=40
                    ),
                    ft.Divider(),
                    ft.ElevatedButton(
                        text="Review Security Settings",
                        on_click=self._show_security_settings,
                        icon=ft.icons.SECURITY
                    )
                ]
            ),
            padding=15,
            bgcolor=ft.Colors.SURFACE_VARIANT,
            border_radius=10
        )

    def _refresh_devices(self):
        """Refresh trusted devices list"""

        self.devices_container.controls.clear()

        devices = self.session.query(DeviceTrust).filter(
            DeviceTrust.employee_id == self.employee_id
        ).order_by(DeviceTrust.last_used.desc()).all()

        if not devices:
            self.devices_container.controls.append(
                ft.Text("No registered devices", color="gray")
            )
            return

        for device in devices:
            card = self._build_device_card(device)
            self.devices_container.controls.append(card)

    def _build_device_card(self, device: DeviceTrust) -> ft.Container:
        """Build device card"""

        # Trust status color
        trust_color = "#4CAF50" if device.is_trusted else "#FF9800"
        trust_text = "Trusted" if device.is_trusted else "Untrusted"

        # Device type icon
        device_icons = {
            "desktop": ft.icons.COMPUTER,
            "mobile": ft.icons.SMARTPHONE,
            "tablet": ft.icons.TABLET,
            "web": ft.icons.LANGUAGE
        }
        icon = device_icons.get(device.device_type or "web", ft.icons.DEVICES)

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            ft.Icon(icon, size=40, color="#2196F3"),
                            ft.Column(
                                controls=[
                                    ft.Text(
                                        device.device_name or "Unknown Device", weight="bold"),
                                    ft.Text(
                                        f"{device.device_type or 'Web'} • {device.os_name or 'Unknown OS'}",
                                        size=12,
                                        color="gray"
                                    ),
                                    ft.Text(
                                        f"Last used: {device.last_used.strftime('%d %b, %H:%M') if device.last_used else 'Never'}",
                                        size=10,
                                        color="gray"
                                    )
                                ],
                                expand=True
                            ),
                            ft.Container(
                                content=ft.Text(
                                    trust_text, color="white", size=11, weight="bold"),
                                padding=8,
                                bgcolor=trust_color,
                                border_radius=5
                            )
                        ],
                        spacing=10
                    ),
                    ft.Divider(height=10),
                    ft.Row(
                        controls=[
                            ft.Column(
                                controls=[
                                    ft.Text("IP Address", size=10,
                                            color="gray"),
                                    ft.Text(device.ip_address or "N/A",
                                            size=11, selectable=True)
                                ]
                            ),
                            ft.Column(
                                controls=[
                                    ft.Text("Browser", size=10, color="gray"),
                                    ft.Text(
                                        device.browser_info or "N/A", size=11)
                                ]
                            ),
                            ft.Column(
                                controls=[
                                    ft.Text("Registered", size=10,
                                            color="gray"),
                                    ft.Text(device.registered_date.strftime(
                                        "%d %b, %Y") if device.registered_date else "N/A", size=11)
                                ]
                            )
                        ],
                        spacing=20
                    ),
                    ft.Row(
                        controls=[
                            ft.IconButton(
                                icon=ft.icons.LOCK if device.is_trusted else ft.icons.LOCK_OPEN,
                                tooltip="Toggle Trust",
                                on_click=lambda e: self._toggle_trust(device)
                            ),
                            ft.IconButton(
                                icon=ft.icons.DELETE,
                                tooltip="Remove Device",
                                on_click=lambda e: self._remove_device(
                                    device.id)
                            )
                        ]
                    )
                ]
            ),
            padding=10,
            border=ft.border.all(1, ft.Colors.OUTLINE),
            border_radius=8
        )

    def _build_activity_panel(self) -> ft.Container:
        """Build recent activity panel"""

        activities = self.session.query(DeviceTrust).filter(
            DeviceTrust.employee_id == self.employee_id
        ).order_by(DeviceTrust.last_used.desc()).limit(5).all()

        activity_list = ft.Column(spacing=5)

        for activity in activities:
            activity_list.controls.append(
                ft.Row(
                    controls=[
                        ft.Icon(ft.icons.LOGIN, size=20, color="#2196F3"),
                        ft.Column(
                            controls=[
                                ft.Text(
                                    f"{activity.device_name} login",
                                    size=12,
                                    weight="bold"
                                ),
                                ft.Text(
                                    activity.last_used.strftime(
                                        "%d %b, %H:%M") if activity.last_used else "N/A",
                                    size=10,
                                    color="gray"
                                )
                            ],
                            expand=True
                        )
                    ],
                    spacing=10
                )
            )

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Text("Recent Activity", size=16, weight="bold"),
                    ft.Divider(height=10),
                    activity_list
                ]
            ),
            padding=10
        )

    def _toggle_trust(self, device: DeviceTrust):
        """Toggle device trust status"""

        try:
            device.is_trusted = not device.is_trusted
            self.session.commit()
            self._refresh_devices()

            status = "trusted" if device.is_trusted else "untrusted"
            self.page.snack_bar = ft.SnackBar(
                ft.Text(f"Device marked as {status}")
            )
            self.page.snack_bar.open = True
            self.page.update()

        except Exception as ex:
            self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
            self.page.snack_bar.open = True
            self.page.update()

    def _remove_device(self, device_id: int):
        """Remove device from trusted list"""

        try:
            device = self.session.query(DeviceTrust).get(device_id)
            if device:
                self.session.delete(device)
                self.session.commit()
                self._refresh_devices()

                self.page.snack_bar = ft.SnackBar(ft.Text("Device removed"))
                self.page.snack_bar.open = True
                self.page.update()

        except Exception as ex:
            self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
            self.page.snack_bar.open = True
            self.page.update()

    def _show_security_settings(self, e):
        """Show security settings dialog"""

        content = ft.Column(
            controls=[
                ft.Text("Two-Factor Authentication", weight="bold"),
                ft.Switch(label="Require 2FA on login", value=False),
                ft.Divider(),
                ft.Text("Session Management", weight="bold"),
                ft.Slider(
                    label="Session timeout (minutes)",
                    value=30,
                    min=5,
                    max=480,
                    width=300
                ),
                ft.Divider(),
                ft.Text("Device Verification", weight="bold"),
                ft.Switch(label="Verify new devices", value=True),
                ft.Switch(label="Notify on new login", value=True)
            ],
            spacing=10
        )

        dialog = ft.AlertDialog(
            title=ft.Text("Security Settings"),
            content=content,
            actions=[
                ft.TextButton("Close", on_click=lambda e: self._close_dialog())
            ]
        )

        self.page.dialog = dialog
        dialog.open = True
        self.page.update()

    def _close_dialog(self):
        """Close dialog"""
        self.page.dialog.open = False
        self.page.update()

    def on_screen_load(self):
        """Called when screen loads"""
        self._refresh_devices()

    def on_screen_unload(self):
        """Called when screen unloads"""
        pass
