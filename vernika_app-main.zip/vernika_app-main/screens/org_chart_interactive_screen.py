"""
Organization Chart Interactive Screen - Hierarchical Structure
Drill-down navigation with employee information
"""

import flet as ft
from sqlalchemy.orm import Session
from database.models import Employee
from utils.org_chart_builder import OrgChartBuilder
from core.base_screen import BaseScreen


class OrgChartInteractiveScreen(BaseScreen):
    """Interactive organization chart visualization"""

    def __init__(self, *args, **kwargs):
        page = kwargs.pop('page', None)
        user = kwargs.pop('user', None)
        session = kwargs.pop('session', None)
        employee_id = kwargs.pop('employee_id', None)

        if len(args) > 0:
            if isinstance(args[0], ft.Page):
                page = args[0]
            elif hasattr(args[0], 'query') or hasattr(args[0], 'add'):
                session = args[0]
        if len(args) > 1:
            if isinstance(args[1], (dict, object)) and not isinstance(args[1], int):
                user = args[1]
            elif isinstance(args[1], int):
                employee_id = args[1]

        super().__init__(page=page, **kwargs)

        if session is None:
            try:
                from database.session_manager import get_db_session
                session = get_db_session()
            except Exception:
                session = None
        self.session = session

        self.user = user
        if employee_id is None and user is not None:
            user_id = user.get('id') if isinstance(user, dict) else getattr(user, 'id', None)
            if user_id and session:
                try:
                    from database.session_manager import get_employee_by_user_id
                    emp = get_employee_by_user_id(session, user_id)
                    employee_id = emp.id if emp else user_id
                except Exception:
                    employee_id = user_id or 1
        if not employee_id:
            employee_id = 1
        self.employee_id = employee_id

        self.current_view_id = None

        main_content = self.build_screen()
        if main_content:
            self.controls = [main_content]

    def build_screen(self):
        """Build org chart screen"""

        # Navigation breadcrumb
        self.breadcrumb = ft.Row(spacing=5, wrap=True)
        self._update_breadcrumb()

        # Chart area
        self.chart_container = ft.Column(
            scroll=ft.ScrollMode.AUTO,
            expand=True
        )
        self._render_org_chart()

        # Statistics panel
        stats_panel = self._build_stats_panel()

        main_content = ft.Column(
            controls=[
                ft.Container(
                    content=ft.Text("Organization Chart",
                                    size=24, weight="bold"),
                    padding=10
                ),
                ft.Container(
                    content=self.breadcrumb,
                    padding=10
                ),
                ft.Divider(),
                ft.Container(
                    content=self.chart_container,
                    expand=True
                ),
                ft.Divider(),
                stats_panel
            ],
            expand=True
        )

        return main_content

    def _build_stats_panel(self) -> ft.Container:
        """Build statistics panel"""

        stats = OrgChartBuilder.get_org_stats(self.session)

        return ft.Container(
            content=ft.Row(
                controls=[
                    ft.Column(
                        controls=[
                            ft.Text("Total Employees", size=12, color="gray"),
                            ft.Text(str(stats["total_employees"]),
                                    size=18, weight="bold")
                        ]
                    ),
                    ft.Column(
                        controls=[
                            ft.Text("Managers", size=12, color="gray"),
                            ft.Text(str(stats["total_managers"]),
                                    size=18, weight="bold")
                        ]
                    ),
                    ft.Column(
                        controls=[
                            ft.Text("Org. Depth", size=12, color="gray"),
                            ft.Text(str(stats["depth"]),
                                    size=18, weight="bold")
                        ]
                    ),
                    ft.Column(
                        controls=[
                            ft.Text("Avg Team Size", size=12, color="gray"),
                            ft.Text(
                                f"{stats['average_team_size']:.1f}", size=18, weight="bold")
                        ]
                    )
                ],
                spacing=40
            ),
            padding=15,
            bgcolor=ft.Colors.SURFACE_VARIANT,
            border_radius=10
        )

    def _render_org_chart(self):
        """Render organization chart"""

        self.chart_container.controls.clear()

        if self.current_view_id:
            # Viewing specific employee
            employee = self.session.query(Employee).get(self.current_view_id)
        else:
            # Find root employee
            root = self.session.query(Employee).filter(
                Employee.manager_id == None
            ).first()
            employee = root
            self.current_view_id = employee.id if employee else None

        if not employee:
            self.chart_container.controls.append(
                ft.Text("Organization structure not found", color="gray")
            )
            return

        # Build employee card
        card = self._build_employee_card(employee)
        self.chart_container.controls.append(card)

        # Build direct reports
        direct_reports = OrgChartBuilder.get_direct_reports(
            self.session, employee.id)

        if direct_reports:
            self.chart_container.controls.append(
                ft.Text(
                    f"Direct Reports ({len(direct_reports)})", size=14, weight="bold")
            )

            for report in direct_reports:
                report_card = self._build_report_card(report)
                self.chart_container.controls.append(report_card)

        # Build management chain
        chain = OrgChartBuilder.get_management_chain(self.session, employee.id)

        if len(chain) > 1:  # More than just current employee
            self.chart_container.controls.append(
                ft.Divider()
            )
            self.chart_container.controls.append(
                ft.Text("Management Chain", size=14, weight="bold")
            )

            for i, manager in enumerate(chain[1:]):  # Skip current employee
                level_text = f"Level {i+1}"
                manager_card = self._build_chain_card(manager, level_text)
                self.chart_container.controls.append(manager_card)

    def _build_employee_card(self, emp: Employee) -> ft.Container:
        """Build employee card"""

        team_size = OrgChartBuilder.get_team_size(
            self.session, emp.id, include_indirect=False)

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            ft.Container(
                                content=ft.Icon(
                                    ft.icons.PERSON_4,
                                    size=50,
                                    color="#2196F3"
                                ),
                                width=60,
                                height=60,
                                bgcolor=ft.Colors.SURFACE_VARIANT,
                                border_radius=10
                            ),
                            ft.Column(
                                controls=[
                                    ft.Text(
                                        f"{emp.first_name} {emp.last_name}",
                                        size=16,
                                        weight="bold"
                                    ),
                                    ft.Text(emp.position or "N/A",
                                            size=12, color="gray"),
                                    ft.Text(
                                        emp.department.name if emp.department else "N/A",
                                        size=11,
                                        color="gray"
                                    )
                                ]
                            )
                        ],
                        spacing=15
                    ),
                    ft.Divider(height=10),
                    ft.Row(
                        controls=[
                            ft.Column(
                                controls=[
                                    ft.Text("Direct Reports",
                                            size=10, color="gray"),
                                    ft.Text(str(team_size),
                                            size=14, weight="bold")
                                ]
                            ),
                            ft.Column(
                                controls=[
                                    ft.Text("Email", size=10, color="gray"),
                                    ft.Text(emp.email or "N/A",
                                            size=12, selectable=True)
                                ]
                            )
                        ],
                        spacing=40
                    )
                ]
            ),
            padding=15,
            border=ft.border.all(2, "#2196F3"),
            border_radius=10
        )

    def _build_report_card(self, report_info: dict) -> ft.Container:
        """Build direct report card"""

        def on_click(e):
            self.current_view_id = report_info["id"]
            self._render_org_chart()
            self._update_breadcrumb()
            self.page.update()

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            ft.Icon(ft.icons.PERSON, color="#FF9800"),
                            ft.Column(
                                controls=[
                                    ft.Text(
                                        report_info["name"], weight="bold"),
                                    ft.Text(
                                        report_info["position"], size=11, color="gray")
                                ],
                                expand=True
                            ),
                            ft.Icon(ft.icons.ARROW_FORWARD,
                                    color="gray", size=16)
                        ],
                        spacing=10
                    )
                ]
            ),
            padding=10,
            border=ft.border.all(1, ft.Colors.OUTLINE),
            border_radius=8,
            on_click=on_click
        )

    def _build_chain_card(self, manager_info: dict, level: str) -> ft.Container:
        """Build management chain card"""

        def on_click(e):
            self.current_view_id = manager_info["id"]
            self._render_org_chart()
            self._update_breadcrumb()
            self.page.update()

        return ft.Container(
            content=ft.Row(
                controls=[
                    ft.Container(
                        content=ft.Text(level, size=10, weight="bold"),
                        padding=5,
                        bgcolor="#F5F5F5",
                        border_radius=5,
                        width=60
                    ),
                    ft.Column(
                        controls=[
                            ft.Text(manager_info["name"], weight="bold"),
                            ft.Text(manager_info["position"],
                                    size=11, color="gray")
                        ],
                        expand=True
                    ),
                    ft.Icon(ft.icons.ARROW_FORWARD, color="gray", size=16)
                ],
                spacing=10
            ),
            padding=10,
            border=ft.border.all(1, ft.Colors.OUTLINE),
            border_radius=8,
            on_click=on_click
        )

    def _update_breadcrumb(self):
        """Update breadcrumb navigation"""

        self.breadcrumb.controls.clear()

        if not self.current_view_id:
            return

        # Get chain to root
        chain = OrgChartBuilder.get_management_chain(
            self.session, self.current_view_id)

        # Reverse to show root first
        chain.reverse()

        for i, person in enumerate(chain):
            btn = ft.TextButton(
                text=person["name"],
                on_click=lambda e, emp_id=person["id"]: self._navigate_to(
                    emp_id)
            )
            self.breadcrumb.controls.append(btn)

            if i < len(chain) - 1:
                self.breadcrumb.controls.append(
                    ft.Text("/", color="gray")
                )

    def _navigate_to(self, emp_id: int):
        """Navigate to employee"""
        self.current_view_id = emp_id
        self._render_org_chart()
        self._update_breadcrumb()
        self.page.update()

    def on_screen_load(self):
        """Called when screen loads"""
        self._render_org_chart()
        self._update_breadcrumb()

    def on_screen_unload(self):
        """Called when screen unloads"""
        pass
