"""
AI Assistant Screen - Local AI Chat with FAQ
Keyword-based search and action suggestions
"""

import flet as ft
from datetime import datetime
from sqlalchemy.orm import Session
from database.new_models import AIFAQEntry
from utils.ai_local_search import LocalAIAssistant
from core.base_screen import BaseScreen


class AIAssistantScreen(BaseScreen):
    """Local AI assistant with FAQ knowledge base"""

    def __init__(self, *args, **kwargs):
        page = kwargs.pop('page', None)
        user = kwargs.pop('user', None)
        session = kwargs.pop('session', None)
        employee_id = kwargs.pop('employee_id', None)

        if len(args) > 0:
            if isinstance(args[0], ft.Page):
                page = args[0]
            elif hasattr(args[0], 'query') or hasattr(args[0], 'add'):
                session = args[0]
        if len(args) > 1:
            if isinstance(args[1], (dict, object)) and not isinstance(args[1], int):
                user = args[1]
            elif isinstance(args[1], int):
                employee_id = args[1]

        super().__init__(page=page, **kwargs)

        if session is None:
            try:
                from database.session_manager import get_db_session
                session = get_db_session()
            except Exception:
                session = None
        self.session = session

        self.user = user
        if employee_id is None and user is not None:
            user_id = user.get('id') if isinstance(user, dict) else getattr(user, 'id', None)
            if user_id and session:
                try:
                    from database.session_manager import get_employee_by_user_id
                    emp = get_employee_by_user_id(session, user_id)
                    employee_id = emp.id if emp else user_id
                except Exception:
                    employee_id = user_id or 1
        if not employee_id:
            employee_id = 1
        self.employee_id = employee_id

        self.chat_history = []

        main_content = self.build_screen()
        if main_content:
            self.controls = [main_content]

    def build_screen(self):
        """Build AI assistant screen"""

        # Chat area
        self.chat_list = ft.ListView(
            auto_scroll=True,
            spacing=10,
            expand=True
        )

        # Input area
        input_field = ft.TextField(
            label="Ask me anything...",
            multiline=False,
            on_submit=lambda e: self._send_message(input_field, e)
        )

        send_btn = ft.IconButton(
            icon=ft.icons.SEND,
            on_click=lambda e: self._send_message(input_field, e)
        )

        # Suggestions
        self.suggestions_row = ft.Row(
            spacing=5,
            wrap=True,
            height=50
        )
        self._load_suggestions()

        main_content = ft.Column(
            controls=[
                ft.Container(
                    content=ft.Text("AI Assistant", size=24, weight="bold"),
                    padding=10
                ),
                ft.Container(
                    content=self.suggestions_row,
                    padding=10
                ),
                ft.Divider(),
                ft.Container(
                    content=self.chat_list,
                    expand=True
                ),
                ft.Row(
                    controls=[
                        ft.Container(
                            content=input_field,
                            expand=True
                        ),
                        send_btn
                    ],
                    spacing=5,
                    padding=10
                )
            ],
            expand=True
        )

        # Initialize default FAQs
        try:
            LocalAIAssistant.initialize_default_faqs(self.session)
        except:
            pass

        return main_content

    def _load_suggestions(self):
        """Load common action suggestions"""

        actions = [
            ("📋 Request Leave", "leave_request"),
            ("🔄 Change Status", "status_change"),
            ("👥 Find Colleague", "find_colleague"),
            ("✓ Check Attendance", "check_attendance"),
            ("📋 My Tasks", "task_update"),
            ("📅 Schedule Meeting", "meeting_schedule")
        ]

        self.suggestions_row.controls.clear()

        for label, action in actions:
            btn = ft.ElevatedButton(
                text=label,
                on_click=lambda e, a=action: self._handle_action(a),
                style=ft.ButtonStyle(
                    shape=ft.RoundedRectangleBorder(radius=20)
                )
            )
            self.suggestions_row.controls.append(btn)

    def _send_message(self, input_field: ft.TextField, e):
        """Send message to assistant"""

        query = input_field.value.strip()
        if not query:
            return

        # Clear input
        input_field.value = ""
        self.page.update()

        # Add user message to chat
        self._add_chat_message(query, "user")

        # Detect intent
        intent = LocalAIAssistant.detect_intent(query)

        if intent == "general_inquiry":
            # Search FAQ
            results = LocalAIAssistant.search_faq(self.session, query, limit=3)

            if results:
                # Add best match as response
                best_match = results[0]
                response = f"Based on your question, here's what I found:\n\n{best_match.answer}"
                self._add_chat_message(response, "assistant")

                # Add suggestions for other results if available
                if len(results) > 1:
                    self._add_suggestions_message(results[1:])
            else:
                response = "I didn't find a match in the knowledge base. Would you like to:\n• Contact HR\n• Check FAQ categories\n• Ask another question"
                self._add_chat_message(response, "assistant")
        else:
            # Handle action
            action_response = LocalAIAssistant.get_action_response(intent)
            message = action_response.get(
                "message", "Processing your request...")
            self._add_chat_message(message, "assistant")

            # Show action options if available
            if "options" in action_response:
                self._add_options_message(intent, action_response["options"])

    def _handle_action(self, action: str):
        """Handle action button click"""

        action_response = LocalAIAssistant.get_action_response(action)
        message = action_response.get("message", f"Opening {action}...")
        self._add_chat_message(message, "assistant")

        if "options" in action_response:
            self._add_options_message(action, action_response["options"])

    def _add_chat_message(self, text: str, sender: str):
        """Add message to chat"""

        # Determine message styling
        if sender == "user":
            bgcolor = "#E3F2FD"
            alignment = ft.MainAxisAlignment.END
            text_color = "#000000"
        else:
            bgcolor = "#F5F5F5"
            alignment = ft.MainAxisAlignment.START
            text_color = "#000000"

        message_bubble = ft.Container(
            content=ft.Column(
                controls=[
                    ft.Text(text, wrap=True, color=text_color, size=14),
                    ft.Text(
                        datetime.now().strftime("%H:%M"),
                        size=10,
                        color="gray"
                    )
                ],
                spacing=3
            ),
            padding=10,
            bgcolor=bgcolor,
            border_radius=10,
            width=300
        )

        row = ft.Row(
            controls=[message_bubble],
            alignment=alignment
        )

        self.chat_list.controls.append(row)
        self.page.update()

    def _add_suggestions_message(self, faqs: list):
        """Add FAQ suggestions"""

        for faq in faqs:
            suggestion_btn = ft.TextButton(
                text=faq.question[:50] +
                "..." if len(faq.question) > 50 else faq.question,
                on_click=lambda e, f=faq: self._show_faq_answer(f)
            )

            row = ft.Row(
                controls=[suggestion_btn],
                alignment=ft.MainAxisAlignment.START
            )

            self.chat_list.controls.append(row)

        self.page.update()

    def _add_options_message(self, intent: str, options: list):
        """Add clickable options"""

        buttons = []
        for option in options:
            if isinstance(option, dict):
                btn = ft.ElevatedButton(
                    text=option.get("label", ""),
                    on_click=lambda e, opt=option: self._handle_option(
                        intent, opt)
                )
            else:
                btn = ft.ElevatedButton(
                    text=str(option),
                    on_click=lambda e: self._add_chat_message(
                        f"You selected: {option}", "user")
                )
            buttons.append(btn)

        row = ft.Row(
            controls=buttons,
            spacing=5,
            wrap=True
        )

        container = ft.Container(
            content=row,
            padding=10
        )

        self.chat_list.controls.append(container)
        self.page.update()

    def _show_faq_answer(self, faq: AIFAQEntry, e=None):
        """Show FAQ answer"""

        response = LocalAIAssistant.format_response(faq)
        answer = f"**{faq.question}**\n\n{faq.answer}"
        self._add_chat_message(answer, "assistant")

    def _handle_option(self, intent: str, option: dict):
        """Handle option selection"""

        label = option.get("label", "")
        value = option.get("value", "")

        # Add user selection
        self._add_chat_message(f"Selected: {label}", "user")

        # Simulate response
        if intent == "status_change":
            response = f"Your status has been changed to {label}."
            self._add_chat_message(response, "assistant")
        elif intent == "find_colleague":
            response = f"Searching for colleagues in {label}..."
            self._add_chat_message(response, "assistant")
        else:
            response = f"Processing: {label}"
            self._add_chat_message(response, "assistant")

    def on_screen_load(self):
        """Called when screen loads"""
        # Add welcome message
        welcome = "Hello! 👋 I'm your AI Assistant. I can help you with:\n• Leave requests\n• Status changes\n• Finding colleagues\n• Attendance records\n• Task management\n• Meeting scheduling\n\nJust ask me anything!"
        self._add_chat_message(welcome, "assistant")

    def on_screen_unload(self):
        """Called when screen unloads"""
        pass
