"""
OKR Tracking Screen - Objectives and Key Results Management
Cascading OKRs with progress visualization
"""

import flet as ft
from datetime import date
from sqlalchemy.orm import Session
from database.new_models import OKRTracking, OKRStatus
from database.models import Employee, Department
from utils.okr_calculator import OKRCalculator
from core.base_screen import BaseScreen


class OKRTrackingScreen(BaseScreen):
    """OKR tracking and management dashboard"""

    def __init__(self, *args, **kwargs):
        page = kwargs.pop('page', None)
        user = kwargs.pop('user', None)
        session = kwargs.pop('session', None)
        employee_id = kwargs.pop('employee_id', None)

        if len(args) > 0:
            if isinstance(args[0], ft.Page):
                page = args[0]
            elif hasattr(args[0], 'query') or hasattr(args[0], 'add'):
                session = args[0]
        if len(args) > 1:
            if isinstance(args[1], (dict, object)) and not isinstance(args[1], int):
                user = args[1]
            elif isinstance(args[1], int):
                employee_id = args[1]

        super().__init__(page=page, **kwargs)

        if session is None:
            try:
                from database.session_manager import get_db_session
                session = get_db_session()
            except Exception:
                session = None
        self.session = session

        self.user = user
        if employee_id is None and user is not None:
            user_id = user.get('id') if isinstance(user, dict) else getattr(user, 'id', None)
            if user_id and session:
                try:
                    from database.session_manager import get_employee_by_user_id
                    emp = get_employee_by_user_id(session, user_id)
                    employee_id = emp.id if emp else user_id
                except Exception:
                    employee_id = user_id or 1
        if not employee_id:
            employee_id = 1
        self.employee_id = employee_id

        self.current_view = "company"

        main_content = self.build_screen()
        if main_content:
            self.controls = [main_content]

    def build_screen(self):
        """Build OKR tracking screen"""

        # Level selector
        level_selector = self._build_level_selector()

        # OKR list
        self.okr_list_container = ft.Column(spacing=10)
        self._refresh_okr_list()

        # Create OKR button
        create_btn = ft.ElevatedButton(
            text="Create New OKR",
            on_click=self._show_create_okr_dialog,
            icon=ft.icons.ADD
        )

        main_content = ft.Column(
            controls=[
                ft.Container(
                    content=ft.Text("OKR Management", size=24, weight="bold"),
                    padding=10
                ),
                level_selector,
                ft.Divider(),
                create_btn,
                ft.Divider(),
                ft.Container(
                    content=self.okr_list_container,
                    expand=True
                )
            ],
            scroll=ft.ScrollMode.AUTO,
            expand=True
        )

        return main_content

    def _build_level_selector(self) -> ft.Container:
        """Build level selector tabs"""

        def on_level_change(level):
            self.current_view = level
            self._refresh_okr_list()

        tabs = ft.Tabs(
            selected_index=0,
            on_change=lambda e: on_level_change(
                ["company", "team", "individual"][e.control.selected_index]),
            tabs=[
                ft.Tab(text="Company OKRs", content=ft.Text("")),
                ft.Tab(text="Team OKRs", content=ft.Text("")),
                ft.Tab(text="My OKRs", content=ft.Text(""))
            ]
        )

        return ft.Container(content=tabs, padding=5)

    def _refresh_okr_list(self):
        """Refresh OKR list"""

        self.okr_list_container.controls.clear()

        if self.current_view == "company":
            okrs = self._get_company_okrs()
        elif self.current_view == "team":
            okrs = self._get_team_okrs()
        else:
            okrs = self._get_individual_okrs()

        if not okrs:
            self.okr_list_container.controls.append(
                ft.Text("No OKRs found", color="gray")
            )
            return

        for okr in okrs:
            okr_card = self._build_okr_card(okr)
            self.okr_list_container.controls.append(okr_card)

    def _get_company_okrs(self):
        """Get company-level OKRs"""
        today = date.today()
        return self.session.query(OKRTracking).filter(
            OKRTracking.level == "company",
            OKRTracking.start_date <= today,
            OKRTracking.end_date >= today
        ).all()

    def _get_team_okrs(self):
        """Get team-level OKRs"""
        employee = self.session.query(Employee).get(self.employee_id)
        if not employee or not employee.team_id:
            return []

        today = date.today()
        return self.session.query(OKRTracking).filter(
            OKRTracking.level == "team",
            OKRTracking.level_id == employee.team_id,
            OKRTracking.start_date <= today,
            OKRTracking.end_date >= today
        ).all()

    def _get_individual_okrs(self):
        """Get individual OKRs"""
        today = date.today()
        return self.session.query(OKRTracking).filter(
            OKRTracking.level == "individual",
            OKRTracking.level_id == self.employee_id,
            OKRTracking.start_date <= today,
            OKRTracking.end_date >= today
        ).all()

    def _build_okr_card(self, okr: OKRTracking) -> ft.Container:
        """Build OKR card"""

        progress = OKRCalculator.calculate_okr_progress(okr)

        # Status color
        status_colors = {
            OKRStatus.NOT_STARTED: "#9E9E9E",
            OKRStatus.ON_TRACK: "#4CAF50",
            OKRStatus.AT_RISK: "#FF9800",
            OKRStatus.COMPLETED: "#2196F3",
            OKRStatus.ABANDONED: "#F44336"
        }

        # Build key results
        kr_controls = []

        for i, kr_title in enumerate([okr.key_result_1, okr.key_result_2, okr.key_result_3], 1):
            if kr_title:
                if i == 1:
                    current, target, unit = okr.kr1_current_value, okr.kr1_target_value, okr.kr1_unit
                elif i == 2:
                    current, target, unit = okr.kr2_current_value, okr.kr2_target_value, okr.kr2_unit
                else:
                    current, target, unit = okr.kr3_current_value, okr.kr3_target_value, okr.kr3_unit

                kr_progress = OKRCalculator.calculate_kr_progress(
                    current or 0, target or 0)

                kr_controls.append(
                    ft.Column(
                        controls=[
                            ft.Text(kr_title, size=12),
                            ft.ProgressBar(
                                value=kr_progress / 100,
                                height=8,
                                color=status_colors[okr.status]
                            ),
                            ft.Text(
                                f"{current or 0} / {target or 0} {unit or ''}",
                                size=10,
                                color="gray"
                            )
                        ],
                        spacing=3
                    )
                )

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            ft.Column(
                                controls=[
                                    ft.Text(okr.objective, size=14,
                                            weight="bold"),
                                    ft.Text(
                                        f"Status: {okr.status.value}",
                                        size=12,
                                        color=status_colors[okr.status]
                                    )
                                ],
                                expand=True
                            ),
                            ft.Text(f"{progress:.0f}%", size=16, weight="bold")
                        ],
                        spacing=10
                    ),
                    ft.Divider(height=10),
                    ft.Column(controls=kr_controls, spacing=8),
                    ft.Row(
                        controls=[
                            ft.IconButton(
                                icon=ft.icons.EDIT,
                                tooltip="Edit",
                                on_click=lambda e: self._show_edit_okr_dialog(
                                    okr)
                            ),
                            ft.IconButton(
                                icon=ft.icons.DELETE,
                                tooltip="Delete",
                                on_click=lambda e: self._delete_okr(okr.id)
                            )
                        ]
                    )
                ]
            ),
            padding=10,
            border=ft.border.all(1, ft.Colors.OUTLINE),
            border_radius=8
        )

    def _show_create_okr_dialog(self, e):
        """Show create OKR dialog"""

        # Form fields
        objective_field = ft.TextField(
            label="Objective",
            multiline=True,
            min_lines=2
        )

        kr1_field = ft.TextField(label="Key Result 1")
        kr2_field = ft.TextField(label="Key Result 2")
        kr3_field = ft.TextField(label="Key Result 3")

        def save_okr(e):
            try:
                if not objective_field.value:
                    self.page.snack_bar = ft.SnackBar(
                        ft.Text("Objective required"))
                    self.page.snack_bar.open = True
                    self.page.update()
                    return

                key_results = [
                    kr1_field.value,
                    kr2_field.value,
                    kr3_field.value
                ]

                OKRCalculator.create_okr(
                    self.session,
                    self.current_view,
                    self.employee_id if self.current_view == "individual" else 1,
                    objective_field.value,
                    key_results,
                    self.employee_id,
                    date.today(),
                    date.today().replace(year=date.today().year + 1)
                )

                self.session.commit()
                self._refresh_okr_list()
                self.page.dialog.open = False
                self.page.update()

            except Exception as ex:
                self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
                self.page.snack_bar.open = True
                self.page.update()

        dialog = ft.AlertDialog(
            title=ft.Text("Create New OKR"),
            content=ft.Column(
                controls=[
                    objective_field,
                    kr1_field,
                    kr2_field,
                    kr3_field
                ],
                spacing=10
            ),
            actions=[
                ft.TextButton(
                    "Cancel", on_click=lambda e: self._close_dialog()),
                ft.TextButton("Save", on_click=save_okr)
            ]
        )

        self.page.dialog = dialog
        dialog.open = True
        self.page.update()

    def _show_edit_okr_dialog(self, okr: OKRTracking, e):
        """Show edit OKR dialog"""
        # Implementation similar to create
        pass

    def _delete_okr(self, okr_id: int):
        """Delete OKR"""
        try:
            okr = self.session.query(OKRTracking).get(okr_id)
            if okr:
                self.session.delete(okr)
                self.session.commit()
                self._refresh_okr_list()
                self.page.update()
        except Exception as ex:
            self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
            self.page.snack_bar.open = True
            self.page.update()

    def _close_dialog(self):
        """Close current dialog"""
        self.page.dialog.open = False
        self.page.update()

    def on_screen_load(self):
        """Called when screen loads"""
        self._refresh_okr_list()

    def on_screen_unload(self):
        """Called when screen unloads"""
        pass
