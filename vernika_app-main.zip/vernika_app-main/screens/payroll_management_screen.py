"""
Payroll Management Screen - Salary Slips and Payroll Processing
Multi-currency payroll with tax and deductions
"""

import flet as ft
from datetime import datetime, date
from decimal import Decimal
from sqlalchemy.orm import Session
from database.new_models import SalarySlip
from database.models import Employee, Department
from utils.payroll_calculator import PayrollCalculator
from utils.pdf_generator import PDFGenerator
from core.base_screen import BaseScreen


class PayrollManagementScreen(BaseScreen):
    """Payroll management and salary slip generation"""

    def __init__(self, *args, **kwargs):
        page = kwargs.pop('page', None)
        user = kwargs.pop('user', None)
        session = kwargs.pop('session', None)
        employee_id = kwargs.pop('employee_id', None)

        if len(args) > 0:
            if isinstance(args[0], ft.Page):
                page = args[0]
            elif hasattr(args[0], 'query') or hasattr(args[0], 'add'):
                session = args[0]
        if len(args) > 1:
            if isinstance(args[1], (dict, object)) and not isinstance(args[1], int):
                user = args[1]
            elif isinstance(args[1], int):
                employee_id = args[1]

        super().__init__(page=page, **kwargs)

        if session is None:
            try:
                from database.session_manager import get_db_session
                session = get_db_session()
            except Exception:
                session = None
        self.session = session

        self.user = user
        if employee_id is None and user is not None:
            user_id = user.get('id') if isinstance(user, dict) else getattr(user, 'id', None)
            if user_id and session:
                try:
                    from database.session_manager import get_employee_by_user_id
                    emp = get_employee_by_user_id(session, user_id)
                    employee_id = emp.id if emp else user_id
                except Exception:
                    employee_id = user_id or 1
        if not employee_id:
            employee_id = 1
        self.employee_id = employee_id

        self.current_month = datetime.now().month
        self.current_year = datetime.now().year

        main_content = self.build_screen()
        if main_content:
            self.controls = [main_content]

    def build_screen(self):
        """Build payroll management screen"""

        # Period selector
        period_selector = self._build_period_selector()

        # Department filter
        department_filter = self._build_department_filter()

        # Payroll summary
        summary_panel = self._build_summary_panel()

        # Salary slips list
        self.slips_container = ft.Column(spacing=10)
        self._refresh_salary_slips()

        # Action buttons
        action_buttons = ft.Row(
            controls=[
                ft.ElevatedButton(
                    text="Generate Payroll",
                    on_click=self._generate_payroll,
                    icon=ft.icons.PAYMENT
                ),
                ft.ElevatedButton(
                    text="Download PDFs",
                    on_click=self._download_payroll_pdfs,
                    icon=ft.icons.DOWNLOAD
                ),
                ft.ElevatedButton(
                    text="Tax Settings",
                    on_click=self._show_tax_settings,
                    icon=ft.icons.SETTINGS
                )
            ],
            spacing=10
        )

        main_content = ft.Column(
            controls=[
                ft.Container(
                    content=ft.Text("Payroll Management",
                                    size=24, weight="bold"),
                    padding=10
                ),
                period_selector,
                department_filter,
                ft.Divider(),
                summary_panel,
                ft.Divider(),
                action_buttons,
                ft.Divider(),
                ft.Container(
                    content=self.slips_container,
                    expand=True
                )
            ],
            scroll=ft.ScrollMode.AUTO,
            expand=True
        )

        return main_content

    def _build_period_selector(self) -> ft.Container:
        """Build period selector"""

        month_dropdown = ft.Dropdown(
            label="Month",
            options=[
                ft.dropdown.Option(str(i))
                for i in range(1, 13)
            ],
            value=str(self.current_month),
            width=100
        )

        year_dropdown = ft.Dropdown(
            label="Year",
            options=[
                ft.dropdown.Option(str(y))
                for y in range(2020, 2026)
            ],
            value=str(self.current_year),
            width=100
        )

        def on_period_change(e):
            self.current_month = int(month_dropdown.value)
            self.current_year = int(year_dropdown.value)
            self._refresh_salary_slips()

        month_dropdown.on_change = on_period_change
        year_dropdown.on_change = on_period_change

        return ft.Container(
            content=ft.Row(
                controls=[
                    ft.Text("Period:", weight="bold"),
                    month_dropdown,
                    year_dropdown
                ],
                spacing=10
            ),
            padding=10
        )

    def _build_department_filter(self) -> ft.Container:
        """Build department filter"""

        departments = self.session.query(Department).all()

        self.dept_dropdown = ft.Dropdown(
            label="Filter by Department",
            options=[
                ft.dropdown.Option("All Departments", key="all")
            ] + [
                ft.dropdown.Option(d.name, key=str(d.id))
                for d in departments
            ],
            value="All Departments",
            width=200
        )

        self.dept_dropdown.on_change = lambda e: self._refresh_salary_slips()

        return ft.Container(
            content=self.dept_dropdown,
            padding=10
        )

    def _build_summary_panel(self) -> ft.Container:
        """Build payroll summary"""

        self.total_gross = ft.Text("$0.00", size=18, weight="bold")
        self.total_net = ft.Text("$0.00", size=18, weight="bold")
        self.total_deductions = ft.Text("$0.00", size=18, weight="bold")
        self.employee_count = ft.Text("0", size=18, weight="bold")

        return ft.Container(
            content=ft.Row(
                controls=[
                    ft.Column(
                        controls=[
                            ft.Text("Total Gross", size=12, color="gray"),
                            self.total_gross
                        ]
                    ),
                    ft.Column(
                        controls=[
                            ft.Text("Total Deductions", size=12, color="gray"),
                            self.total_deductions
                        ]
                    ),
                    ft.Column(
                        controls=[
                            ft.Text("Total Net", size=12, color="gray"),
                            self.total_net
                        ]
                    ),
                    ft.Column(
                        controls=[
                            ft.Text("Employees", size=12, color="gray"),
                            self.employee_count
                        ]
                    )
                ],
                spacing=40
            ),
            padding=20,
            bgcolor=ft.Colors.SURFACE_VARIANT,
            border_radius=10
        )

    def _refresh_salary_slips(self):
        """Refresh salary slip list"""

        self.slips_container.controls.clear()

        # Get department filter
        dept_id = None
        if self.dept_dropdown.value != "All Departments":
            for opt in self.dept_dropdown.options:
                if opt.label == self.dept_dropdown.value:
                    dept_id = int(opt.key)
                    break

        # Get payroll summary
        summary = PayrollCalculator.get_payroll_summary(
            self.session,
            self.current_month,
            self.current_year,
            dept_id
        )

        # Update summary display
        self.total_gross.value = f"${summary['total_gross_salary']:,.2f}"
        self.total_net.value = f"${summary['total_net_salary']:,.2f}"
        self.total_deductions.value = f"${summary['total_deductions']:,.2f}"
        self.employee_count.value = str(summary['employee_count'])

        # Get salary slips
        from database.models import Employee as Emp

        query = self.session.query(SalarySlip).filter(
            SalarySlip.fiscal_month == self.current_month,
            SalarySlip.fiscal_year == self.current_year
        )

        if dept_id:
            emp_ids = [e.id for e in self.session.query(Emp).filter(
                Emp.department_id == dept_id
            ).all()]
            query = query.filter(SalarySlip.employee_id.in_(emp_ids))

        slips = query.all()

        if not slips:
            self.slips_container.controls.append(
                ft.Text("No salary slips found", color="gray")
            )
            return

        for slip in slips:
            card = self._build_salary_slip_card(slip)
            self.slips_container.controls.append(card)

    def _build_salary_slip_card(self, slip: SalarySlip) -> ft.Container:
        """Build salary slip card"""

        employee = self.session.query(Employee).get(slip.employee_id)

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            ft.Column(
                                controls=[
                                    ft.Text(
                                        f"{employee.first_name} {employee.last_name}",
                                        size=14,
                                        weight="bold"
                                    ),
                                    ft.Text(
                                        employee.employee_id or "N/A",
                                        size=12,
                                        color="gray"
                                    )
                                ],
                                expand=True
                            ),
                            ft.Column(
                                controls=[
                                    ft.Text(
                                        f"${slip.gross_salary:,.2f}",
                                        size=14,
                                        weight="bold"
                                    ),
                                    ft.Text("Gross", size=10, color="gray")
                                ]
                            ),
                            ft.Column(
                                controls=[
                                    ft.Text(
                                        f"${slip.total_deductions:,.2f}",
                                        size=14,
                                        weight="bold",
                                        color="#F44336"
                                    ),
                                    ft.Text("Deductions",
                                            size=10, color="gray")
                                ]
                            ),
                            ft.Column(
                                controls=[
                                    ft.Text(
                                        f"${slip.net_salary:,.2f}",
                                        size=14,
                                        weight="bold",
                                        color="#4CAF50"
                                    ),
                                    ft.Text("Net", size=10, color="gray")
                                ]
                            )
                        ],
                        spacing=20
                    ),
                    ft.Divider(height=10),
                    ft.Row(
                        controls=[
                            ft.IconButton(
                                icon=ft.icons.VISIBILITY,
                                tooltip="View Details",
                                on_click=lambda e: self._show_slip_details(
                                    slip)
                            ),
                            ft.IconButton(
                                icon=ft.icons.DOWNLOAD,
                                tooltip="Download PDF",
                                on_click=lambda e: self._download_slip_pdf(
                                    slip)
                            )
                        ]
                    )
                ]
            ),
            padding=10,
            border=ft.border.all(1, ft.Colors.OUTLINE),
            border_radius=8
        )

    def _show_slip_details(self, slip: SalarySlip, e=None):
        """Show salary slip details"""

        summary = PayrollCalculator.get_salary_slip_summary(slip)

        content = ft.Column(
            controls=[
                ft.Row(
                    controls=[
                        ft.Column(
                            controls=[
                                ft.Text("Gross Salary", size=12, color="gray"),
                                ft.Text(
                                    f"${summary['gross_salary']:,.2f}",
                                    size=16,
                                    weight="bold"
                                )
                            ]
                        ),
                        ft.Column(
                            controls=[
                                ft.Text("Total Deductions",
                                        size=12, color="gray"),
                                ft.Text(
                                    f"${summary['deductions']['total']:,.2f}",
                                    size=16,
                                    weight="bold"
                                )
                            ]
                        ),
                        ft.Column(
                            controls=[
                                ft.Text("Net Salary", size=12, color="gray"),
                                ft.Text(
                                    f"${summary['net_salary']:,.2f}",
                                    size=16,
                                    weight="bold",
                                    color="#4CAF50"
                                )
                            ]
                        )
                    ],
                    spacing=40
                ),
                ft.Divider(),
                ft.Text("Deduction Details", weight="bold"),
                ft.Column(
                    controls=[
                        ft.Row(
                            controls=[
                                ft.Text("Provident Fund", expand=True),
                                ft.Text(
                                    f"${summary['deductions']['provident_fund']:,.2f}")
                            ]
                        ),
                        ft.Row(
                            controls=[
                                ft.Text("Health Insurance", expand=True),
                                ft.Text(
                                    f"${summary['deductions']['health_insurance']:,.2f}")
                            ]
                        ),
                        ft.Row(
                            controls=[
                                ft.Text("Income Tax", expand=True),
                                ft.Text(
                                    f"${summary['deductions']['tax']:,.2f}")
                            ]
                        )
                    ],
                    spacing=8
                )
            ],
            spacing=15
        )

        dialog = ft.AlertDialog(
            title=ft.Text("Salary Slip Details"),
            content=content,
            actions=[
                ft.TextButton("Close", on_click=lambda e: self._close_dialog())
            ]
        )

        self.page.dialog = dialog
        dialog.open = True
        self.page.update()

    def _download_slip_pdf(self, slip: SalarySlip, e=None):
        """Download salary slip as PDF"""

        try:
            output_path = PDFGenerator.generate_salary_slip_pdf(
                self.session,
                slip.id
            )

            self.page.snack_bar = ft.SnackBar(
                ft.Text(f"PDF generated: {output_path}")
            )
            self.page.snack_bar.open = True
            self.page.update()

        except Exception as ex:
            self.page.snack_bar = ft.SnackBar(
                ft.Text(f"Error: {str(ex)}")
            )
            self.page.snack_bar.open = True
            self.page.update()

    def _generate_payroll(self, e):
        """Generate payroll for period"""

        try:
            # Get department filter
            dept_id = None
            if self.dept_dropdown.value != "All Departments":
                for opt in self.dept_dropdown.options:
                    if opt.label == self.dept_dropdown.value:
                        dept_id = int(opt.key)
                        break

            # Generate salary slips
            from database.models import Employee as Emp

            if dept_id:
                employees = self.session.query(Emp).filter(
                    Emp.department_id == dept_id
                ).all()
            else:
                employees = self.session.query(Emp).all()

            count = 0
            for emp in employees:
                slip = PayrollCalculator.generate_salary_slip(
                    self.session,
                    emp.id,
                    self.current_month,
                    self.current_year
                )
                if slip:
                    count += 1

            self.page.snack_bar = ft.SnackBar(
                ft.Text(f"Generated {count} salary slips")
            )
            self.page.snack_bar.open = True
            self._refresh_salary_slips()
            self.page.update()

        except Exception as ex:
            self.page.snack_bar = ft.SnackBar(
                ft.Text(f"Error: {str(ex)}")
            )
            self.page.snack_bar.open = True
            self.page.update()

    def _download_payroll_pdfs(self, e):
        """Download all payroll PDFs"""

        try:
            # Get department filter
            dept_id = None
            if self.dept_dropdown.value != "All Departments":
                for opt in self.dept_dropdown.options:
                    if opt.label == self.dept_dropdown.value:
                        dept_id = int(opt.key)
                        break

            paths = PDFGenerator.generate_batch_payroll_pdf(
                self.session,
                self.current_month,
                self.current_year,
                dept_id
            )

            self.page.snack_bar = ft.SnackBar(
                ft.Text(f"Generated {len(paths)} PDFs")
            )
            self.page.snack_bar.open = True
            self.page.update()

        except Exception as ex:
            self.page.snack_bar = ft.SnackBar(
                ft.Text(f"Error: {str(ex)}")
            )
            self.page.snack_bar.open = True
            self.page.update()

    def _show_tax_settings(self, e):
        """Show tax configuration dialog"""

        config = PayrollCalculator.get_or_create_config(self.session)

        tax_rate_field = ft.TextField(
            label="Tax Rate (%)",
            value=str(config.tax_rate),
            keyboard_type=ft.KeyboardType.NUMBER
        )

        pf_rate_field = ft.TextField(
            label="Provident Fund (%)",
            value=str(config.provident_fund_rate),
            keyboard_type=ft.KeyboardType.NUMBER
        )

        hi_rate_field = ft.TextField(
            label="Health Insurance (%)",
            value=str(config.health_insurance_rate),
            keyboard_type=ft.KeyboardType.NUMBER
        )

        def save_settings(e):
            try:
                PayrollCalculator.update_tax_configuration(
                    self.session,
                    float(tax_rate_field.value),
                    "Income Tax"
                )

                PayrollCalculator.update_deduction_rates(
                    self.session,
                    float(pf_rate_field.value),
                    float(hi_rate_field.value)
                )

                self.page.snack_bar = ft.SnackBar(ft.Text("Settings updated"))
                self.page.snack_bar.open = True
                self._close_dialog()
                self.page.update()

            except Exception as ex:
                self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
                self.page.snack_bar.open = True
                self.page.update()

        dialog = ft.AlertDialog(
            title=ft.Text("Tax and Deduction Settings"),
            content=ft.Column(
                controls=[
                    tax_rate_field,
                    pf_rate_field,
                    hi_rate_field
                ],
                spacing=10
            ),
            actions=[
                ft.TextButton(
                    "Cancel", on_click=lambda e: self._close_dialog()),
                ft.TextButton("Save", on_click=save_settings)
            ]
        )

        self.page.dialog = dialog
        dialog.open = True
        self.page.update()

    def _close_dialog(self):
        """Close dialog"""
        self.page.dialog.open = False
        self.page.update()

    def on_screen_load(self):
        """Called when screen loads"""
        self._refresh_salary_slips()

    def on_screen_unload(self):
        """Called when screen unloads"""
        pass
