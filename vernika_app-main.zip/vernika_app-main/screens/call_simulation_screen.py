"""
Call Simulation Screen - In-App Call UI
Mock WebRTC calls with full call controls and history
"""

import flet as ft
from datetime import datetime
from sqlalchemy.orm import Session
from database.new_models import EnhancedCallLog, CallType, CallStatus
from database.models import Employee
from utils.call_logger import CallLogger
from core.base_screen import BaseScreen


class CallSimulationScreen(BaseScreen):
    """Simulated call interface"""

    def __init__(self, *args, **kwargs):
        page = kwargs.pop('page', None)
        user = kwargs.pop('user', None)
        session = kwargs.pop('session', None)
        employee_id = kwargs.pop('employee_id', None)

        if len(args) > 0:
            if isinstance(args[0], ft.Page):
                page = args[0]
            elif hasattr(args[0], 'query') or hasattr(args[0], 'add'):
                session = args[0]
        if len(args) > 1:
            if isinstance(args[1], (dict, object)) and not isinstance(args[1], int):
                user = args[1]
            elif isinstance(args[1], int):
                employee_id = args[1]

        super().__init__(page=page, **kwargs)

        if session is None:
            try:
                from database.session_manager import get_db_session
                session = get_db_session()
            except Exception:
                session = None
        self.session = session

        self.user = user
        if employee_id is None and user is not None:
            user_id = user.get('id') if isinstance(user, dict) else getattr(user, 'id', None)
            if user_id and session:
                try:
                    from database.session_manager import get_employee_by_user_id
                    emp = get_employee_by_user_id(session, user_id)
                    employee_id = emp.id if emp else user_id
                except Exception:
                    employee_id = user_id or 1
        if not employee_id:
            employee_id = 1
        self.employee_id = employee_id

        self.active_call = None
        self.call_timer = 0

        main_content = self.build_screen()
        if main_content:
            self.controls = [main_content]

    def build_screen(self):
        """Build call simulation screen"""

        # Call initiation panel
        initiation_panel = self._build_initiation_panel()

        # Active call panel
        self.active_call_panel = self._build_active_call_panel()

        # Call history
        history_panel = self._build_history_panel()

        # Main content
        main_content = ft.Column(
            controls=[
                ft.Container(
                    content=ft.Text("Call Simulation", size=24, weight="bold"),
                    padding=10
                ),
                initiation_panel,
                ft.Divider(),
                self.active_call_panel,
                ft.Divider(),
                history_panel
            ],
            scroll=ft.ScrollMode.AUTO
        )

        return main_content

    def _build_initiation_panel(self) -> ft.Container:
        """Build call initiation panel"""

        # Employee selection
        self.recipient_dropdown = ft.Dropdown(
            label="Select Contact",
            width=200
        )
        self._load_employee_list()

        # Call type selection
        self.call_type_dropdown = ft.Dropdown(
            label="Call Type",
            options=[
                ft.dropdown.Option("Audio"),
                ft.dropdown.Option("Video"),
                ft.dropdown.Option("Huddle")
            ],
            value="Audio",
            width=150
        )

        # Call initiation button
        call_btn = ft.ElevatedButton(
            text="Initiate Call",
            on_click=self._initiate_call,
            icon=ft.icons.CALL
        )

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Text("Initiate New Call", size=16, weight="bold"),
                    ft.Row(
                        controls=[
                            self.recipient_dropdown,
                            self.call_type_dropdown,
                            call_btn
                        ],
                        spacing=10
                    )
                ]
            ),
            padding=10,
            bgcolor=ft.Colors.SURFACE_VARIANT,
            border_radius=10
        )

    def _build_active_call_panel(self) -> ft.Container:
        """Build active call panel"""

        self.call_recipient_name = ft.Text(
            "No active call", size=18, weight="bold")
        self.call_timer_display = ft.Text("00:00", size=32, weight="bold")
        self.call_type_display = ft.Text("")

        # Call control buttons
        self.mute_btn = ft.IconButton(
            icon=ft.icons.MIC,
            icon_size=30,
            tooltip="Mute"
        )

        self.video_btn = ft.IconButton(
            icon=ft.icons.VIDEOCAM_OFF,
            icon_size=30,
            tooltip="Enable Video"
        )

        self.end_call_btn = ft.IconButton(
            icon=ft.icons.CALL_END,
            icon_size=30,
            on_click=self._end_call,
            tooltip="End Call"
        )

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Text("Active Call", size=16, weight="bold"),
                    ft.Container(
                        content=ft.Column(
                            controls=[
                                self.call_recipient_name,
                                self.call_type_display,
                                ft.Divider(),
                                self.call_timer_display,
                                ft.Row(
                                    controls=[
                                        self.mute_btn,
                                        self.video_btn,
                                        self.end_call_btn
                                    ],
                                    spacing=10,
                                    alignment=ft.MainAxisAlignment.CENTER
                                )
                            ],
                            alignment=ft.MainAxisAlignment.CENTER,
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER
                        ),
                        padding=20
                    )
                ]
            ),
            padding=10,
            bgcolor=ft.Colors.SURFACE_VARIANT,
            border_radius=10
        )

    def _build_history_panel(self) -> ft.Container:
        """Build call history panel"""

        self.history_list = ft.Column(spacing=5)
        self._refresh_call_history()

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Text("Call History", size=16, weight="bold"),
                    ft.Divider(height=10),
                    ft.Container(
                        content=self.history_list,
                        expand=True
                    )
                ]
            ),
            padding=10
        )

    def _load_employee_list(self):
        """Load employee list for dropdown"""

        employees = self.session.query(Employee).all()

        options = []
        for emp in employees:
            if emp.id != self.employee_id:  # Don't call self
                options.append(
                    ft.dropdown.Option(
                        f"{emp.first_name} {emp.last_name}",
                        key=str(emp.id)
                    )
                )

        self.recipient_dropdown.options = options

    def _initiate_call(self, e):
        """Initiate a call"""

        if not self.recipient_dropdown.value:
            self.page.snack_bar = ft.SnackBar(
                ft.Text("Please select a contact"))
            self.page.snack_bar.open = True
            self.page.update()
            return

        try:
            # Find employee ID from dropdown
            recipient_id = None
            for opt in self.recipient_dropdown.options:
                if opt.label == self.recipient_dropdown.value:
                    recipient_id = int(opt.key)
                    break

            if not recipient_id:
                return

            # Map call type
            call_type_map = {
                "Audio": CallType.AUDIO,
                "Video": CallType.VIDEO,
                "Huddle": CallType.HUDDLE
            }
            call_type = call_type_map.get(
                self.call_type_dropdown.value, CallType.AUDIO)

            # Create call
            self.active_call = CallLogger.initiate_call(
                self.session,
                self.employee_id,
                recipient_id,
                call_type
            )

            # Connect call
            CallLogger.update_call_status(
                self.session, self.active_call.id, CallStatus.CONNECTED
            )

            self._refresh_active_call_display()

            self.page.snack_bar = ft.SnackBar(ft.Text("Call initiated"))
            self.page.snack_bar.open = True
            self.page.update()

        except Exception as ex:
            self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
            self.page.snack_bar.open = True
            self.page.update()

    def _end_call(self, e):
        """End active call"""

        if not self.active_call:
            return

        try:
            CallLogger.update_call_status(
                self.session, self.active_call.id, CallStatus.ENDED
            )

            self.session.commit()
            self.active_call = None
            self.call_timer = 0

            self._refresh_active_call_display()
            self._refresh_call_history()

            self.page.snack_bar = ft.SnackBar(ft.Text("Call ended"))
            self.page.snack_bar.open = True
            self.page.update()

        except Exception as ex:
            self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
            self.page.snack_bar.open = True
            self.page.update()

    def _refresh_active_call_display(self):
        """Refresh active call display"""

        if self.active_call:
            recipient = self.session.query(Employee).get(
                self.active_call.recipient_id)
            if recipient:
                self.call_recipient_name.value = f"{recipient.first_name} {recipient.last_name}"

            call_type_map = {
                CallType.AUDIO: "Audio Call",
                CallType.VIDEO: "Video Call",
                CallType.HUDDLE: "Huddle"
            }
            self.call_type_display.value = call_type_map.get(
                self.active_call.call_type, "Call")
        else:
            self.call_recipient_name.value = "No active call"
            self.call_type_display.value = ""
            self.call_timer_display.value = "00:00"

    def _refresh_call_history(self):
        """Refresh call history list"""

        calls = CallLogger.get_call_history(
            self.session, self.employee_id, limit=20)

        self.history_list.controls.clear()

        for call in calls:
            if call.initiator_id == self.employee_id:
                contact_id = call.recipient_id
                direction = "Outgoing"
            else:
                contact_id = call.initiator_id
                direction = "Incoming"

            contact = self.session.query(Employee).get(contact_id)
            contact_name = f"{contact.first_name} {contact.last_name}" if contact else "Unknown"

            duration = CallLogger.get_call_duration_formatted(call)

            status_color = {
                CallStatus.ENDED: "#4CAF50",
                CallStatus.REJECTED: "#F44336",
                CallStatus.MISSED: "#FF9800"
            }.get(call.status, "#2196F3")

            self.history_list.controls.append(
                ft.Container(
                    content=ft.Row(
                        controls=[
                            ft.Icon(
                                ft.icons.CALL_RECEIVED if direction == "Incoming" else ft.icons.CALL_MADE,
                                color=status_color
                            ),
                            ft.Column(
                                controls=[
                                    ft.Text(contact_name, size=14,
                                            weight="bold"),
                                    ft.Text(call.created_at.strftime(
                                        "%H:%M - %d %b"), size=12, color="gray")
                                ],
                                expand=True
                            ),
                            ft.Text(duration, size=12)
                        ],
                        spacing=10
                    ),
                    padding=10,
                    border_radius=5,
                    border=ft.border.all(1, ft.colors.OUTLINE)
                )
            )

    def on_screen_load(self):
        """Called when screen loads"""
        self._refresh_call_history()
        self._load_employee_list()

    def on_screen_unload(self):
        """Called when screen unloads"""
        if self.active_call:
            CallLogger.update_call_status(
                self.session, self.active_call.id, CallStatus.ENDED
            )
            self.session.commit()
