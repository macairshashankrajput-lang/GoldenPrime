"""
Onboarding Pipeline Screen - Digital Onboarding Workflow
Task management and document collection
"""

import flet as ft
from datetime import datetime
from sqlalchemy.orm import Session
from database.new_models import OnboardingTask, OnboardingDocument
from utils.onboarding_manager import OnboardingManager
from core.base_screen import BaseScreen


class OnboardingPipelineScreen(BaseScreen):
    """Digital onboarding workflow management"""

    def __init__(self, *args, **kwargs):
        page = kwargs.pop('page', None)
        user = kwargs.pop('user', None)
        session = kwargs.pop('session', None)
        employee_id = kwargs.pop('employee_id', None)

        if len(args) > 0:
            if isinstance(args[0], ft.Page):
                page = args[0]
            elif hasattr(args[0], 'query') or hasattr(args[0], 'add'):
                session = args[0]
        if len(args) > 1:
            if isinstance(args[1], (dict, object)) and not isinstance(args[1], int):
                user = args[1]
            elif isinstance(args[1], int):
                employee_id = args[1]

        super().__init__(page=page, **kwargs)

        if session is None:
            try:
                from database.session_manager import get_db_session
                session = get_db_session()
            except Exception:
                session = None
        self.session = session

        self.user = user
        if employee_id is None and user is not None:
            user_id = user.get('id') if isinstance(user, dict) else getattr(user, 'id', None)
            if user_id and session:
                try:
                    from database.session_manager import get_employee_by_user_id
                    emp = get_employee_by_user_id(session, user_id)
                    employee_id = emp.id if emp else user_id
                except Exception:
                    employee_id = user_id or 1
        if not employee_id:
            employee_id = 1
        self.employee_id = employee_id

        main_content = self.build_screen()
        if main_content:
            self.controls = [main_content]

    def build_screen(self):
        """Build onboarding screen"""

        # Progress bar
        progress_bar = self._build_progress_panel()

        # Tab selector
        self.tab_control = ft.Tabs(
            selected_index=0,
            on_change=self._on_tab_change,
            tabs=[
                ft.Tab(text="Tasks", content=ft.Container()),
                ft.Tab(text="Documents", content=ft.Container()),
                ft.Tab(text="Timeline", content=ft.Container())
            ]
        )

        # Container for tab content
        self.content_container = ft.Column(
            expand=True,
            scroll=ft.ScrollMode.AUTO
        )

        # Update initial content
        self._refresh_content()

        main_content = ft.Column(
            controls=[
                ft.Container(
                    content=ft.Text("Onboarding Pipeline",
                                    size=24, weight="bold"),
                    padding=10
                ),
                progress_bar,
                ft.Divider(),
                self.tab_control,
                self.content_container
            ],
            expand=True
        )

        return main_content

    def _build_progress_panel(self) -> ft.Container:
        """Build progress panel"""

        progress_data = OnboardingManager.get_onboarding_progress(
            self.session, self.employee_id
        )

        progress_percent = progress_data["progress_percent"] / 100
        completed = progress_data["completed_tasks"]
        total = progress_data["total_tasks"]

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            ft.Column(
                                controls=[
                                    ft.Text("Onboarding Progress",
                                            size=14, weight="bold"),
                                    ft.Text(
                                        f"{completed} of {total} tasks completed",
                                        size=12,
                                        color="gray"
                                    )
                                ]
                            ),
                            ft.Text(
                                f"{progress_data['progress_percent']}%",
                                size=18,
                                weight="bold"
                            )
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                    ),
                    ft.ProgressBar(
                        value=progress_percent,
                        height=8,
                        color="#4CAF50"
                    )
                ],
                spacing=10
            ),
            padding=15,
            bgcolor=ft.Colors.SURFACE_VARIANT,
            border_radius=10
        )

    def _refresh_content(self):
        """Refresh tab content"""

        index = self.tab_control.selected_index

        self.content_container.controls.clear()

        if index == 0:
            self._show_tasks()
        elif index == 1:
            self._show_documents()
        elif index == 2:
            self._show_timeline()

    def _on_tab_change(self, e):
        """Handle tab change"""
        self._refresh_content()

    def _show_tasks(self):
        """Show onboarding tasks"""

        progress_data = OnboardingManager.get_onboarding_progress(
            self.session, self.employee_id
        )

        tasks = progress_data.get("tasks", [])

        if not tasks:
            self.content_container.controls.append(
                ft.Text("No onboarding tasks", color="gray")
            )
            return

        for task in sorted(tasks, key=lambda t: t.sequence_order):
            card = self._build_task_card(task)
            self.content_container.controls.append(card)

    def _build_task_card(self, task: OnboardingTask) -> ft.Container:
        """Build task card"""

        # Status colors
        status_colors = {
            "PENDING": "#FF9800",
            "IN_PROGRESS": "#2196F3",
            "COMPLETED": "#4CAF50",
            "SKIPPED": "#9E9E9E"
        }

        status_icons = {
            "PENDING": ft.icons.SCHEDULE,
            "IN_PROGRESS": ft.icons.HOURGLASS_TOP,
            "COMPLETED": ft.icons.CHECK_CIRCLE,
            "SKIPPED": ft.icons.CANCEL
        }

        status_color = status_colors.get(task.status, "#9E9E9E")
        status_icon = status_icons.get(task.status, ft.icons.HELP)

        def on_status_change(e, task_id):
            new_status = "COMPLETED" if task.status != "COMPLETED" else "IN_PROGRESS"
            OnboardingManager.update_task_status(
                self.session, task_id, new_status)
            self._refresh_content()
            self.page.update()

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            ft.Icon(status_icon, color=status_color, size=28),
                            ft.Column(
                                controls=[
                                    ft.Text(
                                        task.title, weight="bold", size=14),
                                    ft.Text(task.description or "",
                                            size=11, color="gray"),
                                    ft.Text(
                                        f"Target: {task.target_completion.strftime('%d %b') if task.target_completion else 'N/A'}",
                                        size=10,
                                        color="gray"
                                    )
                                ],
                                expand=True
                            ),
                            ft.IconButton(
                                icon=ft.icons.CHECK if task.status != "COMPLETED" else ft.icons.REFRESH,
                                on_click=lambda e: on_status_change(e, task.id)
                            )
                        ],
                        spacing=10
                    )
                ]
            ),
            padding=12,
            border=ft.border.all(1, status_color),
            border_radius=8,
            bgcolor=ft.Colors.with_opacity(0.05, status_color)
        )

    def _show_documents(self):
        """Show document requirements"""

        docs = OnboardingManager.get_pending_documents(
            self.session, self.employee_id
        )

        if not docs:
            self.content_container.controls.append(
                ft.Text("All documents signed", color="gray")
            )
            return

        for doc in docs:
            card = self._build_document_card(doc)
            self.content_container.controls.append(card)

    def _build_document_card(self, doc: OnboardingDocument) -> ft.Container:
        """Build document card"""

        status_colors = {
            "PENDING_SIGNATURE": "#FF9800",
            "SIGNED": "#4CAF50",
            "REJECTED": "#F44336"
        }

        status_color = status_colors.get(doc.signature_status, "#9E9E9E")

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            ft.Icon(ft.icons.DESCRIPTION,
                                    color="#2196F3", size=32),
                            ft.Column(
                                controls=[
                                    ft.Text(
                                        doc.template_name or "Document", weight="bold"),
                                    ft.Text(
                                        f"Type: {doc.document_type or 'N/A'}",
                                        size=11,
                                        color="gray"
                                    ),
                                    ft.Text(
                                        f"Status: {doc.signature_status}",
                                        size=10,
                                        weight="bold",
                                        color=status_color
                                    )
                                ],
                                expand=True
                            )
                        ],
                        spacing=10
                    ),
                    ft.Divider(height=10),
                    ft.Row(
                        controls=[
                            ft.ElevatedButton(
                                text="Upload File",
                                icon=ft.icons.UPLOAD,
                                on_click=lambda e: self._show_upload_dialog(
                                    doc)
                            ),
                            ft.ElevatedButton(
                                text="Sign Document" if doc.signature_status != "SIGNED" else "View",
                                icon=ft.icons.EDIT if doc.signature_status != "SIGNED" else ft.icons.VISIBILITY,
                                on_click=lambda e: self._show_sign_dialog(doc)
                            )
                        ],
                        spacing=10
                    )
                ],
                spacing=8
            ),
            padding=12,
            border=ft.border.all(1, status_color),
            border_radius=8
        )

    def _show_timeline(self):
        """Show onboarding timeline"""

        timeline_data = OnboardingManager.get_onboarding_timeline(
            self.session, self.employee_id
        )

        tasks = timeline_data.get("tasks", [])

        if not tasks:
            self.content_container.controls.append(
                ft.Text("No timeline data", color="gray")
            )
            return

        # Timeline header
        self.content_container.controls.append(
            ft.Container(
                content=ft.Column(
                    controls=[
                        ft.Text("Onboarding Timeline", size=14, weight="bold"),
                        ft.Text(
                            f"Started: {timeline_data['start_date'].strftime('%d %b, %Y') if timeline_data.get('start_date') else 'N/A'}",
                            size=11,
                            color="gray"
                        ),
                        ft.Text(
                            f"Est. Completion: {timeline_data['estimated_end'].strftime('%d %b, %Y') if timeline_data.get('estimated_end') else 'N/A'}",
                            size=11,
                            color="gray"
                        )
                    ]
                ),
                padding=10
            )
        )

        # Timeline items
        for task in sorted(tasks, key=lambda t: t["order"]):
            timeline_item = ft.Container(
                content=ft.Row(
                    controls=[
                        ft.Column(
                            controls=[
                                ft.Icon(
                                    ft.icons.CHECK_CIRCLE if task["status"] == "COMPLETED" else ft.icons.SCHEDULE,
                                    size=24,
                                    color="#4CAF50" if task["status"] == "COMPLETED" else "#FF9800"
                                )
                            ],
                            width=40,
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER
                        ),
                        ft.Column(
                            controls=[
                                ft.Text(task["title"], weight="bold"),
                                ft.Text(
                                    f"Target: {task['target_date'].strftime('%d %b') if task.get('target_date') else 'N/A'}",
                                    size=10,
                                    color="gray"
                                )
                            ],
                            expand=True
                        )
                    ]
                ),
                padding=10,
                border_left=ft.border.only(
                    left=ft.border.BorderSide(3, "#2196F3"))
            )
            self.content_container.controls.append(timeline_item)

    def _show_upload_dialog(self, doc: OnboardingDocument):
        """Show file upload dialog"""

        file_name_field = ft.TextField(
            label="File Name", value=doc.file_name or "")

        def on_upload(e):
            file_name = file_name_field.value
            if file_name:
                OnboardingManager.upload_document(
                    self.session, doc.id, f"/uploads/{file_name}", file_name
                )
                self.page.snack_bar = ft.SnackBar(
                    ft.Text("File uploaded successfully"))
                self.page.snack_bar.open = True
                self._refresh_content()
                dialog.open = False
                self.page.update()

        dialog = ft.AlertDialog(
            title=ft.Text("Upload Document"),
            content=file_name_field,
            actions=[
                ft.TextButton(
                    "Cancel", on_click=lambda e: self._close_dialog(dialog)),
                ft.TextButton("Upload", on_click=on_upload)
            ]
        )

        self.page.dialog = dialog
        dialog.open = True
        self.page.update()

    def _show_sign_dialog(self, doc: OnboardingDocument):
        """Show signature dialog"""

        signature_canvas = ft.Container(
            width=400,
            height=200,
            bgcolor=ft.Colors.SURFACE_VARIANT,
            border_radius=8
        )

        def on_sign(e):
            OnboardingManager.sign_document(self.session, doc.id)
            self.page.snack_bar = ft.SnackBar(
                ft.Text("Document signed successfully"))
            self.page.snack_bar.open = True
            self._refresh_content()
            dialog.open = False
            self.page.update()

        dialog = ft.AlertDialog(
            title=ft.Text("Sign Document"),
            content=ft.Column(
                controls=[
                    ft.Text("Signature Area (Tap to sign)"),
                    signature_canvas,
                    ft.Text("By signing, you agree to the terms",
                            size=10, color="gray")
                ]
            ),
            actions=[
                ft.TextButton(
                    "Cancel", on_click=lambda e: self._close_dialog(dialog)),
                ft.TextButton("Sign", on_click=on_sign)
            ]
        )

        self.page.dialog = dialog
        dialog.open = True
        self.page.update()

    def _close_dialog(self, dialog):
        """Close dialog"""
        dialog.open = False
        self.page.update()

    def on_screen_load(self):
        """Called when screen loads"""
        # Initialize onboarding if not done
        progress_data = OnboardingManager.get_onboarding_progress(
            self.session, self.employee_id
        )
        if progress_data["total_tasks"] == 0:
            OnboardingManager.create_onboarding_workflow(
                self.session, self.employee_id)

    def on_screen_unload(self):
        """Called when screen unloads"""
        pass
