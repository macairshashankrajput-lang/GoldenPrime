"""
Async Collaboration Suite Screen - Video and Standup Management
Async video recording, annotations, and daily standups
"""

import flet as ft
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from database.new_models import AsyncVideoEntry, AsyncAnnotation, DailyStandupEntry
from database.models import Employee
from core.base_screen import BaseScreen


class AsyncCollaborationScreen(BaseScreen):
    """Async collaboration with videos and standups"""

    def __init__(self, *args, **kwargs):
        page = kwargs.pop('page', None)
        user = kwargs.pop('user', None)
        session = kwargs.pop('session', None)
        employee_id = kwargs.pop('employee_id', None)

        if len(args) > 0:
            if isinstance(args[0], ft.Page):
                page = args[0]
            elif hasattr(args[0], 'query') or hasattr(args[0], 'add'):
                session = args[0]
        if len(args) > 1:
            if isinstance(args[1], (dict, object)) and not isinstance(args[1], int):
                user = args[1]
            elif isinstance(args[1], int):
                employee_id = args[1]

        super().__init__(page=page, **kwargs)

        if session is None:
            try:
                from database.session_manager import get_db_session
                session = get_db_session()
            except Exception:
                session = None
        self.session = session

        self.user = user
        if employee_id is None and user is not None:
            user_id = user.get('id') if isinstance(user, dict) else getattr(user, 'id', None)
            if user_id and session:
                try:
                    from database.session_manager import get_employee_by_user_id
                    emp = get_employee_by_user_id(session, user_id)
                    employee_id = emp.id if emp else user_id
                except Exception:
                    employee_id = user_id or 1
        if not employee_id:
            employee_id = 1
        self.employee_id = employee_id

        main_content = self.build_screen()
        if main_content:
            self.controls = [main_content]

    def build_screen(self):
        """Build async collaboration screen"""

        # Stats panel
        stats_panel = self._build_stats_panel()

        # Tab selector
        self.tab_control = ft.Tabs(
            selected_index=0,
            on_change=self._on_tab_change,
            tabs=[
                ft.Tab(text="Videos", content=ft.Container()),
                ft.Tab(text="Standups", content=ft.Container()),
                ft.Tab(text="Annotations", content=ft.Container())
            ]
        )

        # Content container
        self.content_container = ft.Column(
            expand=True,
            scroll=ft.ScrollMode.AUTO
        )

        self._refresh_content()

        main_content = ft.Column(
            controls=[
                ft.Container(
                    content=ft.Text("Async Collaboration",
                                    size=24, weight="bold"),
                    padding=10
                ),
                stats_panel,
                ft.Divider(),
                self.tab_control,
                self.content_container
            ],
            expand=True
        )

        return main_content

    def _build_stats_panel(self) -> ft.Container:
        """Build statistics panel"""

        videos = self.session.query(AsyncVideoEntry).filter(
            AsyncVideoEntry.created_by == self.employee_id
        ).all()

        standups = self.session.query(DailyStandupEntry).filter(
            DailyStandupEntry.employee_id == self.employee_id
        ).all()

        annotations = self.session.query(AsyncAnnotation).filter(
            AsyncAnnotation.created_by == self.employee_id
        ).all()

        return ft.Container(
            content=ft.Row(
                controls=[
                    ft.Column(
                        controls=[
                            ft.Text("Videos Recorded", size=12, color="gray"),
                            ft.Text(str(len(videos)), size=18, weight="bold")
                        ]
                    ),
                    ft.Column(
                        controls=[
                            ft.Text("Standups Completed",
                                    size=12, color="gray"),
                            ft.Text(str(len(standups)), size=18, weight="bold")
                        ]
                    ),
                    ft.Column(
                        controls=[
                            ft.Text("Annotations Added",
                                    size=12, color="gray"),
                            ft.Text(str(len(annotations)),
                                    size=18, weight="bold")
                        ]
                    ),
                    ft.Column(
                        controls=[
                            ft.Text("Total Duration", size=12, color="gray"),
                            ft.Text(
                                f"{sum(v.duration_seconds or 0 for v in videos)}s", size=18, weight="bold")
                        ]
                    )
                ],
                spacing=30
            ),
            padding=15,
            bgcolor=ft.Colors.SURFACE_VARIANT,
            border_radius=10
        )

    def _refresh_content(self):
        """Refresh tab content"""

        index = self.tab_control.selected_index

        self.content_container.controls.clear()

        if index == 0:
            self._show_videos()
        elif index == 1:
            self._show_standups()
        elif index == 2:
            self._show_annotations()

    def _on_tab_change(self, e):
        """Handle tab change"""
        self._refresh_content()

    def _show_videos(self):
        """Show video recordings"""

        videos = self.session.query(AsyncVideoEntry).order_by(
            AsyncVideoEntry.created_at.desc()
        ).all()

        if not videos:
            self.content_container.controls.append(
                ft.Text("No videos recorded", color="gray")
            )
            return

        # Upload button
        upload_btn = ft.ElevatedButton(
            text="Upload Video",
            icon=ft.icons.UPLOAD,
            on_click=self._show_upload_video_dialog
        )
        self.content_container.controls.append(upload_btn)
        self.content_container.controls.append(ft.Divider())

        for video in videos:
            card = self._build_video_card(video)
            self.content_container.controls.append(card)

    def _build_video_card(self, video: AsyncVideoEntry) -> ft.Container:
        """Build video card"""

        creator = self.session.query(Employee).get(video.created_by)

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            ft.Icon(ft.icons.VIDEOCAM,
                                    size=40, color="#FF5722"),
                            ft.Column(
                                controls=[
                                    ft.Text(video.title or "Untitled Video",
                                            weight="bold", size=14),
                                    ft.Text(
                                        f"By {creator.first_name if creator else 'Unknown'}",
                                        size=11,
                                        color="gray"
                                    ),
                                    ft.Text(
                                        f"Duration: {video.duration_seconds or 0}s • "
                                        f"{video.created_at.strftime('%d %b, %H:%M') if video.created_at else 'N/A'}",
                                        size=10,
                                        color="gray"
                                    )
                                ],
                                expand=True
                            ),
                            ft.PopupMenuButton(
                                items=[
                                    ft.PopupMenuItem(
                                        text="View Details",
                                        on_click=lambda e: self._show_video_details(
                                            video)
                                    ),
                                    ft.PopupMenuItem(
                                        text="Add Annotation",
                                        on_click=lambda e: self._show_annotation_dialog(
                                            video)
                                    ),
                                    ft.PopupMenuItem(
                                        text="Delete",
                                        on_click=lambda e: self._delete_video(
                                            video.id)
                                    )
                                ]
                            )
                        ]
                    ),
                    if video.description else ft.Container(),
                    ft.Text(video.description or "", size=11,
                            color="gray") if video.description else ft.Container(),
                    ft.Row(
                        controls=[
                            ft.Container(
                                content=ft.Text(
                                    f"Views: {video.view_count or 0}", size=10),
                                padding=5
                            ),
                            ft.Container(
                                content=ft.Text(
                                    f"Annotations: {video.annotation_count or 0}", size=10),
                                padding=5
                            )
                        ]
                    )
                ],
                spacing=8
            ),
            padding=12,
            border=ft.border.all(1, ft.Colors.OUTLINE),
            border_radius=8
        )

    def _show_standups(self):
        """Show daily standups"""

        standups = self.session.query(DailyStandupEntry).filter(
            DailyStandupEntry.employee_id == self.employee_id
        ).order_by(DailyStandupEntry.standup_date.desc()).all()

        if not standups:
            self.content_container.controls.append(
                ft.Text("No standups recorded", color="gray")
            )
            return

        # New standup button
        new_btn = ft.ElevatedButton(
            text="New Daily Standup",
            icon=ft.icons.MIC,
            on_click=self._show_standup_dialog
        )
        self.content_container.controls.append(new_btn)
        self.content_container.controls.append(ft.Divider())

        for standup in standups:
            card = self._build_standup_card(standup)
            self.content_container.controls.append(card)

    def _build_standup_card(self, standup: DailyStandupEntry) -> ft.Container:
        """Build standup card"""

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            ft.Icon(ft.icons.MIC_NONE,
                                    size=40, color="#2196F3"),
                            ft.Column(
                                controls=[
                                    ft.Text(
                                        f"Daily Standup - {standup.standup_date.strftime('%d %b, %Y')}",
                                        weight="bold",
                                        size=14
                                    ),
                                    ft.Text(
                                        f"Duration: {standup.duration_seconds or 0}s",
                                        size=11,
                                        color="gray"
                                    ),
                                    ft.Text(
                                        f"Status: {standup.status or 'COMPLETED'}",
                                        size=10,
                                        color="#4CAF50"
                                    )
                                ],
                                expand=True
                            )
                        ]
                    ),
                    if standup.transcript else ft.Container(),
                    ft.Container(
                        content=ft.Text(
                            f"Transcript: {standup.transcript[:100]}..." if len(
                                standup.transcript or "") > 100 else f"Transcript: {standup.transcript or ''}",
                            size=10,
                            color="gray"
                        )
                    ) if standup.transcript else ft.Container(),
                    ft.Row(
                        controls=[
                            ft.TextButton(
                                text="View Details",
                                on_click=lambda e: self._show_standup_details(
                                    standup)
                            ),
                            ft.TextButton(
                                text="Edit",
                                on_click=lambda e: self._show_edit_standup_dialog(
                                    standup)
                            ),
                            ft.TextButton(
                                text="Delete",
                                on_click=lambda e: self._delete_standup(
                                    standup.id)
                            )
                        ]
                    )
                ],
                spacing=8
            ),
            padding=12,
            border=ft.border.all(1, ft.Colors.OUTLINE),
            border_radius=8
        )

    def _show_annotations(self):
        """Show annotations"""

        annotations = self.session.query(AsyncAnnotation).filter(
            AsyncAnnotation.created_by == self.employee_id
        ).order_by(AsyncAnnotation.created_at.desc()).all()

        if not annotations:
            self.content_container.controls.append(
                ft.Text("No annotations added", color="gray")
            )
            return

        for annotation in annotations:
            card = self._build_annotation_card(annotation)
            self.content_container.controls.append(card)

    def _build_annotation_card(self, annotation: AsyncAnnotation) -> ft.Container:
        """Build annotation card"""

        video = self.session.query(AsyncVideoEntry).get(annotation.video_id)
        creator = self.session.query(Employee).get(annotation.created_by)

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            ft.Icon(ft.icons.COMMENT,
                                    size=32, color="#FF9800"),
                            ft.Column(
                                controls=[
                                    ft.Text(
                                        f"Annotation on '{video.title or 'Video'}'", weight="bold"),
                                    ft.Text(
                                        f"By {creator.first_name if creator else 'Unknown'} • "
                                        f"At {annotation.timestamp_seconds or 0}s",
                                        size=11,
                                        color="gray"
                                    ),
                                    ft.Text(
                                        annotation.created_at.strftime(
                                            "%d %b, %H:%M") if annotation.created_at else "N/A",
                                        size=10,
                                        color="gray"
                                    )
                                ],
                                expand=True
                            )
                        ]
                    ),
                    ft.Divider(height=10),
                    ft.Container(
                        content=ft.Text(
                            annotation.annotation_text or "",
                            size=11,
                            selectable=True
                        )
                    ),
                    ft.Row(
                        controls=[
                            ft.TextButton(
                                text="Delete",
                                on_click=lambda e: self._delete_annotation(
                                    annotation.id)
                            )
                        ]
                    )
                ],
                spacing=8
            ),
            padding=12,
            border=ft.border.all(1, "#FF9800"),
            border_radius=8
        )

    def _show_upload_video_dialog(self, e=None):
        """Show upload video dialog"""

        title_field = ft.TextField(label="Video Title")
        description_field = ft.TextField(
            label="Description", multiline=True, max_lines=3)
        duration_field = ft.TextField(
            label="Duration (seconds)", input_filter=ft.NumbersOnlyInputFilter())

        def on_upload(e):
            try:
                video = AsyncVideoEntry(
                    title=title_field.value,
                    description=description_field.value,
                    duration_seconds=int(duration_field.value or "0"),
                    created_by=self.employee_id,
                    created_at=datetime.utcnow(),
                    view_count=0,
                    annotation_count=0
                )
                self.session.add(video)
                self.session.commit()

                self.page.snack_bar = ft.SnackBar(
                    ft.Text("Video uploaded successfully"))
                self.page.snack_bar.open = True
                self._refresh_content()
                dialog.open = False
                self.page.update()

            except Exception as ex:
                self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
                self.page.snack_bar.open = True
                self.page.update()

        dialog = ft.AlertDialog(
            title=ft.Text("Upload Video"),
            content=ft.Column(
                controls=[title_field, description_field, duration_field],
                spacing=10
            ),
            actions=[
                ft.TextButton(
                    "Cancel", on_click=lambda e: self._close_dialog()),
                ft.TextButton("Upload", on_click=on_upload)
            ]
        )

        self.page.dialog = dialog
        dialog.open = True
        self.page.update()

    def _show_standup_dialog(self, e=None):
        """Show new standup dialog"""

        title_field = ft.TextField(
            label="Today's Focus/Updates", multiline=True, max_lines=5)
        blockers_field = ft.TextField(
            label="Blockers (if any)", multiline=True, max_lines=3)

        def on_create(e):
            try:
                standup = DailyStandupEntry(
                    employee_id=self.employee_id,
                    standup_date=datetime.utcnow(),
                    transcript=title_field.value,
                    blockers=blockers_field.value or None,
                    duration_seconds=0,
                    status="COMPLETED",
                    created_at=datetime.utcnow()
                )
                self.session.add(standup)
                self.session.commit()

                self.page.snack_bar = ft.SnackBar(
                    ft.Text("Standup recorded successfully"))
                self.page.snack_bar.open = True
                self._refresh_content()
                dialog.open = False
                self.page.update()

            except Exception as ex:
                self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
                self.page.snack_bar.open = True
                self.page.update()

        dialog = ft.AlertDialog(
            title=ft.Text("Daily Standup"),
            content=ft.Column(
                controls=[title_field, blockers_field],
                spacing=10
            ),
            actions=[
                ft.TextButton(
                    "Cancel", on_click=lambda e: self._close_dialog()),
                ft.TextButton("Save", on_click=on_create)
            ]
        )

        self.page.dialog = dialog
        dialog.open = True
        self.page.update()

    def _show_annotation_dialog(self, video: AsyncVideoEntry):
        """Show annotation creation dialog"""

        timestamp_field = ft.TextField(
            label="Timestamp (seconds)", input_filter=ft.NumbersOnlyInputFilter(), value="0")
        text_field = ft.TextField(
            label="Annotation Text", multiline=True, max_lines=5)

        def on_add_annotation(e):
            try:
                annotation = AsyncAnnotation(
                    video_id=video.id,
                    timestamp_seconds=int(timestamp_field.value or "0"),
                    annotation_text=text_field.value,
                    created_by=self.employee_id,
                    created_at=datetime.utcnow()
                )
                self.session.add(annotation)

                # Update annotation count on video
                video.annotation_count = (video.annotation_count or 0) + 1

                self.session.commit()

                self.page.snack_bar = ft.SnackBar(
                    ft.Text("Annotation added successfully"))
                self.page.snack_bar.open = True
                self._refresh_content()
                dialog.open = False
                self.page.update()

            except Exception as ex:
                self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
                self.page.snack_bar.open = True
                self.page.update()

        dialog = ft.AlertDialog(
            title=ft.Text("Add Annotation"),
            content=ft.Column(
                controls=[timestamp_field, text_field],
                spacing=10
            ),
            actions=[
                ft.TextButton(
                    "Cancel", on_click=lambda e: self._close_dialog()),
                ft.TextButton("Add", on_click=on_add_annotation)
            ]
        )

        self.page.dialog = dialog
        dialog.open = True
        self.page.update()

    def _show_video_details(self, video: AsyncVideoEntry):
        """Show video details"""

        creator = self.session.query(Employee).get(video.created_by)

        dialog = ft.AlertDialog(
            title=ft.Text(video.title or "Video"),
            content=ft.Column(
                controls=[
                    ft.Text("Details", weight="bold"),
                    ft.Text(
                        f"Duration: {video.duration_seconds or 0} seconds"),
                    ft.Text(
                        f"Created by: {creator.first_name if creator else 'Unknown'}"),
                    ft.Text(
                        f"Date: {video.created_at.strftime('%d %b, %Y %H:%M') if video.created_at else 'N/A'}"),
                    ft.Text(f"Views: {video.view_count or 0}"),
                    ft.Text(f"Annotations: {video.annotation_count or 0}"),
                    ft.Divider(),
                    ft.Text("Description", weight="bold"),
                    ft.Text(video.description or "No description")
                ]
            ),
            actions=[
                ft.TextButton("Close", on_click=lambda e: self._close_dialog())
            ]
        )

        self.page.dialog = dialog
        dialog.open = True
        self.page.update()

    def _show_standup_details(self, standup: DailyStandupEntry):
        """Show standup details"""

        dialog = ft.AlertDialog(
            title=ft.Text(
                f"Standup - {standup.standup_date.strftime('%d %b, %Y')}"),
            content=ft.Column(
                controls=[
                    ft.Text("Updates", weight="bold"),
                    ft.Text(standup.transcript or "No content"),
                    if standup.blockers else ft.Container(),
                    ft.Divider() if standup.blockers else ft.Container(),
                    ft.Text(
                        "Blockers", weight="bold") if standup.blockers else ft.Container(),
                    ft.Text(
                        standup.blockers or "") if standup.blockers else ft.Container()
                ]
            ),
            actions=[
                ft.TextButton("Close", on_click=lambda e: self._close_dialog())
            ]
        )

        self.page.dialog = dialog
        dialog.open = True
        self.page.update()

    def _show_edit_standup_dialog(self, standup: DailyStandupEntry):
        """Show edit standup dialog"""

        title_field = ft.TextField(
            label="Updates", value=standup.transcript or "", multiline=True, max_lines=5)
        blockers_field = ft.TextField(
            label="Blockers", value=standup.blockers or "", multiline=True, max_lines=3)

        def on_update(e):
            try:
                standup.transcript = title_field.value
                standup.blockers = blockers_field.value or None
                self.session.commit()

                self.page.snack_bar = ft.SnackBar(ft.Text("Standup updated"))
                self.page.snack_bar.open = True
                self._refresh_content()
                dialog.open = False
                self.page.update()

            except Exception as ex:
                self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
                self.page.snack_bar.open = True
                self.page.update()

        dialog = ft.AlertDialog(
            title=ft.Text("Edit Standup"),
            content=ft.Column(
                controls=[title_field, blockers_field],
                spacing=10
            ),
            actions=[
                ft.TextButton(
                    "Cancel", on_click=lambda e: self._close_dialog()),
                ft.TextButton("Update", on_click=on_update)
            ]
        )

        self.page.dialog = dialog
        dialog.open = True
        self.page.update()

    def _delete_video(self, video_id: int):
        """Delete video"""

        try:
            video = self.session.query(AsyncVideoEntry).get(video_id)
            if video:
                self.session.delete(video)
                self.session.commit()
                self.page.snack_bar = ft.SnackBar(ft.Text("Video deleted"))
                self.page.snack_bar.open = True
                self._refresh_content()
                self.page.update()

        except Exception as ex:
            self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
            self.page.snack_bar.open = True
            self.page.update()

    def _delete_standup(self, standup_id: int):
        """Delete standup"""

        try:
            standup = self.session.query(DailyStandupEntry).get(standup_id)
            if standup:
                self.session.delete(standup)
                self.session.commit()
                self.page.snack_bar = ft.SnackBar(ft.Text("Standup deleted"))
                self.page.snack_bar.open = True
                self._refresh_content()
                self.page.update()

        except Exception as ex:
            self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
            self.page.snack_bar.open = True
            self.page.update()

    def _delete_annotation(self, annotation_id: int):
        """Delete annotation"""

        try:
            annotation = self.session.query(AsyncAnnotation).get(annotation_id)
            if annotation:
                # Update video annotation count
                video = self.session.query(
                    AsyncVideoEntry).get(annotation.video_id)
                if video:
                    video.annotation_count = max(
                        0, (video.annotation_count or 1) - 1)

                self.session.delete(annotation)
                self.session.commit()
                self.page.snack_bar = ft.SnackBar(
                    ft.Text("Annotation deleted"))
                self.page.snack_bar.open = True
                self._refresh_content()
                self.page.update()

        except Exception as ex:
            self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
            self.page.snack_bar.open = True
            self.page.update()

    def _close_dialog(self):
        """Close dialog"""
        self.page.dialog.open = False
        self.page.update()

    def on_screen_load(self):
        """Called when screen loads"""
        self._refresh_content()

    def on_screen_unload(self):
        """Called when screen unloads"""
        pass
