import flet as ft
import threading
from openai import OpenAI
import pyttsx3
import speech_recognition as sr


class ChatMessage(ft.Column):
    def __init__(self, text: str, user_name: str, is_user: bool):
        super().__init__()
        self.text = text
        self.user_name = user_name
        self.is_user = is_user

        # Define colors and alignment based on sender
        bg_color = ft.Colors.BLUE_500 if is_user else ft.Colors.GREY_200
        text_color = ft.Colors.WHITE if is_user else ft.Colors.BLACK
        alignment = ft.MainAxisAlignment.END if is_user else ft.MainAxisAlignment.START
        bubble_radius = ft.border_radius.only(
            top_left=15, top_right=15,
            bottom_left=15 if is_user else 0,
            bottom_right=0 if is_user else 15
        )

        self.controls = [
            ft.Row(
                [
                    ft.Container(
                        content=ft.Column([
                            ft.Text(self.user_name, size=10,
                                    weight="bold", color=text_color),
                            ft.Text(self.text, size=14,
                                    color=text_color, selectable=True),
                        ], tight=True, spacing=2),
                        bgcolor=bg_color,
                        padding=12,
                        border_radius=bubble_radius,
                        width=300,  # Constrain width for a "bubble" look
                    )
                ],
                alignment=alignment,
            )
        ]


class AIAssistantApp:
    def __init__(self, page: ft.Page):
        self.page = page
        self.chat = ft.ListView(expand=True, spacing=15,
                                padding=20, auto_scroll=True)
        self.history = []

    def speak(self, text: str):
        def run_tts():
            try:
                engine = pyttsx3.init()
                engine.say(text)
                engine.runAndWait()
            except:
                pass
        threading.Thread(target=run_tts, daemon=True).start()

    def listen(self):
        r = sr.Recognizer()
        with sr.Microphone() as source:
            try:
                r.adjust_for_ambient_noise(source)
                audio = r.listen(source, timeout=5)
                return r.recognize_google(audio)
            except:
                return None

    def get_ai_response(self, user_input: str):
        try:
            self.history.append({"role": "user", "content": user_input})
            response = client.chat.completions.create(
                model="llama3",
                messages=[
                    {"role": "system", "content": "You are a helpful Company AI Assistant."}] + self.history[-10:],
            )
            ans = response.choices[0].message.content
            self.history.append({"role": "assistant", "content": ans})
            return ans
        except Exception as e:
            return f"Error'.\n{str(e)}"

    def send_message(self, text: str, is_voice=False):
        if not text:
            return
        # Add User Bubble
        self.chat.controls.append(ChatMessage(text, "You", True))
        self.page.update()

        # Fetch & Add AI Bubble
        res = self.get_ai_response(text)
        self.chat.controls.append(ChatMessage(res, "Company AI", False))
        self.page.update()

        if is_voice:
            self.speak(res)

    def get_view(self):
        input_field = ft.TextField(
            hint_text="Write a message...",
            expand=True,
            border_radius=25,
            filled=True,
            content_padding=15,
            on_submit=lambda _: self.handle_click()
        )

        self.handle_click = lambda: (
            self.send_message(input_field.value),
            setattr(input_field, 'value', ""),
            self.page.update()
        )

        def start_voice(e):
            voice_text = self.listen()
            if voice_text:
                self.send_message(voice_text, is_voice=True)

        return ft.Container(
            content=ft.Column([
                # Top Header
                ft.Container(
                    content=ft.Row([
                        ft.Text("🏢 Vernika Assistant", color="white",
                                size=20, weight="bold"),
                        ft.IconButton(ft.Icons.RESTART_ALT, icon_color="white", on_click=lambda _: (
                            self.chat.controls.clear(), self.page.update()))
                    ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    bgcolor=ft.Colors.BLUE_900,
                    padding=20,
                ),
                # Chat Area
                ft.Container(content=self.chat, expand=True),
                # Bottom Input Area
                ft.Container(
                    padding=20,
                    content=ft.Row([
                        input_field,
                        ft.IconButton(ft.Icons.SEND_ROUNDED, icon_color=ft.Colors.BLUE_900,
                                      on_click=lambda _: self.handle_click()),
                        ft.FloatingActionButton(
                            icon=ft.Icons.MIC, on_click=start_voice, mini=True, bgcolor=ft.Colors.BLUE_900),
                    ])
                )
            ], spacing=0),
            expand=True,
            bgcolor=ft.Colors.WHITE,
        )


def main(page: ft.Page):
    page.title = "Vernika AI"
    page.window_width = 450
    page.window_height = 800
    page.padding = 0  # Remove default page padding for a full-screen look

    app = AIAssistantApp(page)
    page.add(app.get_view())


if __name__ == "__main__":
    ft.app(target=main)
