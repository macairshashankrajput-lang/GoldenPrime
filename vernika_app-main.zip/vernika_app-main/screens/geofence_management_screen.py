"""
Geofence Management Screen - Shift and Zone Verification
Location-based shift verification with code generation
"""

import flet as ft
from datetime import time, date
from sqlalchemy.orm import Session
from database.new_models import GeofenceZone, ShiftManagement
from database.models import Employee
from utils.geofence_validator import GeofenceValidator
from core.base_screen import BaseScreen


class GeofenceManagementScreen(BaseScreen):
    """Geofence zone and shift management"""

    def __init__(self, *args, **kwargs):
        page = kwargs.pop('page', None)
        user = kwargs.pop('user', None)
        session = kwargs.pop('session', None)
        employee_id = kwargs.pop('employee_id', None)

        if len(args) > 0:
            if isinstance(args[0], ft.Page):
                page = args[0]
            elif hasattr(args[0], 'query') or hasattr(args[0], 'add'):
                session = args[0]
        if len(args) > 1:
            if isinstance(args[1], (dict, object)) and not isinstance(args[1], int):
                user = args[1]
            elif isinstance(args[1], int):
                employee_id = args[1]

        super().__init__(page=page, **kwargs)

        if session is None:
            try:
                from database.session_manager import get_db_session
                session = get_db_session()
            except Exception:
                session = None
        self.session = session

        self.user = user
        if employee_id is None and user is not None:
            user_id = user.get('id') if isinstance(user, dict) else getattr(user, 'id', None)
            if user_id and session:
                try:
                    from database.session_manager import get_employee_by_user_id
                    emp = get_employee_by_user_id(session, user_id)
                    employee_id = emp.id if emp else user_id
                except Exception:
                    employee_id = user_id or 1
        if not employee_id:
            employee_id = 1
        self.employee_id = employee_id

        self.view_mode = "zones"

        main_content = self.build_screen()
        if main_content:
            self.controls = [main_content]

    def build_screen(self):
        """Build geofence management screen"""

        # Tab selector
        tabs = ft.Tabs(
            selected_index=0,
            on_change=lambda e: self._on_tab_change(e),
            tabs=[
                ft.Tab(text="Zones", content=ft.Text("")),
                ft.Tab(text="My Shifts", content=ft.Text(""))
            ]
        )

        # Content container
        self.content_container = ft.Column(
            scroll=ft.ScrollMode.AUTO, expand=True)
        self._refresh_zones()

        # Action buttons
        action_buttons = ft.Row(
            controls=[
                ft.ElevatedButton(
                    text="Add Zone",
                    on_click=self._show_add_zone_dialog,
                    icon=ft.icons.ADD_LOCATION_ALT
                ),
                ft.ElevatedButton(
                    text="Add Shift",
                    on_click=self._show_add_shift_dialog,
                    icon=ft.icons.SCHEDULE
                )
            ],
            spacing=10
        )

        main_content = ft.Column(
            controls=[
                ft.Container(
                    content=ft.Text("Geofence Management",
                                    size=24, weight="bold"),
                    padding=10
                ),
                tabs,
                ft.Divider(),
                action_buttons,
                ft.Divider(),
                self.content_container
            ],
            expand=True
        )

        return main_content

    def _on_tab_change(self, e):
        """Handle tab change"""
        self.view_mode = "zones" if e.control.selected_index == 0 else "shifts"
        self._refresh_content()

    def _refresh_content(self):
        """Refresh content based on view mode"""
        if self.view_mode == "zones":
            self._refresh_zones()
        else:
            self._refresh_shifts()

    def _refresh_zones(self):
        """Refresh geofence zones"""

        self.content_container.controls.clear()

        zones = GeofenceValidator.get_geofence_zones_by_name(self.session)

        if not zones:
            self.content_container.controls.append(
                ft.Text("No geofence zones configured", color="gray")
            )
            return

        for zone in zones:
            card = self._build_zone_card(zone)
            self.content_container.controls.append(card)

    def _refresh_shifts(self):
        """Refresh employee shifts"""

        self.content_container.controls.clear()

        from database.models import Employee as Emp
        employee = self.session.query(Emp).get(self.employee_id)

        if not employee:
            return

        shifts = self.session.query(ShiftManagement).filter(
            ShiftManagement.employee_id == self.employee_id
        ).all()

        if not shifts:
            self.content_container.controls.append(
                ft.Text("No shifts configured", color="gray")
            )
            return

        for shift in shifts:
            card = self._build_shift_card(shift)
            self.content_container.controls.append(card)

    def _build_zone_card(self, zone: GeofenceZone) -> ft.Container:
        """Build geofence zone card"""

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            ft.Column(
                                controls=[
                                    ft.Text(zone.name, size=16, weight="bold"),
                                    ft.Text(
                                        f"Radius: {zone.radius_meters}m",
                                        size=12,
                                        color="gray"
                                    )
                                ],
                                expand=True
                            ),
                            ft.Container(
                                content=ft.Icon(
                                    ft.icons.LOCATION_ON,
                                    color="#2196F3",
                                    size=24
                                )
                            )
                        ]
                    ),
                    ft.Divider(height=10),
                    ft.Row(
                        controls=[
                            ft.Column(
                                controls=[
                                    ft.Text("Code", size=10, color="gray"),
                                    ft.Text(
                                        zone.verification_code,
                                        size=12,
                                        weight="bold",
                                        selectable=True
                                    )
                                ]
                            ),
                            ft.Column(
                                controls=[
                                    ft.Text("Coordinates",
                                            size=10, color="gray"),
                                    ft.Text(
                                        f"{zone.location_latitude or 'N/A'}, {zone.location_longitude or 'N/A'}",
                                        size=11
                                    )
                                ]
                            )
                        ],
                        spacing=40
                    ),
                    ft.Row(
                        controls=[
                            ft.IconButton(
                                icon=ft.icons.EDIT,
                                tooltip="Edit",
                                on_click=lambda e: self._show_edit_zone_dialog(
                                    zone)
                            ),
                            ft.IconButton(
                                icon=ft.icons.DELETE,
                                tooltip="Delete",
                                on_click=lambda e: self._delete_zone(zone.id)
                            ),
                            ft.IconButton(
                                icon=ft.icons.CONTENT_COPY,
                                tooltip="Copy Code",
                                on_click=lambda e: self._copy_to_clipboard(
                                    zone.verification_code)
                            )
                        ]
                    )
                ]
            ),
            padding=10,
            border=ft.border.all(1, ft.Colors.OUTLINE),
            border_radius=8
        )

    def _build_shift_card(self, shift: ShiftManagement) -> ft.Container:
        """Build shift card"""

        # Calculate duration
        duration = GeofenceValidator.calculate_shift_duration(shift)
        hours = duration // 60
        minutes = duration % 60

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            ft.Column(
                                controls=[
                                    ft.Text(shift.shift_name,
                                            size=16, weight="bold"),
                                    ft.Text(
                                        f"{hours}h {minutes}m shift",
                                        size=12,
                                        color="gray"
                                    )
                                ],
                                expand=True
                            ),
                            ft.Container(
                                content=ft.Icon(
                                    ft.icons.SCHEDULE,
                                    color="#FF9800",
                                    size=24
                                )
                            )
                        ]
                    ),
                    ft.Divider(height=10),
                    ft.Row(
                        controls=[
                            ft.Column(
                                controls=[
                                    ft.Text("Start", size=10, color="gray"),
                                    ft.Text(
                                        shift.start_time.strftime("%H:%M"),
                                        size=14,
                                        weight="bold"
                                    )
                                ]
                            ),
                            ft.Container(width=20),
                            ft.Icon(ft.icons.ARROW_FORWARD, color="gray"),
                            ft.Container(width=20),
                            ft.Column(
                                controls=[
                                    ft.Text("End", size=10, color="gray"),
                                    ft.Text(
                                        shift.end_time.strftime("%H:%M"),
                                        size=14,
                                        weight="bold"
                                    )
                                ]
                            ),
                            ft.Column(
                                controls=[
                                    ft.Text("Break", size=10, color="gray"),
                                    ft.Text(
                                        f"{shift.break_duration_minutes}m",
                                        size=12
                                    )
                                ]
                            )
                        ],
                        spacing=5
                    ),
                    ft.Row(
                        controls=[
                            ft.IconButton(
                                icon=ft.icons.EDIT,
                                tooltip="Edit",
                                on_click=lambda e: self._show_edit_shift_dialog(
                                    shift)
                            ),
                            ft.IconButton(
                                icon=ft.icons.DELETE,
                                tooltip="Delete",
                                on_click=lambda e: self._delete_shift(shift.id)
                            )
                        ]
                    )
                ]
            ),
            padding=10,
            border=ft.border.all(1, ft.Colors.OUTLINE),
            border_radius=8
        )

    def _show_add_zone_dialog(self, e):
        """Show add geofence zone dialog"""

        name_field = ft.TextField(label="Zone Name")
        radius_field = ft.TextField(
            label="Radius (meters)",
            value="100",
            keyboard_type=ft.KeyboardType.NUMBER
        )
        lat_field = ft.TextField(
            label="Latitude (optional)",
            keyboard_type=ft.KeyboardType.NUMBER
        )
        lon_field = ft.TextField(
            label="Longitude (optional)",
            keyboard_type=ft.KeyboardType.NUMBER
        )

        def save_zone(e):
            try:
                if not name_field.value:
                    self.page.snack_bar = ft.SnackBar(
                        ft.Text("Zone name required"))
                    self.page.snack_bar.open = True
                    self.page.update()
                    return

                lat = float(lat_field.value) if lat_field.value else None
                lon = float(lon_field.value) if lon_field.value else None

                GeofenceValidator.create_zone(
                    self.session,
                    name_field.value,
                    lat,
                    lon,
                    int(radius_field.value)
                )

                self.page.snack_bar = ft.SnackBar(
                    ft.Text("Zone created successfully"))
                self.page.snack_bar.open = True
                self._refresh_zones()
                self._close_dialog()
                self.page.update()

            except Exception as ex:
                self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
                self.page.snack_bar.open = True
                self.page.update()

        dialog = ft.AlertDialog(
            title=ft.Text("Add Geofence Zone"),
            content=ft.Column(
                controls=[name_field, radius_field, lat_field, lon_field],
                spacing=10
            ),
            actions=[
                ft.TextButton(
                    "Cancel", on_click=lambda e: self._close_dialog()),
                ft.TextButton("Add", on_click=save_zone)
            ]
        )

        self.page.dialog = dialog
        dialog.open = True
        self.page.update()

    def _show_add_shift_dialog(self, e):
        """Show add shift dialog"""

        name_field = ft.TextField(label="Shift Name")

        start_hour = ft.TextField(
            label="Start Hour", value="09", keyboard_type=ft.KeyboardType.NUMBER, width=80)
        start_min = ft.TextField(
            label="Start Min", value="00", keyboard_type=ft.KeyboardType.NUMBER, width=80)

        end_hour = ft.TextField(
            label="End Hour", value="17", keyboard_type=ft.KeyboardType.NUMBER, width=80)
        end_min = ft.TextField(label="End Min", value="00",
                               keyboard_type=ft.KeyboardType.NUMBER, width=80)

        break_field = ft.TextField(
            label="Break Duration (minutes)",
            value="60",
            keyboard_type=ft.KeyboardType.NUMBER
        )

        grace_field = ft.TextField(
            label="Grace Period (minutes)",
            value="5",
            keyboard_type=ft.KeyboardType.NUMBER
        )

        def save_shift(e):
            try:
                if not name_field.value:
                    self.page.snack_bar = ft.SnackBar(
                        ft.Text("Shift name required"))
                    self.page.snack_bar.open = True
                    self.page.update()
                    return

                start = time(int(start_hour.value), int(start_min.value))
                end = time(int(end_hour.value), int(end_min.value))

                GeofenceValidator.create_shift(
                    self.session,
                    self.employee_id,
                    name_field.value,
                    start,
                    end,
                    int(break_field.value),
                    int(grace_field.value)
                )

                self.page.snack_bar = ft.SnackBar(
                    ft.Text("Shift created successfully"))
                self.page.snack_bar.open = True
                self._refresh_shifts()
                self._close_dialog()
                self.page.update()

            except Exception as ex:
                self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
                self.page.snack_bar.open = True
                self.page.update()

        dialog = ft.AlertDialog(
            title=ft.Text("Add Shift"),
            content=ft.Column(
                controls=[
                    name_field,
                    ft.Text("Start Time", weight="bold"),
                    ft.Row(controls=[start_hour, start_min], spacing=5),
                    ft.Text("End Time", weight="bold"),
                    ft.Row(controls=[end_hour, end_min], spacing=5),
                    break_field,
                    grace_field
                ],
                spacing=10
            ),
            actions=[
                ft.TextButton(
                    "Cancel", on_click=lambda e: self._close_dialog()),
                ft.TextButton("Add", on_click=save_shift)
            ]
        )

        self.page.dialog = dialog
        dialog.open = True
        self.page.update()

    def _show_edit_zone_dialog(self, zone: GeofenceZone, e=None):
        """Show edit zone dialog"""
        pass

    def _show_edit_shift_dialog(self, shift: ShiftManagement, e=None):
        """Show edit shift dialog"""
        pass

    def _delete_zone(self, zone_id: int):
        """Delete geofence zone"""
        try:
            zone = self.session.query(GeofenceZone).get(zone_id)
            if zone:
                zone.is_active = False
                self.session.commit()
                self._refresh_zones()
                self.page.update()
        except Exception as ex:
            self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
            self.page.snack_bar.open = True
            self.page.update()

    def _delete_shift(self, shift_id: int):
        """Delete shift"""
        try:
            shift = self.session.query(ShiftManagement).get(shift_id)
            if shift:
                self.session.delete(shift)
                self.session.commit()
                self._refresh_shifts()
                self.page.update()
        except Exception as ex:
            self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
            self.page.snack_bar.open = True
            self.page.update()

    def _copy_to_clipboard(self, text: str):
        """Copy text to clipboard"""
        self.page.snack_bar = ft.SnackBar(ft.Text(f"Copied: {text}"))
        self.page.snack_bar.open = True
        self.page.update()

    def _close_dialog(self):
        """Close dialog"""
        self.page.dialog.open = False
        self.page.update()

    def on_screen_load(self):
        """Called when screen loads"""
        self._refresh_content()

    def on_screen_unload(self):
        """Called when screen unloads"""
        pass
