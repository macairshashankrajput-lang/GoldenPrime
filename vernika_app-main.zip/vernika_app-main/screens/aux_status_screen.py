"""
AUX Status Screen - Real-Time Productivity Status Management
Track employee status with live duration counter and daily timeline
"""

import flet as ft
from datetime import datetime, date, timedelta
from sqlalchemy.orm import Session
from database.new_models import AUXLog, AUXStatus
from utils.aux_status_manager import AUXStatusManager
from core.base_screen import BaseScreen


class AUXStatusScreen(BaseScreen):
    """Real-time AUX status tracking and management"""

    def __init__(self, *args, **kwargs):
        page = kwargs.pop('page', None)
        user = kwargs.pop('user', None)
        session = kwargs.pop('session', None)
        employee_id = kwargs.pop('employee_id', None)

        if len(args) > 0:
            if isinstance(args[0], ft.Page):
                page = args[0]
            elif hasattr(args[0], 'query') or hasattr(args[0], 'add'):
                session = args[0]
        if len(args) > 1:
            if isinstance(args[1], (dict, object)) and not isinstance(args[1], int):
                user = args[1]
            elif isinstance(args[1], int):
                employee_id = args[1]

        super().__init__(page=page, **kwargs)

        if session is None:
            try:
                from database.session_manager import get_db_session
                session = get_db_session()
            except Exception:
                session = None
        self.session = session

        self.user = user
        if employee_id is None and user is not None:
            user_id = user.get('id') if isinstance(user, dict) else getattr(user, 'id', None)
            if user_id and session:
                try:
                    from database.session_manager import get_employee_by_user_id
                    emp = get_employee_by_user_id(session, user_id)
                    employee_id = emp.id if emp else user_id
                except Exception:
                    employee_id = user_id or 1
        if not employee_id:
            employee_id = 1
        self.employee_id = employee_id

        self.current_status = None
        self.current_duration = 0

        main_content = self.build_screen()
        if main_content:
            self.controls = [main_content]

        try:
            self.on_screen_load()
        except Exception:
            pass

    def build_screen(self):
        """Build AUX status screen"""

        # Status control strip
        status_strip = self._build_status_strip()

        # Current status display
        current_status_panel = self._build_current_status_panel()

        # Daily timeline
        timeline = self._build_daily_timeline()

        # Statistics
        stats = self._build_statistics_panel()

        # Main content
        main_content = ft.Column(
            controls=[
                ft.Container(
                    content=ft.Text("AUX Status Management",
                                    size=24, weight="bold"),
                    padding=10
                ),
                status_strip,
                ft.Divider(),
                current_status_panel,
                ft.Divider(),
                timeline,
                ft.Divider(),
                stats
            ],
            scroll=ft.ScrollMode.AUTO
        )

        return main_content

    def _build_status_strip(self) -> ft.Container:
        """Build status control strip with 7 buttons"""

        statuses = [
            ("On Production", AUXStatus.ON_PRODUCTION, "#4CAF50"),
            ("Free Idle", AUXStatus.FREE_IDLE, "#2196F3"),
            ("In Meeting", AUXStatus.IN_MEETING, "#FF9800"),
            ("On Break", AUXStatus.ON_BREAK, "#9C27B0"),
            ("On Lunch", AUXStatus.ON_LUNCH, "#FFC107"),
            ("In Training", AUXStatus.IN_TRAINING, "#03A9F4"),
            ("Offline", AUXStatus.OFFLINE, "#9E9E9E")
        ]

        buttons = []
        for label, status, color in statuses:
            btn = ft.ElevatedButton(
                text=label,
                on_click=lambda e, s=status: self._set_status(s),
                style=ft.ButtonStyle(
                    bgcolor=color,
                    color="white"
                ),
                expand=True
            )
            buttons.append(btn)

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(controls=buttons[:4], spacing=5),
                    ft.Row(controls=buttons[4:], spacing=5)
                ],
                spacing=5
            ),
            padding=10
        )

    def _build_current_status_panel(self) -> ft.Container:
        """Build current status display"""

        self.status_text = ft.Text("Loading...", size=18, weight="bold")
        self.duration_text = ft.Text("00:00:00", size=36, weight="bold")
        self.color_indicator = ft.Container(
            width=50, height=50, bgcolor="#CCCCCC", border_radius=25
        )

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            self.color_indicator,
                            ft.Column(
                                controls=[
                                    ft.Text("Current Status",
                                            size=12, color="gray"),
                                    self.status_text
                                ]
                            )
                        ],
                        spacing=20,
                        alignment=ft.MainAxisAlignment.START
                    ),
                    ft.Divider(),
                    ft.Text("Duration", size=12, color="gray"),
                    self.duration_text
                ],
                spacing=10
            ),
            padding=20,
            bgcolor=ft.Colors.SURFACE_VARIANT,
            border_radius=10
        )

    def _build_daily_timeline(self) -> ft.Container:
        """Build daily timeline view"""

        self.timeline_content = ft.Column(spacing=5)

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Text("Daily Timeline", size=16, weight="bold"),
                    ft.Divider(height=10),
                    self.timeline_content
                ]
            ),
            padding=10
        )

    def _build_statistics_panel(self) -> ft.Container:
        """Build statistics panel"""

        self.productive_time = ft.Text("0h 0m", size=16)
        self.adheren_score = ft.Text("0%", size=16)

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Text("Daily Statistics", size=16, weight="bold"),
                    ft.Divider(height=10),
                    ft.Row(
                        controls=[
                            ft.Column(
                                controls=[
                                    ft.Text("Productive Time",
                                            size=12, color="gray"),
                                    self.productive_time
                                ]
                            ),
                            ft.Column(
                                controls=[
                                    ft.Text("Adherence Score",
                                            size=12, color="gray"),
                                    self.adheren_score
                                ]
                            )
                        ],
                        spacing=40
                    )
                ]
            ),
            padding=10,
            bgcolor=ft.Colors.SURFACE_VARIANT,
            border_radius=10
        )

    def _set_status(self, status: AUXStatus):
        """Set employee status"""

        try:
            AUXStatusManager.set_status(self.session, self.employee_id, status)
            self.session.commit()

            # Refresh UI
            self._refresh_status_display()

            self.page.snack_bar = ft.SnackBar(
                ft.Text(f"Status changed to {status.value}")
            )
            self.page.snack_bar.open = True
            self.page.update()

        except Exception as e:
            self.page.snack_bar = ft.SnackBar(
                ft.Text(f"Error: {str(e)}")
            )
            self.page.snack_bar.open = True
            self.page.update()

    def _refresh_status_display(self):
        """Refresh current status display"""

        current = AUXStatusManager.get_current_status(
            self.session, self.employee_id)

        if current:
            self.status_text.value = current.status.value
            duration = AUXStatusManager.get_status_duration(
                self.session, self.employee_id)

            hours = int(duration // 3600)
            minutes = int((duration % 3600) // 60)
            seconds = int(duration % 60)

            self.duration_text.value = f"{hours:02d}:{minutes:02d}:{seconds:02d}"

            # Update color indicator
            color_map = {
                AUXStatus.ON_PRODUCTION: "#4CAF50",
                AUXStatus.FREE_IDLE: "#2196F3",
                AUXStatus.IN_MEETING: "#FF9800",
                AUXStatus.ON_BREAK: "#9C27B0",
                AUXStatus.ON_LUNCH: "#FFC107",
                AUXStatus.IN_TRAINING: "#03A9F4",
                AUXStatus.OFFLINE: "#9E9E9E"
            }
            self.color_indicator.bgcolor = color_map.get(
                current.status, "#CCCCCC")

        # Update timeline
        self._refresh_timeline()

        # Update statistics
        self._refresh_statistics()

        self.page.update()

    def _refresh_timeline(self):
        """Refresh daily timeline"""

        today = date.today()
        timeline_data = AUXStatusManager.get_daily_timeline(
            self.session, self.employee_id, today
        )

        self.timeline_content.controls.clear()

        for log in timeline_data:
            duration = log.duration_minutes or 0
            hours = duration // 60
            minutes = duration % 60

            time_str = log.start_time.strftime(
                "%H:%M") if log.start_time else "N/A"
            duration_str = f"{hours}h {minutes}m" if duration > 0 else "Ongoing"

            self.timeline_content.controls.append(
                ft.Row(
                    controls=[
                        ft.Container(
                            width=100,
                            content=ft.Text(time_str, size=12)
                        ),
                        ft.Container(
                            expand=True,
                            content=ft.Text(log.status.value, size=12)
                        ),
                        ft.Container(
                            width=80,
                            content=ft.Text(
                                duration_str, size=12, color="gray")
                        )
                    ],
                    spacing=10
                )
            )

    def _refresh_statistics(self):
        """Refresh statistics"""

        today = date.today()
        productive = AUXStatusManager.get_productive_time(
            self.session, self.employee_id, today
        )

        hours = int(productive // 3600)
        minutes = int((productive % 3600) // 60)

        self.productive_time.value = f"{hours}h {minutes}m"

        # Calculate adherence score (8-hour per day target)
        adherence = AUXStatusManager.get_adherence_score(
            self.session, self.employee_id, today, today
        )

        self.adheren_score.value = f"{adherence:.0f}%"

    def on_screen_load(self):
        """Called when screen loads"""
        self._refresh_status_display()

    def on_screen_unload(self):
        """Called when screen unloads"""
        pass
