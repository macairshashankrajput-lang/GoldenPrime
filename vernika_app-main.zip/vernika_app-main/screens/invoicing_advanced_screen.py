"""
Advanced Invoicing Screen - Invoice Management
Create, edit, and track invoices with recurring setup
"""

import flet as ft
from decimal import Decimal
from datetime import datetime
from sqlalchemy.orm import Session
from database.new_models import EnhancedInvoice
from database.models import Supplier
from utils.invoice_generator import InvoiceGenerator
from utils.pdf_generator import PDFGenerator
from core.base_screen import BaseScreen


class AdvancedInvoicingScreen(BaseScreen):
    """Advanced invoicing management"""

    def __init__(self, *args, **kwargs):
        page = kwargs.pop('page', None)
        user = kwargs.pop('user', None)
        session = kwargs.pop('session', None)
        employee_id = kwargs.pop('employee_id', None)

        if len(args) > 0:
            if isinstance(args[0], ft.Page):
                page = args[0]
            elif hasattr(args[0], 'query') or hasattr(args[0], 'add'):
                session = args[0]
        if len(args) > 1:
            if isinstance(args[1], (dict, object)) and not isinstance(args[1], int):
                user = args[1]
            elif isinstance(args[1], int):
                employee_id = args[1]

        super().__init__(page=page, **kwargs)

        if session is None:
            try:
                from database.session_manager import get_db_session
                session = get_db_session()
            except Exception:
                session = None
        self.session = session

        self.user = user
        if employee_id is None and user is not None:
            user_id = user.get('id') if isinstance(user, dict) else getattr(user, 'id', None)
            if user_id and session:
                try:
                    from database.session_manager import get_employee_by_user_id
                    emp = get_employee_by_user_id(session, user_id)
                    employee_id = emp.id if emp else user_id
                except Exception:
                    employee_id = user_id or 1
        if not employee_id:
            employee_id = 1
        self.employee_id = employee_id

        main_content = self.build_screen()
        if main_content:
            self.controls = [main_content]

# Alias for consistent naming
InvoicingAdvancedScreen = AdvancedInvoicingScreen

    def build_screen(self):
        """Build invoicing screen"""

        # Summary panel
        summary_panel = self._build_summary_panel()

        # Tabs for views
        self.tab_control = ft.Tabs(
            selected_index=0,
            on_change=self._on_tab_change,
            tabs=[
                ft.Tab(text="All Invoices", content=ft.Container()),
                ft.Tab(text="Pending", content=ft.Container()),
                ft.Tab(text="Recurring", content=ft.Container())
            ]
        )

        # Content container
        self.content_container = ft.Column(
            expand=True,
            scroll=ft.ScrollMode.AUTO
        )

        self._refresh_content()

        # Create button
        create_btn = ft.FloatingActionButton(
            icon=ft.icons.ADD,
            on_click=self._show_create_invoice_dialog
        )

        main_content = ft.Column(
            controls=[
                ft.Container(
                    content=ft.Text("Advanced Invoicing",
                                    size=24, weight="bold"),
                    padding=10
                ),
                summary_panel,
                ft.Divider(),
                self.tab_control,
                self.content_container
            ],
            expand=True
        )

        # Set floating action button
        self.page.floating_action_button = create_btn
        self.page.floating_action_button_location = ft.FloatingActionButtonLocation.CENTER_RIGHT

        return main_content

    def _build_summary_panel(self) -> ft.Container:
        """Build summary statistics panel"""

        summary = InvoiceGenerator.get_invoice_summary(self.session)

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            ft.Column(
                                controls=[
                                    ft.Text("Total Invoices",
                                            size=12, color="gray"),
                                    ft.Text(
                                        str(summary.get("total_invoices", 0)), size=18, weight="bold")
                                ]
                            ),
                            ft.Column(
                                controls=[
                                    ft.Text("Pending", size=12, color="gray"),
                                    ft.Text(str(summary.get("sent", 0)),
                                            size=18, weight="bold", color="#FF9800")
                                ]
                            ),
                            ft.Column(
                                controls=[
                                    ft.Text("Paid", size=12, color="gray"),
                                    ft.Text(str(summary.get("paid", 0)),
                                            size=18, weight="bold", color="#4CAF50")
                                ]
                            ),
                            ft.Column(
                                controls=[
                                    ft.Text("Total Amount",
                                            size=12, color="gray"),
                                    ft.Text(
                                        f"${summary.get('total_amount', '0')}", size=16, weight="bold")
                                ]
                            )
                        ],
                        spacing=30
                    )
                ]
            ),
            padding=15,
            bgcolor=ft.Colors.SURFACE_VARIANT,
            border_radius=10
        )

    def _refresh_content(self):
        """Refresh tab content"""

        index = self.tab_control.selected_index

        self.content_container.controls.clear()

        if index == 0:
            self._show_all_invoices()
        elif index == 1:
            self._show_pending_invoices()
        elif index == 2:
            self._show_recurring_invoices()

    def _on_tab_change(self, e):
        """Handle tab change"""
        self._refresh_content()

    def _show_all_invoices(self):
        """Show all invoices"""

        invoices = self.session.query(EnhancedInvoice).order_by(
            EnhancedInvoice.invoice_date.desc()
        ).all()

        if not invoices:
            self.content_container.controls.append(
                ft.Text("No invoices found", color="gray")
            )
            return

        for invoice in invoices:
            card = self._build_invoice_card(invoice)
            self.content_container.controls.append(card)

    def _show_pending_invoices(self):
        """Show pending invoices"""

        invoices = InvoiceGenerator.get_pending_invoices(self.session)

        if not invoices:
            self.content_container.controls.append(
                ft.Text("No pending invoices", color="gray")
            )
            return

        for invoice in invoices:
            card = self._build_invoice_card(invoice)
            self.content_container.controls.append(card)

    def _show_recurring_invoices(self):
        """Show recurring invoices"""

        invoices = self.session.query(EnhancedInvoice).filter(
            EnhancedInvoice.recurring_type != "ONCE"
        ).all()

        if not invoices:
            self.content_container.controls.append(
                ft.Text("No recurring invoices", color="gray")
            )
            return

        for invoice in invoices:
            card = self._build_invoice_card(invoice)
            self.content_container.controls.append(card)

    def _build_invoice_card(self, invoice: EnhancedInvoice) -> ft.Container:
        """Build invoice card"""

        status_colors = {
            "DRAFT": "#9E9E9E",
            "SENT": "#FF9800",
            "PAID": "#4CAF50",
            "CANCELLED": "#F44336"
        }

        status_color = status_colors.get(invoice.status, "#9E9E9E")
        supplier = self.session.query(Supplier).get(invoice.supplier_id)

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            ft.Column(
                                controls=[
                                    ft.Text(
                                        invoice.invoice_number or "INV-000", weight="bold", size=14),
                                    ft.Text(
                                        supplier.name if supplier else "Unknown Supplier",
                                        size=11,
                                        color="gray"
                                    ),
                                    ft.Text(
                                        f"Date: {invoice.invoice_date.strftime('%d %b, %Y') if invoice.invoice_date else 'N/A'}",
                                        size=10,
                                        color="gray"
                                    )
                                ],
                                expand=True
                            ),
                            ft.Column(
                                controls=[
                                    ft.Text(f"${invoice.total_amount}",
                                            weight="bold", size=16),
                                    ft.Text(
                                        invoice.status,
                                        size=10,
                                        weight="bold",
                                        color=status_color
                                    )
                                ]
                            )
                        ],
                        spacing=10
                    ),
                    ft.Divider(height=10),
                    ft.Row(
                        controls=[
                            ft.Text(
                                f"Tax: ${invoice.tax_amount} ({invoice.tax_rate}%)",
                                size=10,
                                color="gray"
                            ),
                            ft.Text(
                                f"Due: {invoice.due_date.strftime('%d %b') if invoice.due_date else 'N/A'}",
                                size=10,
                                color="gray"
                            )
                        ]
                    ),
                    ft.Divider(height=10),
                    ft.Row(
                        controls=[
                            ft.TextButton(
                                text="View Details",
                                on_click=lambda e: self._show_invoice_details(
                                    invoice)
                            ),
                            ft.TextButton(
                                text="Download PDF",
                                on_click=lambda e: self._download_invoice_pdf(
                                    invoice)
                            ),
                            ft.TextButton(
                                text="Edit",
                                on_click=lambda e: self._show_edit_invoice_dialog(
                                    invoice)
                            ) if invoice.status == "DRAFT" else ft.Container(),
                            ft.PopupMenuButton(
                                items=[
                                    ft.PopupMenuItem(
                                        text="Mark as Sent",
                                        on_click=lambda e: self._update_status(
                                            invoice.id, "SENT")
                                    ) if invoice.status == "DRAFT" else None,
                                    ft.PopupMenuItem(
                                        text="Mark as Paid",
                                        on_click=lambda e: self._update_status(
                                            invoice.id, "PAID")
                                    ) if invoice.status == "SENT" else None,
                                    ft.PopupMenuItem(
                                        text="Delete",
                                        on_click=lambda e: self._delete_invoice(
                                            invoice.id)
                                    )
                                ]
                            )
                        ]
                    )
                ],
                spacing=5
            ),
            padding=12,
            border=ft.border.all(1, status_color),
            border_radius=8,
            bgcolor=ft.Colors.with_opacity(0.05, status_color)
        )

    def _show_invoice_details(self, invoice: EnhancedInvoice):
        """Show invoice details"""

        supplier = self.session.query(Supplier).get(invoice.supplier_id)

        details_content = ft.Column(
            controls=[
                ft.Row(
                    controls=[
                        ft.Column(
                            controls=[
                                ft.Text("Invoice Number",
                                        size=10, color="gray"),
                                ft.Text(invoice.invoice_number or "N/A",
                                        weight="bold", size=14)
                            ]
                        ),
                        ft.Column(
                            controls=[
                                ft.Text("Status", size=10, color="gray"),
                                ft.Text(invoice.status, weight="bold", size=14)
                            ]
                        )
                    ]
                ),
                ft.Divider(),
                ft.Text("Supplier", weight="bold"),
                ft.Text(supplier.name if supplier else "Unknown", size=12),
                ft.Divider(),
                ft.Text("Amounts", weight="bold"),
                ft.Row(
                    controls=[
                        ft.Column(controls=[
                            ft.Text("Subtotal:", size=11),
                            ft.Text(f"${invoice.amount}",
                                    size=12, weight="bold")
                        ]),
                        ft.Column(controls=[
                            ft.Text(f"Tax ({invoice.tax_rate}%):", size=11),
                            ft.Text(f"${invoice.tax_amount}",
                                    size=12, weight="bold")
                        ]),
                        ft.Column(controls=[
                            ft.Text("Total:", size=11),
                            ft.Text(f"${invoice.total_amount}",
                                    size=12, weight="bold", color="#4CAF50")
                        ])
                    ],
                    spacing=20
                ),
                ft.Divider(),
                ft.Text("Dates", weight="bold"),
                ft.Row(
                    controls=[
                        ft.Column(controls=[
                            ft.Text("Invoice Date:", size=10),
                            ft.Text(invoice.invoice_date.strftime(
                                "%d %b, %Y") if invoice.invoice_date else "N/A", size=11)
                        ]),
                        ft.Column(controls=[
                            ft.Text("Due Date:", size=10),
                            ft.Text(invoice.due_date.strftime("%d %b, %Y")
                                    if invoice.due_date else "N/A", size=11)
                        ])
                    ],
                    spacing=20
                ),
                ft.Divider(),
                ft.Text("Recurring", weight="bold"),
                ft.Text(f"Type: {invoice.recurring_type or 'ONCE'}", size=11),
                if invoice.recurring_interval else ft.Container(),
                ft.Text(f"Interval: {invoice.recurring_interval} days",
                        size=11) if invoice.recurring_interval else ft.Container()
            ]
        )

        dialog = ft.AlertDialog(
            title=ft.Text("Invoice Details"),
            content=details_content,
            actions=[
                ft.TextButton("Close", on_click=lambda e: self._close_dialog())
            ]
        )

        self.page.dialog = dialog
        dialog.open = True
        self.page.update()

    def _show_create_invoice_dialog(self, e=None):
        """Show create invoice dialog"""

        suppliers = self.session.query(Supplier).all()

        supplier_dropdown = ft.Dropdown(
            label="Supplier",
            options=[ft.dropdown.Option(str(s.id), s.name) for s in suppliers],
            width=300
        )
        amount_field = ft.TextField(
            label="Amount", input_filter=ft.NumbersOnlyInputFilter())
        tax_rate_field = ft.TextField(label="Tax Rate (%)", value="0")
        description_field = ft.TextField(
            label="Description", multiline=True, max_lines=3)
        recurring_dropdown = ft.Dropdown(
            label="Recurring Type",
            options=[
                ft.dropdown.Option("ONCE", "One-time"),
                ft.dropdown.Option("MONTHLY", "Monthly"),
                ft.dropdown.Option("QUARTERLY", "Quarterly"),
                ft.dropdown.Option("ANNUAL", "Annual")
            ],
            value="ONCE"
        )

        def on_create(e):
            try:
                supplier_id = int(supplier_dropdown.value)
                amount = Decimal(amount_field.value or "0")
                tax_rate = float(tax_rate_field.value or "0")
                description = description_field.value
                recurring = recurring_dropdown.value

                invoice = InvoiceGenerator.create_invoice(
                    self.session, supplier_id, amount, tax_rate, description, recurring
                )

                if invoice:
                    self.page.snack_bar = ft.SnackBar(
                        ft.Text(f"Invoice {invoice.invoice_number} created"))
                    self.page.snack_bar.open = True
                    self._refresh_content()
                    dialog.open = False
                    self.page.update()

            except Exception as ex:
                self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
                self.page.snack_bar.open = True
                self.page.update()

        dialog = ft.AlertDialog(
            title=ft.Text("Create Invoice"),
            content=ft.Column(
                controls=[supplier_dropdown, amount_field,
                          tax_rate_field, description_field, recurring_dropdown],
                spacing=10
            ),
            actions=[
                ft.TextButton(
                    "Cancel", on_click=lambda e: self._close_dialog()),
                ft.TextButton("Create", on_click=on_create)
            ]
        )

        self.page.dialog = dialog
        dialog.open = True
        self.page.update()

    def _show_edit_invoice_dialog(self, invoice: EnhancedInvoice):
        """Show edit invoice dialog"""

        amount_field = ft.TextField(label="Amount", value=str(invoice.amount))
        tax_rate_field = ft.TextField(
            label="Tax Rate (%)", value=str(invoice.tax_rate))
        description_field = ft.TextField(
            label="Description", value=invoice.description or "", multiline=True)

        def on_update(e):
            try:
                invoice.amount = Decimal(amount_field.value or "0")
                invoice.tax_rate = float(tax_rate_field.value or "0")
                invoice.description = description_field.value
                self.session.commit()

                self.page.snack_bar = ft.SnackBar(ft.Text("Invoice updated"))
                self.page.snack_bar.open = True
                self._refresh_content()
                dialog.open = False
                self.page.update()

            except Exception as ex:
                self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
                self.page.snack_bar.open = True
                self.page.update()

        dialog = ft.AlertDialog(
            title=ft.Text("Edit Invoice"),
            content=ft.Column(
                controls=[amount_field, tax_rate_field, description_field],
                spacing=10
            ),
            actions=[
                ft.TextButton(
                    "Cancel", on_click=lambda e: self._close_dialog()),
                ft.TextButton("Update", on_click=on_update)
            ]
        )

        self.page.dialog = dialog
        dialog.open = True
        self.page.update()

    def _download_invoice_pdf(self, invoice: EnhancedInvoice):
        """Download invoice as PDF"""

        try:
            PDFGenerator.generate_invoice_pdf(invoice)
            self.page.snack_bar = ft.SnackBar(
                ft.Text("Invoice PDF downloaded"))
            self.page.snack_bar.open = True
            self.page.update()

        except Exception as ex:
            self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
            self.page.snack_bar.open = True
            self.page.update()

    def _update_status(self, invoice_id: int, status: str):
        """Update invoice status"""

        try:
            InvoiceGenerator.update_invoice_status(
                self.session, invoice_id, status)
            self.page.snack_bar = ft.SnackBar(
                ft.Text(f"Invoice marked as {status}"))
            self.page.snack_bar.open = True
            self._refresh_content()
            self.page.update()

        except Exception as ex:
            self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
            self.page.snack_bar.open = True
            self.page.update()

    def _delete_invoice(self, invoice_id: int):
        """Delete invoice"""

        try:
            invoice = self.session.query(EnhancedInvoice).get(invoice_id)
            if invoice:
                self.session.delete(invoice)
                self.session.commit()
                self.page.snack_bar = ft.SnackBar(ft.Text("Invoice deleted"))
                self.page.snack_bar.open = True
                self._refresh_content()
                self.page.update()

        except Exception as ex:
            self.page.snack_bar = ft.SnackBar(ft.Text(f"Error: {str(ex)}"))
            self.page.snack_bar.open = True
            self.page.update()

    def _close_dialog(self):
        """Close dialog"""
        self.page.dialog.open = False
        self.page.update()

    def on_screen_load(self):
        """Called when screen loads"""
        self._refresh_content()

    def on_screen_unload(self):
        """Called when screen unloads"""
        pass
