import type { Express } from "express";
import { ENV } from "./env";
import { createGoldenPrimeImageSignedUrl } from "../supabaseStorage";

export function registerStorageProxy(app: Express) {
  app.get(["/manus-storage/*", "/api/storage/*"], async (req, res) => {
    const key = (req.params as Record<string, string>)[0];
    if (!key) {
      res.status(400).send("Missing storage key");
      return;
    }

    if (key.startsWith("supabase/")) {
      try {
        const signedUrl = await createGoldenPrimeImageSignedUrl(key);
        if (!signedUrl) {
          res.status(404).send("Image not found");
          return;
        }
        res.set("Cache-Control", "private, max-age=60");
        res.redirect(307, signedUrl);
      } catch (error) {
        console.error("[StorageProxy] Supabase image access failed:", error);
        res.status(502).send("Image storage error");
      }
      return;
    }

    if (!ENV.forgeApiUrl || !ENV.forgeApiKey) {
      res.status(500).send("Storage proxy not configured");
      return;
    }

    try {
      const forgeUrl = new URL(
        "v1/storage/presign/get",
        ENV.forgeApiUrl.replace(/\/+$/, "") + "/",
      );
      forgeUrl.searchParams.set("path", key);

      const forgeResp = await fetch(forgeUrl, {
        headers: { Authorization: `Bearer ${ENV.forgeApiKey}` },
      });

      if (!forgeResp.ok) {
        const body = await forgeResp.text().catch(() => "");
        if (forgeResp.status === 404) {
          res.status(404).send("Storage object not found");
          return;
        }
        console.error(`[StorageProxy] forge error: ${forgeResp.status} ${body}`);
        res.status(502).send("Storage backend error");
        return;
      }

      const { url } = (await forgeResp.json()) as { url: string };
      if (!url) {
        res.status(502).send("Empty signed URL from backend");
        return;
      }

      res.set("Cache-Control", "no-store");
      res.redirect(307, url);
    } catch (err) {
      console.error("[StorageProxy] failed:", err);
      res.status(502).send("Storage proxy error");
    }
  });
}
