/**
 * DESIGN REMINDER — Signal & Story:
 * Detailed case studies use a clear proof hierarchy. State scope and evidence honestly, then show an actionable process.
 * Illustrative studies must remain visibly labelled and never simulate client testimonials, metrics, or outcomes.
 */
import { ArrowLeft, ArrowUpRight, Check } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Link, useRoute } from "wouter";

const studyData = {
  "v-trims-design-seo": {
    kind: "Applied learning project · SEO",
    status: "Practical course application · outcome data not supplied",
    title: "V-Trims Design: turning course learning into a search-focused practice.",
    dek: "After completing my Digital Marketing course, I applied its core SEO concepts to a V-Trims Design project. The brief gave me a practical space to shift from theory toward a more structured, search-focused way of thinking.",
    image: "/portfolio-assets/tanu-case-study-seo-strategy.webp",
    scope: ["Keyword research and search-intent exploration", "On-page optimisation principles", "Content relevance and page-structure thinking", "A measurement framework for future review"],
    process: [["Understand the search", "Start with the language a potential visitor may use and the question they are trying to answer. This transforms keyword research from a list of terms into a more useful intent map."], ["Structure the page", "Use headings, page signals, and supporting content to give the topic a clear shape. The focus was on relevance and readability—not on artificial keyword repetition."], ["Prepare the next measurement step", "Traffic, rankings, and revenue outcomes were not available in the project materials. Rather than invent results, the case identifies the baseline information that would make a future review meaningful."]],
    evidence: "This is a real practical learning project. The portfolio does not claim growth results because no before-and-after analytics, search-console data, or sales data were supplied.",
  },
  "digital-foundation": {
    kind: "Illustrative capability study · Digital transformation",
    status: "Project framework · not a paid client case study",
    title: "From scattered business activity to a clearer digital foundation.",
    dek: "A small business does not always need a complete overhaul. It needs a clear view of where customer attention, internal work, and information begin to break apart—then a practical first system that reconnects them.",
    image: "/portfolio-assets/tanu-case-study-digital-blueprint.webp",
    scope: ["Business-friction and client-journey mapping", "Website and conversion-path priorities", "A marketing and content starting plan", "A phased build, automation, and reporting roadmap"],
    process: [["Map the friction", "Surface where the business is losing time or clarity: a difficult-to-find offer, a confusing enquiry path, disconnected follow-up, or information that only lives in people’s heads."], ["Choose the first useful system", "Select the smallest high-value next move. Depending on the brief, that might be a website foundation, a lead-capture flow, a content structure, or a lightweight operating workflow."], ["Evolve with evidence", "Treat the release as a useful beginning. Capture feedback, observe usage, and use the next decision—not a fixed technology wish list—to shape the roadmap."]],
    evidence: "This is an illustrative capability framework that demonstrates how I would approach an end-to-end digital brief. It is not presented as a client engagement or a claimed business outcome.",
  },
  "automation-workflow": {
    kind: "Illustrative capability study · Automation",
    status: "Project framework · not a paid client case study",
    title: "Making repeat work visible before making it automatic.",
    dek: "Automation is most useful when it removes repetitive movement between people and tools while leaving room for the decisions that still need context, judgment, or a human relationship.",
    image: "/portfolio-assets/tanu-case-study-automation-workflow.webp",
    scope: ["Workflow observation and handoff mapping", "A trigger, action, and ownership definition", "Lightweight script or no-code automation concept", "A clear exception and review path"],
    process: [["Find the repeat", "Identify the task that occurs frequently without adding much decision value: moving a lead between tools, preparing a status update, routing a request, or assembling a routine file."], ["Design for people", "Define the trigger, output, and owner. A helpful automation should make the handoff clearer and leave the team in control when something needs attention."], ["Review the relief", "Test whether the workflow reduces repeated activity, creates a more consistent output, and remains understandable to someone who did not originally build it."]],
    evidence: "This is an illustrative workflow study. It does not claim that a specific client automation was deployed or that a time-saving figure was achieved.",
  },
  "decision-dashboard": {
    kind: "Illustrative capability study · Data visualisation",
    status: "Project framework · not a paid client case study",
    title: "A reporting view designed around the next decision—not the biggest data dump.",
    dek: "A dashboard earns its place when it helps someone notice a meaningful change, understand the context, and choose the next action without hunting through an overgrown spreadsheet.",
    image: "/portfolio-assets/tanu-case-study-data-visualization.webp",
    scope: ["Decision questions and source-data mapping", "Core metric and data-quality definition", "Dashboard hierarchy and chart selection", "A review rhythm for improvements and exceptions"],
    process: [["Start with the decision", "Ask what the person viewing the report needs to decide: which lead source needs attention, what content is working, where a process is slowing down, or what to review next."], ["Create a signal hierarchy", "Bring the most important changes forward through clear comparison, grouping, and visual contrast. Supporting detail can remain available without making every number equally loud."], ["Keep the structure trustworthy", "Data visualisation relies on the work beneath it: understandable sources, useful fields, consistent definitions, and a process for identifying gaps before they become false certainty."]],
    evidence: "This is an illustrative data and reporting framework. It does not contain client data, proprietary figures, or claimed performance gains.",
  },
} as const;

export default function CaseStudyDetail() {
  const [, params] = useRoute("/case-studies/:slug");
  const { data: managedStudies = [] } = trpc.publicContent.caseStudies.useQuery();
  const managedStudy = managedStudies.find(study => study.slug === params?.slug);
  const study = managedStudy
    ? {
        kind: managedStudy.eyebrow,
        status: "Published managed case study",
        title: managedStudy.title,
        dek: managedStudy.summary,
        image: managedStudy.heroImage || "/portfolio-assets/tanu-case-study-digital-blueprint.webp",
        scope: managedStudy.scope.split("\n").map(item => item.trim()).filter(Boolean),
        process: [["Working method", managedStudy.process] as [string, string]],
        evidence: managedStudy.evidenceNote,
      }
    : studyData[params?.slug as keyof typeof studyData] ?? studyData["v-trims-design-seo"];

  return (
    <div className="min-h-screen overflow-x-hidden bg-[#f7f1e8] text-[#1b1b1b]">
      <header className="border-b border-[#1b1b1b]/10 bg-[#f7f1e8]/92 backdrop-blur-xl"><div className="mx-auto flex h-[76px] max-w-[1440px] items-center justify-between px-5 sm:px-8 lg:px-12"><Link href="/" className="group flex items-center gap-3" aria-label="Tanu Singh home"><img src="/portfolio-assets/tanu-signal-mark.webp" alt="Tanu Singh signal mark" className="h-9 w-9 object-contain transition-transform duration-300 group-hover:rotate-6" /><span className="font-serif text-[1.38rem] leading-none tracking-[-0.06em]">tanu <em className="text-[#f04438]">singh</em></span></Link><Link href="/case-studies" className="inline-flex items-center gap-2 font-manrope text-xs font-extrabold"><ArrowLeft className="h-4 w-4 text-[#f04438]" /> All case studies</Link></div></header>

      <main>
        <section className="px-5 pb-16 pt-20 sm:px-8 sm:pt-24 lg:px-12 lg:pb-24 lg:pt-32"><div className="mx-auto max-w-[1120px]"><p className="eyebrow text-[#f04438]">{study.kind}</p><p className="mt-4 inline-block border border-[#1b1b1b]/15 bg-[#ede5d8] px-3 py-2 font-manrope text-[9px] font-extrabold uppercase tracking-[0.13em] text-[#5a554f]">{study.status}</p><h1 className="mt-6 max-w-[980px] font-serif text-[clamp(3.7rem,7vw,7.8rem)] leading-[0.83] tracking-[-0.075em]">{study.title}</h1><p className="mt-10 max-w-[700px] border-l-2 border-[#f04438] pl-5 font-manrope text-lg leading-8 text-[#4f4a44] sm:text-xl">{study.dek}</p></div></section>
        <section className="px-5 pb-16 sm:px-8 lg:px-12 lg:pb-24"><div className="mx-auto max-w-[1120px]"><img src={study.image} alt="Editorial case-study visual" className="h-[500px] w-full object-cover sm:h-[680px]" /></div></section>
        <section className="border-y border-[#1b1b1b]/12 bg-[#ede5d8] px-5 py-12 sm:px-8 lg:px-12 lg:py-16"><div className="mx-auto grid max-w-[1120px] gap-8 lg:grid-cols-12"><div className="lg:col-span-3"><p className="eyebrow">Scope & deliverables</p></div><ul className="grid gap-3 sm:grid-cols-2 lg:col-span-8 lg:col-start-5">{study.scope.map((item) => <li key={item} className="flex gap-3 border-t border-[#1b1b1b]/15 pt-3 font-manrope text-sm font-semibold leading-6 text-[#3f3a34]"><Check className="mt-1 h-4 w-4 shrink-0 text-[#f04438]" />{item}</li>)}</ul></div></section>
        <article className="px-5 py-20 sm:px-8 lg:px-12 lg:py-28"><div className="mx-auto grid max-w-[1120px] gap-12 lg:grid-cols-12 lg:gap-16"><aside className="lg:col-span-3"><p className="eyebrow">Working method</p><p className="mt-4 font-manrope text-sm leading-6 text-[#5a554f]">A clear sequence helps keep the work connected to the real brief rather than the most fashionable tool.</p></aside><div className="space-y-14 lg:col-span-8 lg:col-start-5">{study.process.map(([heading, body], index) => <section key={heading} className="border-t border-[#1b1b1b]/15 pt-5"><span className="article-index">0{index + 1}</span><h2 className="mt-4 font-serif text-[clamp(2.5rem,4.5vw,4.5rem)] leading-[0.9] tracking-[-0.06em]">{heading}</h2><p className="mt-6 max-w-[650px] font-manrope text-base leading-8 text-[#4f4a44] sm:text-lg">{body}</p></section>)}</div></div></article>
        <section className="bg-[#1b1b1b] px-5 py-16 text-[#f7f1e8] sm:px-8 lg:px-12 lg:py-20"><div className="mx-auto grid max-w-[1120px] gap-8 lg:grid-cols-12 lg:items-center"><div className="lg:col-span-8"><p className="eyebrow text-[#f04438]">Evidence note</p><p className="mt-4 font-serif text-3xl leading-[0.96] tracking-[-0.05em]">{study.evidence}</p></div><Link href="/#contact" className="inline-flex items-center gap-2 border-b border-[#f7f1e8]/50 pb-2 font-manrope text-sm font-extrabold lg:col-span-2 lg:col-start-11">Discuss a similar brief <ArrowUpRight className="h-4 w-4 text-[#f04438]" /></Link></div></section>
      </main>
    </div>
  );
}
