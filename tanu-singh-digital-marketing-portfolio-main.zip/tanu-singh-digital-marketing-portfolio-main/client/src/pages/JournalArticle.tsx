/**
 * DESIGN REMINDER — Signal & Story:
 * Detailed journal entries use clear editorial hierarchy, warm paper space, and grounded first-person learning notes.
 * Avoid inflated claims; make insights practical, specific, and human.
 */
import { ArrowLeft, ArrowUpRight } from "lucide-react";
import { Link, useRoute } from "wouter";

const articles = {
  "seo-foundations": {
    category: "SEO notes",
    meta: "Practical project reflection · 4 min read",
    title: "What an SEO project taught me about starting with intent.",
    dek: "My SEO project for V-Trims Design helped me see that search optimisation is less about chasing a phrase and more about matching a real question with a helpful page.",
    image: "/portfolio-assets/tanu-social-content-collage.webp",
    alt: "Tanu Singh holding a blue book outdoors",
    takeaways: ["The clearer the underlying question, the more useful the optimisation can become.", "A page should make its relevance easy to recognise at a glance.", "Foundational work is still meaningful when it creates a more informed next step."],
    sections: [
      ["Begin with the person, not the phrase", "The most useful shift in my thinking was to look beyond a keyword itself. A search term is only a signal. Behind it, someone may be comparing options, looking for a solution, or trying to understand the basics. Starting with that intent made the research feel less mechanical and more connected to the visitor."],
      ["Make the page answerable", "On-page SEO gave me a practical way to think about relevance. Headings, supporting copy, and the structure of a page should make it easier for both a reader and a search engine to understand what is being offered. I focused on how an organised page can create a clearer path from question to answer."],
      ["Treat the work as a foundation", "This project was a learning experience, not a finished growth claim. It gave me hands-on practice with the foundations: keyword research, intent, content relevance, and page structure. The biggest lesson was that useful optimisation begins with empathy and clarity."],
    ],
  },
  "social-content": {
    category: "Content notes",
    meta: "Creative framework · 3 min read",
    title: "A simple lens for making social posts feel more considered.",
    dek: "A strong post does not need to say everything. It needs to give someone one clear reason to pause, understand, and take the next small action.",
    image: "/portfolio-assets/tanu-social-content-collage.webp",
    alt: "Tanu Singh outdoors under a blue sky",
    takeaways: ["A post becomes sharper when its purpose is decided before the format.", "Visual hierarchy should make the central idea easier to notice, not harder.", "Consistency comes from a repeatable rhythm, not a repeated template."],
    sections: [
      ["One post, one job", "When I start thinking about a social post, I first ask what job it should do. Is it there to introduce an idea, make a brand more familiar, invite a response, or help a viewer understand something useful? A single clear job gives the concept its shape."],
      ["Message before decoration", "Visuals are important, but they work best when they support a focused thought. I like to write the core message in one plain sentence before deciding on composition, hierarchy, colour, or supporting details. That makes it easier to keep a post concise rather than crowded."],
      ["Build a recognisable rhythm", "Consistency does not mean repeating one layout. It means creating a visual rhythm that feels recognisable: a repeated detail, a clear type hierarchy, a familiar balance of space and colour. Those small decisions help content feel connected over time."],
    ],
  },
  "practice-notes": {
    category: "Practice notes",
    meta: "Learning reflection · 2 min read",
    title: "Why staying curious is a useful marketing skill.",
    dek: "The more I learn about digital marketing, the more I value the habit of noticing what works, asking why, and turning that observation into a better next step.",
    image: "/portfolio-assets/tanu-social-content-collage.webp",
    alt: "Tanu Singh in a bright floral streetscape",
    takeaways: ["The smallest pattern can lead to a useful marketing question.", "Good ideas stay open to feedback, context, and a changed assumption.", "Learning is most useful when it shapes the next decision in the work."],
    sections: [
      ["Notice the detail", "A useful idea often starts with a small observation: a heading that makes a page easier to scan, a post that makes a complicated topic feel lighter, or a question that keeps appearing in search. Curiosity gives those details a chance to become useful inputs."],
      ["Stay open to the answer", "Marketing is not only about having an immediate solution. It is also about being willing to test an assumption, hear what the audience is asking for, and adjust the message. That is the kind of thinking I want to bring to every project."],
      ["Keep the momentum practical", "The goal of learning is to make better next decisions. I am building my practice by taking what I study, applying it to real situations, and reflecting on what becomes clearer. Progress feels most meaningful when it stays connected to the work."],
    ],
  },
  "building-a-client-demo": {
    category: "Build notes",
    meta: "GlobeFares project reflection · 3 min read",
    title: "What a client demo website taught me about keeping the workflow clear.",
    dek: "The GlobeFares demo project gave me a practical chance to think beyond a page itself and consider the small systems around it: design choices, version control, and deployment.",
    image: "/portfolio-assets/tanu-hero-growth-still-life.webp",
    alt: "Editorial still life representing a focused digital project workflow",
    takeaways: ["A client demo becomes easier to improve when the workflow is visible and organised.", "Tools work better when they are chosen for a specific step instead of added for their own sake.", "A simple handoff path makes a digital build feel more considered and more usable."],
    sections: [
      ["Start with the requirement", "The project was shaped around a client demo brief, which made the first question straightforward: what needs to be clear, useful, and ready to show? Beginning with the requirement helped keep design decisions tied to a real purpose instead of adding features without a reason."],
      ["Give each tool a role", "Canva supported visual design, GitHub supported the code and repository workflow, and Vercel supported deployment. Looking at the tools as a sequence rather than a list helped me understand how a project moves from an idea toward something a client can actually view and discuss."],
      ["Keep the next iteration easy", "A demo is an invitation to improve. I learned that clear structure, tidy files, and a visible deployment path make it easier to take feedback and shape the next version. That practical mindset is useful whether the work is a page, a campaign, or a content system."],
    ],
  },
  "toolkit-with-intent": {
    category: "Tool notes",
    meta: "Working workflow · 3 min read",
    title: "A marketing toolkit works best when each tool has a clear job.",
    dek: "My growing toolkit includes SEO, content, design, and collaboration tools. The important part is not collecting them—it is knowing what question each one helps me answer.",
    image: "/portfolio-assets/tanu-social-gallery-01.webp",
    alt: "Editorial social content study in coral and ink",
    takeaways: ["Start with the task, then choose the tool that supports it most clearly.", "A useful workflow reduces friction between an idea, its execution, and the next review.", "Simple systems are easier to learn from and easier to improve."],
    sections: [
      ["SEO tools create a starting point", "Tools such as WordPress and Rank Math SEO are useful when they help bring structure to on-page work. I see them as a starting point for thinking about headings, content relevance, and page hygiene—not a substitute for understanding the reader or the business."],
      ["Creative tools give an idea a visible form", "Canva and CapCut help turn a content idea into something more tangible. Their value is in speeding up a considered visual decision, whether that means a clear layout, a useful short-form video, or a social post with a stronger hierarchy."],
      ["Collaboration tools keep the work moving", "Google Workspace, GitHub, and Vercel support the practical work around a project: sharing, documenting, iterating, and publishing. I am continuing to build confidence with these systems because the behind-the-scenes workflow matters just as much as the finished screen."],
    ],
  },
  "from-brief-to-blueprint": {
    category: "Freelance notes",
    meta: "End-to-end delivery · 4 min read",
    title: "From a rough brief to a digital blueprint: start where the friction is.",
    dek: "The most useful freelance projects do not begin with a pre-decided deliverable. They begin with the business friction, then turn that uncertainty into a clearer digital next step.",
    image: "/portfolio-assets/tanu-social-gallery-03.webp",
    alt: "Editorial content study representing an organised digital blueprint",
    takeaways: ["The best starting point is a visible business problem, not a favourite tool.", "A blueprint can connect strategy, marketing, product, workflow, and data without pretending every business needs the same system.", "Small useful releases create a better foundation than a large abstract plan."],
    sections: [
      ["Map the real work", "An idea may arrive as a request for a website, an automation, a campaign, or a dashboard. Before choosing the deliverable, I want to understand where the friction actually sits: is the business hard to find, is the customer journey unclear, are tasks repeating, or is useful information hidden in disconnected places? Mapping that first makes the next choice more grounded."],
      ["Build the clearest next step", "A digital blueprint does not need to be complicated. It may be a sharper online presence, a focused SEO plan, a client-facing application, a workflow script, or a clearer reporting view. The point is to connect the work to the outcome the business needs, then make the first release useful enough to learn from."],
      ["Evolve with the business", "I appreciate the Map, Build, Evolve framing used publicly by Vernika because it keeps a digital project connected to the way a business changes. Freelance work can be focused and still have that same discipline: see the current state, make a useful improvement, and leave room for the next version."],
    ],
  },
  "automation-with-a-purpose": {
    category: "Automation notes",
    meta: "Workflow reflection · 3 min read",
    title: "Automation is only useful when it gives people better time back.",
    dek: "Scripts and automations should remove the repeat work that gets in the way, while keeping the human decisions, context, and relationships where they matter most.",
    image: "/portfolio-assets/tanu-social-gallery-02.webp",
    alt: "Editorial content study representing an automated workflow",
    takeaways: ["Automate a repeatable step, not a decision that still needs context.", "A useful workflow makes ownership and handoffs clearer rather than more hidden.", "The right automation creates room for better client work, not just faster activity."],
    sections: [
      ["Find the repeat", "The first question is simple: what is happening again and again in a way that adds little value? It may be moving data between tools, generating a routine update, preparing a file, or prompting a follow-up. Those repetitions are often a better opportunity than trying to automate an entire business process at once."],
      ["Keep the people visible", "The purpose of automation is not to make a team disappear from the workflow. It is to leave them with more space for the parts that need judgment: choosing a priority, listening to a customer, reviewing a decision, or shaping the next creative move. A good system makes that handoff clear."],
      ["Measure the relief", "A small automation can be evaluated through ordinary questions. Does it reduce repeat work? Is the result more consistent? Can someone understand the process if they did not build it? Those checks make the work practical and help decide whether the next iteration is worthwhile."],
    ],
  },
  "data-that-decides": {
    category: "Data notes",
    meta: "Reporting reflection · 4 min read",
    title: "Data visualisation should make the next decision easier to see.",
    dek: "Dashboards and reports are most useful when they help a person notice what has changed, understand why it matters, and decide what to do next without searching through a wall of numbers.",
    image: "/portfolio-assets/tanu-hero-growth-still-life.webp",
    alt: "Editorial still life representing analytical and reporting work",
    takeaways: ["A chart should answer a real operational or marketing question, not simply display available data.", "Good visualisation creates hierarchy: important shifts, useful comparisons, and a clear next action.", "Data engineering matters because trustworthy decisions need a trustworthy source structure."],
    sections: [
      ["Start with the decision", "Before selecting a chart, I would ask what the viewer needs to decide. Are they trying to see whether search visibility is improving, which content needs attention, where a process slows down, or how a campaign is performing? That decision gives the reporting view a purpose."],
      ["Give the signal a hierarchy", "A useful dashboard does not try to make every number equally loud. It uses contrast, grouping, comparison, and simple language to make the important signal visible first. Supporting detail can be available, but it should not overwhelm the person who needs to understand the situation quickly."],
      ["Build from a reliable structure", "Data visualisation is connected to the work that happens before the chart: collecting information, cleaning it, creating useful fields, and keeping the source understandable. I am building my data practice around that connection because a clean visual is only as helpful as the structure beneath it."],
    ],
  },
} as const;

export default function JournalArticle() {
  const [, params] = useRoute("/journal/:slug");
  const article = articles[params?.slug as keyof typeof articles] ?? articles["seo-foundations"];

  return (
    <div className="min-h-screen overflow-x-hidden bg-[#f7f1e8] text-[#1b1b1b]">
      <header className="border-b border-[#1b1b1b]/10 bg-[#f7f1e8]/92 backdrop-blur-xl">
        <div className="mx-auto flex h-[76px] max-w-[1440px] items-center justify-between px-5 sm:px-8 lg:px-12">
          <Link href="/" className="group flex items-center gap-3" aria-label="Tanu Singh home"><img src="/portfolio-assets/tanu-signal-mark.webp" alt="Tanu Singh signal mark" className="h-9 w-9 object-contain transition-transform duration-300 group-hover:rotate-6" /><span className="font-serif text-[1.38rem] leading-none tracking-[-0.06em]">tanu <em className="text-[#f04438]">singh</em></span></Link>
          <Link href="/journal" className="inline-flex items-center gap-2 font-manrope text-xs font-extrabold"><ArrowLeft className="h-4 w-4 text-[#f04438]" /> All notes</Link>
        </div>
      </header>

      <main>
        <section className="px-5 pb-16 pt-20 sm:px-8 sm:pt-24 lg:px-12 lg:pb-24 lg:pt-32">
          <div className="mx-auto max-w-[1120px]">
            <p className="eyebrow text-[#f04438]">{article.category} · {article.meta}</p>
            <h1 className="mt-5 max-w-[980px] font-serif text-[clamp(3.7rem,7vw,7.8rem)] leading-[0.83] tracking-[-0.075em]">{article.title}</h1>
            <p className="mt-10 max-w-[700px] border-l-2 border-[#f04438] pl-5 font-manrope text-lg leading-8 text-[#4f4a44] sm:text-xl">{article.dek}</p>
          </div>
        </section>

        <section className="px-5 pb-16 sm:px-8 lg:px-12 lg:pb-24">
          <div className="mx-auto max-w-[1120px]"><img src={article.image} alt={article.alt} className="h-[500px] w-full object-cover object-center sm:h-[680px]" /></div>
        </section>

        <article className="border-t border-[#1b1b1b]/12 px-5 py-20 sm:px-8 lg:px-12 lg:py-28">
          <div className="mx-auto grid max-w-[1120px] gap-12 lg:grid-cols-12 lg:gap-16">
            <aside className="lg:col-span-3"><p className="eyebrow">Field note</p><p className="mt-4 font-manrope text-sm leading-6 text-[#5a554f]">Written from a practical learning perspective as Tanu continues building experience across SEO and content creation.</p></aside>
            <div className="space-y-14 lg:col-span-8 lg:col-start-5">
              {article.sections.map(([heading, body], index) => (
                <section key={heading} className="article-note border-t border-[#1b1b1b]/15 pt-5"><span className="article-index">0{index + 1}</span><h2 className="mt-4 font-serif text-[clamp(2.5rem,4.5vw,4.5rem)] leading-[0.9] tracking-[-0.06em]">{heading}</h2><p className="mt-6 max-w-[650px] font-manrope text-base leading-8 text-[#4f4a44] sm:text-lg">{body}</p><p className="article-takeaway"><strong>Signal</strong> {article.takeaways[index]}</p></section>
              ))}
            </div>
          </div>
        </article>

        <section className="bg-[#1b1b1b] px-5 py-16 text-[#f7f1e8] sm:px-8 lg:px-12 lg:py-20"><div className="mx-auto flex max-w-[1120px] flex-col justify-between gap-8 sm:flex-row sm:items-center"><p className="font-serif text-4xl leading-[0.94] tracking-[-0.05em]">More notes are on the way.</p><Link href="/journal" className="inline-flex items-center gap-2 border-b border-[#f7f1e8]/50 pb-2 font-manrope text-sm font-extrabold">Explore the journal <ArrowUpRight className="h-4 w-4 text-[#f04438]" /></Link></div></section>
      </main>
    </div>
  );
}
