import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { trpc } from "@/lib/trpc";
import { Download, FileText, LayoutDashboard, Loader2, LockKeyhole, Pencil, Plus, Search, Trash2, Users } from "lucide-react";
import { FormEvent, useMemo, useState } from "react";

type AdminTab = "overview" | "leads" | "requests" | "projects" | "case-studies" | "site-details";

const tabs: Array<{ id: AdminTab; label: string }> = [
  { id: "overview", label: "Overview" },
  { id: "leads", label: "Leads" },
  { id: "requests", label: "Requests" },
  { id: "projects", label: "Projects" },
  { id: "case-studies", label: "Case studies" },
  { id: "site-details", label: "Site details" },
];

type ProjectFormState = { title: string; slug: string; category: string; summary: string; imageUrl: string; status: "draft" | "published" };
type CaseStudyFormState = { slug: string; eyebrow: string; title: string; summary: string; heroImage: string; scope: string; process: string; evidenceNote: string; status: "draft" | "published" };
const emptyProject: ProjectFormState = { title: "", slug: "", category: "", summary: "", imageUrl: "", status: "draft" };
const emptyCaseStudy: CaseStudyFormState = { slug: "", eyebrow: "", title: "", summary: "", heroImage: "", scope: "", process: "", evidenceNote: "", status: "draft" };
const emptySiteDetail = { section: "", detailKey: "", label: "", value: "" };

function toEpochEnd(value: string) {
  if (!value) return undefined;
  const date = new Date(`${value}T23:59:59.999`);
  return Number.isNaN(date.valueOf()) ? undefined : date.valueOf();
}

function toEpochStart(value: string) {
  if (!value) return undefined;
  const date = new Date(`${value}T00:00:00.000`);
  return Number.isNaN(date.valueOf()) ? undefined : date.valueOf();
}

function formatDate(value: number) {
  return new Date(value).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
}

function csvCell(value: unknown) {
  const text = String(value ?? "").replaceAll('"', '""');
  return `"${text}"`;
}

function downloadCsv(leads: Array<Record<string, unknown>>, requests: Array<Record<string, unknown>>) {
  const headers = ["record_type", "id", "created_at", "name", "email", "business", "status", "service", "stage", "goal", "budget", "timeline", "requirements"];
  const leadRows = leads.map(lead => ["lead", lead.id, lead.createdAt, lead.name, lead.email, lead.business, lead.status, "", "", "", "", "", ""]);
  const requestRows = requests.map(request => ["consultation_request", request.id, request.createdAt, request.leadName, request.leadEmail, request.business, request.status, request.service, request.stage, request.goal, request.budget, request.timeline, request.requirements]);
  const csv = [headers, ...leadRows, ...requestRows].map(row => row.map(csvCell).join(",")).join("\n");
  const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `tanu-singh-portfolio-leads-${new Date().toISOString().slice(0, 10)}.csv`;
  anchor.click();
  URL.revokeObjectURL(url);
}

function Pill({ children, tone = "neutral" }: { children: React.ReactNode; tone?: "neutral" | "coral" | "ink" }) {
  const styles = tone === "coral" ? "bg-[#f04438] text-white" : tone === "ink" ? "bg-[#1b1b1b] text-[#f7f1e8]" : "bg-[#ede5d8] text-[#5a554f]";
  return <span className={`inline-flex rounded-full px-2.5 py-1 font-manrope text-[10px] font-extrabold uppercase tracking-[0.12em] ${styles}`}>{children}</span>;
}

function EmptyState({ title, body }: { title: string; body: string }) {
  return <div className="border border-dashed border-[#1b1b1b]/20 bg-[#f7f1e8] p-8 text-center"><p className="font-serif text-2xl tracking-[-0.04em]">{title}</p><p className="mx-auto mt-3 max-w-md font-manrope text-sm leading-6 text-[#5a554f]">{body}</p></div>;
}

function AdminContent() {
  const [activeTab, setActiveTab] = useState<AdminTab>("overview");
  const [search, setSearch] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [projectForm, setProjectForm] = useState(emptyProject);
  const [projectEditId, setProjectEditId] = useState<number | null>(null);
  const [caseForm, setCaseForm] = useState(emptyCaseStudy);
  const [caseEditId, setCaseEditId] = useState<number | null>(null);
  const [detailForm, setDetailForm] = useState(emptySiteDetail);
  const [detailEditId, setDetailEditId] = useState<number | null>(null);

  const filters = useMemo(() => ({ search: search || undefined, startDate: toEpochStart(startDate), endDate: toEpochEnd(endDate) }), [search, startDate, endDate]);
  const utils = trpc.useUtils();
  const leadsQuery = trpc.admin.leads.useQuery(filters);
  const requestsQuery = trpc.admin.consultationRequests.useQuery(filters);
  const projectsQuery = trpc.admin.projects.useQuery();
  const caseStudiesQuery = trpc.admin.caseStudies.useQuery();
  const detailsQuery = trpc.admin.siteDetails.useQuery();

  const refreshLeads = () => Promise.all([utils.admin.leads.invalidate(), utils.admin.consultationRequests.invalidate()]);
  const refreshContent = () => Promise.all([utils.admin.projects.invalidate(), utils.admin.caseStudies.invalidate(), utils.admin.siteDetails.invalidate(), utils.publicContent.projects.invalidate(), utils.publicContent.caseStudies.invalidate(), utils.publicContent.siteDetails.invalidate()]);
  const updateLeadStatus = trpc.admin.updateLeadStatus.useMutation({ onSuccess: refreshLeads });
  const updateRequestStatus = trpc.admin.updateConsultationStatus.useMutation({ onSuccess: refreshLeads });
  const deleteLead = trpc.admin.deleteLead.useMutation({ onSuccess: refreshLeads });
  const deleteRequest = trpc.admin.deleteConsultationRequest.useMutation({ onSuccess: refreshLeads });
  const createProject = trpc.admin.createProject.useMutation({ onSuccess: refreshContent });
  const updateProject = trpc.admin.updateProject.useMutation({ onSuccess: refreshContent });
  const deleteProject = trpc.admin.deleteProject.useMutation({ onSuccess: refreshContent });
  const createCaseStudy = trpc.admin.createCaseStudy.useMutation({ onSuccess: refreshContent });
  const updateCaseStudy = trpc.admin.updateCaseStudy.useMutation({ onSuccess: refreshContent });
  const deleteCaseStudy = trpc.admin.deleteCaseStudy.useMutation({ onSuccess: refreshContent });
  const createDetail = trpc.admin.createSiteDetail.useMutation({ onSuccess: refreshContent });
  const updateDetail = trpc.admin.updateSiteDetail.useMutation({ onSuccess: refreshContent });
  const deleteDetail = trpc.admin.deleteSiteDetail.useMutation({ onSuccess: refreshContent });

  const leads = leadsQuery.data ?? [];
  const requests = requestsQuery.data ?? [];
  const projects = projectsQuery.data ?? [];
  const caseStudies = caseStudiesQuery.data ?? [];
  const details = detailsQuery.data ?? [];
  const isLoading = leadsQuery.isLoading || requestsQuery.isLoading || projectsQuery.isLoading || caseStudiesQuery.isLoading || detailsQuery.isLoading;

  const submitProject = async (event: FormEvent) => {
    event.preventDefault();
    if (projectEditId) await updateProject.mutateAsync({ id: projectEditId, data: projectForm }); else await createProject.mutateAsync(projectForm);
    setProjectForm(emptyProject); setProjectEditId(null);
  };
  const submitCaseStudy = async (event: FormEvent) => {
    event.preventDefault();
    if (caseEditId) await updateCaseStudy.mutateAsync({ id: caseEditId, data: caseForm }); else await createCaseStudy.mutateAsync(caseForm);
    setCaseForm(emptyCaseStudy); setCaseEditId(null);
  };
  const submitSiteDetail = async (event: FormEvent) => {
    event.preventDefault();
    if (detailEditId) await updateDetail.mutateAsync({ id: detailEditId, data: detailForm }); else await createDetail.mutateAsync(detailForm);
    setDetailForm(emptySiteDetail); setDetailEditId(null);
  };

  return <div className="min-h-full bg-[#f7f1e8] px-4 py-5 text-[#1b1b1b] sm:px-8 sm:py-8">
    <header className="border-b border-[#1b1b1b]/15 pb-6"><p className="eyebrow text-[#f04438]">Private workspace</p><div className="mt-3 flex flex-col justify-between gap-4 lg:flex-row lg:items-end"><div><h1 className="font-serif text-[clamp(2.8rem,5vw,5.5rem)] leading-[0.86] tracking-[-0.06em]">Portfolio control<br /><em className="text-[#f04438]">room.</em></h1><p className="mt-4 max-w-xl font-manrope text-sm leading-6 text-[#5a554f]">Manage incoming enquiries and the site content your visitors see. Access is protected by the local administrator session.</p></div><button onClick={() => downloadCsv(leads as unknown as Array<Record<string, unknown>>, requests as unknown as Array<Record<string, unknown>>)} className="inline-flex items-center justify-center gap-2 bg-[#1b1b1b] px-4 py-3 font-manrope text-xs font-extrabold text-white transition-transform active:scale-[0.97]"><Download className="h-4 w-4" /> Export filtered CSV</button></div></header>
    <nav className="mt-6 flex gap-2 overflow-x-auto border-b border-[#1b1b1b]/15 pb-3" aria-label="Admin dashboard sections">{tabs.map(tab => <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`shrink-0 px-3 py-2 font-manrope text-xs font-extrabold transition-colors ${activeTab === tab.id ? "bg-[#f04438] text-white" : "bg-[#ede5d8] text-[#5a554f] hover:bg-[#e4d9ca]"}`}>{tab.label}</button>)}</nav>
    <div className="mt-6 grid gap-3 sm:grid-cols-[1fr_auto_auto_auto]"><label className="flex items-center gap-2 border border-[#1b1b1b]/15 bg-white px-3"><Search className="h-4 w-4 text-[#f04438]" /><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Search name, email, business, service" className="h-11 w-full bg-transparent font-manrope text-sm outline-none" /></label><label className="font-manrope text-[10px] font-extrabold uppercase tracking-[0.1em] text-[#5a554f]">From<input type="date" value={startDate} onChange={event => setStartDate(event.target.value)} className="mt-1 block h-9 border border-[#1b1b1b]/15 bg-white px-2 text-sm normal-case tracking-normal" /></label><label className="font-manrope text-[10px] font-extrabold uppercase tracking-[0.1em] text-[#5a554f]">To<input type="date" value={endDate} onChange={event => setEndDate(event.target.value)} className="mt-1 block h-9 border border-[#1b1b1b]/15 bg-white px-2 text-sm normal-case tracking-normal" /></label><button onClick={() => { setSearch(""); setStartDate(""); setEndDate(""); }} className="self-end h-9 border border-[#1b1b1b]/20 px-3 font-manrope text-xs font-extrabold hover:border-[#f04438]">Clear</button></div>

    {isLoading ? <div className="grid min-h-[360px] place-items-center"><Loader2 className="h-8 w-8 animate-spin text-[#f04438]" /></div> : <main className="mt-8">
      {activeTab === "overview" && <div className="space-y-8"><div className="grid gap-4 md:grid-cols-3"><Stat label="Captured leads" value={leads.length} note="Filtered by the current search and dates" icon={<Users className="h-5 w-5" />} /><Stat label="Consultation requests" value={requests.length} note="Each request is paired with a project brief" icon={<FileText className="h-5 w-5" />} /><Stat label="Published case studies" value={caseStudies.filter(item => item.status === "published").length} note="Editable through the content workspace" icon={<LayoutDashboard className="h-5 w-5" />} /></div><section className="grid gap-6 lg:grid-cols-2"><Panel title="Latest leads"><LeadPreview rows={leads.slice(0, 5)} /></Panel><Panel title="Latest requests"><RequestPreview rows={requests.slice(0, 5)} /></Panel></section></div>}
      {activeTab === "leads" && <Panel title="Captured leads" subtitle="Every portfolio project brief that has been saved appears here.">{leads.length ? <div className="overflow-x-auto"><table className="min-w-full text-left"><thead className="border-b border-[#1b1b1b]/15 font-manrope text-[10px] uppercase tracking-[0.12em] text-[#5a554f]"><tr><th className="p-3">Lead</th><th className="p-3">Business</th><th className="p-3">Captured</th><th className="p-3">Status</th><th className="p-3">Actions</th></tr></thead><tbody>{leads.map(lead => <tr key={lead.id} className="border-b border-[#1b1b1b]/10 font-manrope text-sm"><td className="p-3"><b>{lead.name}</b><br /><span className="text-xs text-[#5a554f]">{lead.email}</span></td><td className="p-3">{lead.business}</td><td className="p-3 text-xs text-[#5a554f]">{formatDate(lead.createdAt)}</td><td className="p-3"><select value={lead.status} onChange={event => updateLeadStatus.mutate({ id: lead.id, status: event.target.value as "new" | "contacted" | "qualified" | "archived" })} className="border border-[#1b1b1b]/15 bg-white px-2 py-1 text-xs"><option value="new">New</option><option value="contacted">Contacted</option><option value="qualified">Qualified</option><option value="archived">Archived</option></select></td><td className="p-3"><button onClick={() => { if (window.confirm(`Delete ${lead.name} and their linked requests?`)) deleteLead.mutate({ id: lead.id }); }} className="text-[#f04438]" aria-label={`Delete ${lead.name}`}><Trash2 className="h-4 w-4" /></button></td></tr>)}</tbody></table></div> : <EmptyState title="No captured leads yet" body="New project-brief submissions will appear here once a visitor uses the consultation form." />}</Panel>}
      {activeTab === "requests" && <Panel title="Consultation requests" subtitle="Review the full brief, update its workflow status, or remove a request.">{requests.length ? <div className="space-y-4">{requests.map(request => <article key={request.id} className="border border-[#1b1b1b]/15 bg-white p-5"><div className="flex flex-col justify-between gap-4 sm:flex-row"><div><p className="eyebrow text-[#f04438]">{request.service}</p><h2 className="mt-2 font-serif text-2xl tracking-[-0.04em]">{request.leadName} <span className="font-manrope text-sm font-semibold text-[#5a554f]">· {request.business}</span></h2><p className="mt-3 max-w-2xl font-manrope text-sm leading-6 text-[#4f4a44]">{request.requirements}</p><dl className="mt-4 grid gap-3 text-xs sm:grid-cols-3"><div><dt className="font-extrabold uppercase tracking-[0.12em] text-[#5a554f]">Goal</dt><dd className="mt-1">{request.goal}</dd></div><div><dt className="font-extrabold uppercase tracking-[0.12em] text-[#5a554f]">Budget / timing</dt><dd className="mt-1">{request.budget} · {request.timeline}</dd></div><div><dt className="font-extrabold uppercase tracking-[0.12em] text-[#5a554f]">Stage</dt><dd className="mt-1">{request.stage}</dd></div></dl></div><div className="flex shrink-0 items-start gap-2"><select value={request.status} onChange={event => updateRequestStatus.mutate({ id: request.id, status: event.target.value as "new" | "reviewing" | "scheduled" | "closed" })} className="border border-[#1b1b1b]/15 bg-white px-2 py-2 text-xs"><option value="new">New</option><option value="reviewing">Reviewing</option><option value="scheduled">Scheduled</option><option value="closed">Closed</option></select><button onClick={() => { if (window.confirm("Delete this consultation request?")) deleteRequest.mutate({ id: request.id }); }} className="border border-[#f04438]/30 p-2 text-[#f04438]" aria-label="Delete request"><Trash2 className="h-4 w-4" /></button></div></div></article>)}</div> : <EmptyState title="No consultation requests yet" body="The dashboard will show detailed project briefs here after a visitor submits the contact form." />}</Panel>}
      {activeTab === "projects" && <ContentWorkspace title="Projects" description="Create, revise, publish, or remove project cards for the public portfolio."><ProjectForm form={projectForm} setForm={setProjectForm} editId={projectEditId} onSubmit={submitProject} onCancel={() => { setProjectForm(emptyProject); setProjectEditId(null); }} loading={createProject.isPending || updateProject.isPending} />{projects.length ? <div className="space-y-3">{projects.map(project => <article key={project.id} className="flex flex-col justify-between gap-3 border border-[#1b1b1b]/15 bg-white p-4 sm:flex-row sm:items-center"><div><div className="flex gap-2"><Pill tone={project.status === "published" ? "coral" : "neutral"}>{project.status}</Pill><Pill>{project.category}</Pill></div><h3 className="mt-3 font-serif text-2xl tracking-[-0.04em]">{project.title}</h3><p className="mt-1 max-w-xl font-manrope text-xs leading-5 text-[#5a554f]">{project.summary}</p></div><div className="flex gap-2"><button onClick={() => { setProjectEditId(project.id); setProjectForm({ title: project.title, slug: project.slug, category: project.category, summary: project.summary, imageUrl: project.imageUrl ?? "", status: project.status }); }} className="border border-[#1b1b1b]/20 p-2"><Pencil className="h-4 w-4" /></button><button onClick={() => { if (window.confirm(`Delete ${project.title}?`)) deleteProject.mutate({ id: project.id }); }} className="border border-[#f04438]/30 p-2 text-[#f04438]"><Trash2 className="h-4 w-4" /></button></div></article>)}</div> : <EmptyState title="No managed projects yet" body="Use the editor to add a public portfolio project when it is ready." />}</ContentWorkspace>}
      {activeTab === "case-studies" && <ContentWorkspace title="Case studies" description="Manage the case-study records that are ready to show on the public portfolio."><CaseStudyForm form={caseForm} setForm={setCaseForm} editId={caseEditId} onSubmit={submitCaseStudy} onCancel={() => { setCaseForm(emptyCaseStudy); setCaseEditId(null); }} loading={createCaseStudy.isPending || updateCaseStudy.isPending} />{caseStudies.length ? <div className="space-y-3">{caseStudies.map(study => <article key={study.id} className="flex flex-col justify-between gap-3 border border-[#1b1b1b]/15 bg-white p-4 sm:flex-row sm:items-center"><div><div className="flex gap-2"><Pill tone={study.status === "published" ? "coral" : "neutral"}>{study.status}</Pill><Pill>{study.eyebrow}</Pill></div><h3 className="mt-3 font-serif text-2xl tracking-[-0.04em]">{study.title}</h3><p className="mt-1 max-w-xl font-manrope text-xs leading-5 text-[#5a554f]">{study.summary}</p></div><div className="flex gap-2"><button onClick={() => { setCaseEditId(study.id); setCaseForm({ slug: study.slug, eyebrow: study.eyebrow, title: study.title, summary: study.summary, heroImage: study.heroImage ?? "", scope: study.scope, process: study.process, evidenceNote: study.evidenceNote, status: study.status }); }} className="border border-[#1b1b1b]/20 p-2"><Pencil className="h-4 w-4" /></button><button onClick={() => { if (window.confirm(`Delete ${study.title}?`)) deleteCaseStudy.mutate({ id: study.id }); }} className="border border-[#f04438]/30 p-2 text-[#f04438]"><Trash2 className="h-4 w-4" /></button></div></article>)}</div> : <EmptyState title="No managed case studies yet" body="Add a case study here when you are ready to publish a new project narrative." />}</ContentWorkspace>}
      {activeTab === "site-details" && <ContentWorkspace title="Site details" description="Manage individual content details such as contact information, headlines, or service notes."><SiteDetailForm form={detailForm} setForm={setDetailForm} editId={detailEditId} onSubmit={submitSiteDetail} onCancel={() => { setDetailForm(emptySiteDetail); setDetailEditId(null); }} loading={createDetail.isPending || updateDetail.isPending} />{details.length ? <div className="space-y-3">{details.map(detail => <article key={detail.id} className="flex flex-col justify-between gap-3 border border-[#1b1b1b]/15 bg-white p-4 sm:flex-row sm:items-center"><div><Pill>{detail.section}</Pill><h3 className="mt-3 font-serif text-xl tracking-[-0.04em]">{detail.label}</h3><p className="mt-1 max-w-xl font-manrope text-xs leading-5 text-[#5a554f]">{detail.value}</p></div><div className="flex gap-2"><button onClick={() => { setDetailEditId(detail.id); setDetailForm({ section: detail.section, detailKey: detail.detailKey, label: detail.label, value: detail.value }); }} className="border border-[#1b1b1b]/20 p-2"><Pencil className="h-4 w-4" /></button><button onClick={() => { if (window.confirm(`Delete ${detail.label}?`)) deleteDetail.mutate({ id: detail.id }); }} className="border border-[#f04438]/30 p-2 text-[#f04438]"><Trash2 className="h-4 w-4" /></button></div></article>)}</div> : <EmptyState title="No managed site details yet" body="Add an individual site detail when you want it ready for controlled public content use." />}</ContentWorkspace>}
    </main>}
  </div>;
}

function Stat({ label, value, note, icon }: { label: string; value: number; note: string; icon: React.ReactNode }) { return <article className="border border-[#1b1b1b]/15 bg-white p-5"><div className="flex items-center justify-between text-[#f04438]">{icon}<span className="font-manrope text-[10px] font-extrabold uppercase tracking-[0.12em]">Live data</span></div><p className="mt-9 font-serif text-5xl tracking-[-0.07em]">{value}</p><h2 className="mt-2 font-manrope text-sm font-extrabold">{label}</h2><p className="mt-2 font-manrope text-xs leading-5 text-[#5a554f]">{note}</p></article>; }
function Panel({ title, subtitle, children }: { title: string; subtitle?: string; children: React.ReactNode }) { return <section className="border border-[#1b1b1b]/15 bg-[#ede5d8] p-5 sm:p-6"><div className="mb-5 flex flex-col gap-2 border-b border-[#1b1b1b]/15 pb-4"><h2 className="font-serif text-3xl tracking-[-0.05em]">{title}</h2>{subtitle && <p className="font-manrope text-xs leading-5 text-[#5a554f]">{subtitle}</p>}</div>{children}</section>; }
function LeadPreview({ rows }: { rows: Array<{ id: number; name: string; email: string; business: string; createdAt: number; status: string }> }) { return rows.length ? <div className="space-y-3">{rows.map(row => <div key={row.id} className="flex items-center justify-between gap-4 border-b border-[#1b1b1b]/10 pb-3"><div><p className="font-manrope text-sm font-extrabold">{row.name}</p><p className="font-manrope text-xs text-[#5a554f]">{row.business} · {row.email}</p></div><Pill>{row.status}</Pill></div>)}</div> : <EmptyState title="No leads yet" body="Captured project briefs will appear here." />; }
function RequestPreview({ rows }: { rows: Array<{ id: number; leadName: string; service: string; createdAt: number; status: string }> }) { return rows.length ? <div className="space-y-3">{rows.map(row => <div key={row.id} className="flex items-center justify-between gap-4 border-b border-[#1b1b1b]/10 pb-3"><div><p className="font-manrope text-sm font-extrabold">{row.leadName}</p><p className="font-manrope text-xs text-[#5a554f]">{row.service} · {formatDate(row.createdAt)}</p></div><Pill tone="coral">{row.status}</Pill></div>)}</div> : <EmptyState title="No requests yet" body="Detailed consultation requests will appear here." />; }
function ContentWorkspace({ title, description, children }: { title: string; description: string; children: React.ReactNode }) { return <div className="grid gap-6 xl:grid-cols-[minmax(300px,0.8fr)_minmax(0,1.2fr)]"><section className="bg-[#1b1b1b] p-5 text-[#f7f1e8] sm:p-7"><p className="eyebrow text-[#f04438]">Content control</p><h2 className="mt-3 font-serif text-4xl leading-[0.9] tracking-[-0.06em]">{title}</h2><p className="mt-4 font-manrope text-sm leading-6 text-[#d6cec2]">{description}</p><p className="mt-8 border-t border-white/20 pt-5 font-manrope text-xs leading-5 text-[#d6cec2]">Draft records remain private. Publish a record only when its copy, images, evidence note, and URLs are ready for the public portfolio.</p></section><section className="space-y-3">{children}</section></div>; }
function Field({ label, children, wide }: { label: string; children: React.ReactNode; wide?: boolean }) { return <label className={`block font-manrope text-[10px] font-extrabold uppercase tracking-[0.1em] text-[#5a554f] ${wide ? "sm:col-span-2" : ""}`}><span>{label}</span>{children}</label>; }
const inputClass = "mt-2 h-10 w-full border border-[#1b1b1b]/20 bg-white px-3 font-manrope text-sm font-semibold text-[#1b1b1b] outline-none focus:border-[#f04438]";
const textareaClass = "mt-2 min-h-24 w-full border border-[#1b1b1b]/20 bg-white p-3 font-manrope text-sm font-semibold text-[#1b1b1b] outline-none focus:border-[#f04438]";
function FormActions({ editId, onCancel, loading }: { editId: number | null; onCancel: () => void; loading: boolean }) { return <div className="mt-5 flex gap-3"><button type="submit" disabled={loading} className="inline-flex items-center gap-2 bg-[#f04438] px-4 py-3 font-manrope text-xs font-extrabold text-white disabled:opacity-50"><Plus className="h-4 w-4" />{editId ? "Save changes" : "Add record"}</button>{editId && <button type="button" onClick={onCancel} className="border border-[#1b1b1b]/30 px-4 py-3 font-manrope text-xs font-extrabold">Cancel</button>}</div>; }
function ProjectForm({ form, setForm, editId, onSubmit, onCancel, loading }: { form: ProjectFormState; setForm: (value: ProjectFormState) => void; editId: number | null; onSubmit: (event: FormEvent) => void; onCancel: () => void; loading: boolean }) { return <form onSubmit={onSubmit} className="grid gap-4 sm:grid-cols-2"><Field label="Title" wide><input required value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} className={inputClass} /></Field><Field label="Slug"><input required value={form.slug} onChange={e => setForm({ ...form, slug: e.target.value })} className={inputClass} /></Field><Field label="Category"><input required value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className={inputClass} /></Field><Field label="Image URL" wide><input value={form.imageUrl} onChange={e => setForm({ ...form, imageUrl: e.target.value })} className={inputClass} /></Field><Field label="Summary" wide><textarea required value={form.summary} onChange={e => setForm({ ...form, summary: e.target.value })} className={textareaClass} /></Field><Field label="Visibility" wide><select value={form.status} onChange={e => setForm({ ...form, status: e.target.value as "draft" | "published" })} className={inputClass}><option value="draft">Draft</option><option value="published">Published</option></select></Field><div className="sm:col-span-2"><FormActions editId={editId} onCancel={onCancel} loading={loading} /></div></form>; }
function CaseStudyForm({ form, setForm, editId, onSubmit, onCancel, loading }: { form: CaseStudyFormState; setForm: (value: CaseStudyFormState) => void; editId: number | null; onSubmit: (event: FormEvent) => void; onCancel: () => void; loading: boolean }) { return <form onSubmit={onSubmit} className="grid gap-4 sm:grid-cols-2"><Field label="Title" wide><input required value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} className={inputClass} /></Field><Field label="Slug"><input required value={form.slug} onChange={e => setForm({ ...form, slug: e.target.value })} className={inputClass} /></Field><Field label="Eyebrow"><input required value={form.eyebrow} onChange={e => setForm({ ...form, eyebrow: e.target.value })} className={inputClass} /></Field><Field label="Hero image URL" wide><input value={form.heroImage} onChange={e => setForm({ ...form, heroImage: e.target.value })} className={inputClass} /></Field><Field label="Summary" wide><textarea required value={form.summary} onChange={e => setForm({ ...form, summary: e.target.value })} className={textareaClass} /></Field><Field label="Scope (one item per line)" wide><textarea required value={form.scope} onChange={e => setForm({ ...form, scope: e.target.value })} className={textareaClass} /></Field><Field label="Process (stored content)" wide><textarea required value={form.process} onChange={e => setForm({ ...form, process: e.target.value })} className={textareaClass} /></Field><Field label="Evidence note" wide><textarea required value={form.evidenceNote} onChange={e => setForm({ ...form, evidenceNote: e.target.value })} className={textareaClass} /></Field><Field label="Visibility" wide><select value={form.status} onChange={e => setForm({ ...form, status: e.target.value as "draft" | "published" })} className={inputClass}><option value="draft">Draft</option><option value="published">Published</option></select></Field><div className="sm:col-span-2"><FormActions editId={editId} onCancel={onCancel} loading={loading} /></div></form>; }
function SiteDetailForm({ form, setForm, editId, onSubmit, onCancel, loading }: { form: typeof emptySiteDetail; setForm: (value: typeof emptySiteDetail) => void; editId: number | null; onSubmit: (event: FormEvent) => void; onCancel: () => void; loading: boolean }) { return <form onSubmit={onSubmit} className="grid gap-4 sm:grid-cols-2"><Field label="Section"><input required value={form.section} onChange={e => setForm({ ...form, section: e.target.value })} className={inputClass} /></Field><Field label="Key"><input required value={form.detailKey} onChange={e => setForm({ ...form, detailKey: e.target.value })} className={inputClass} /></Field><Field label="Label" wide><input required value={form.label} onChange={e => setForm({ ...form, label: e.target.value })} className={inputClass} /></Field><Field label="Value" wide><textarea required value={form.value} onChange={e => setForm({ ...form, value: e.target.value })} className={textareaClass} /></Field><div className="sm:col-span-2"><FormActions editId={editId} onCancel={onCancel} loading={loading} /></div></form>; }

export default function AdminDashboard() {
  const { user, loading } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const localLogin = trpc.localAdmin.login.useMutation({
    onSuccess: () => window.location.reload(),
    onError: () => setLoginError("Those administrator credentials were not recognised. Please try again."),
  });
  const submitLocalLogin = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setLoginError("");
    localLogin.mutate({ username, password });
  };
  if (loading) return <div className="grid min-h-screen place-items-center bg-[#f7f1e8]"><Loader2 className="h-8 w-8 animate-spin text-[#f04438]" /></div>;
  if (!user) return <div className="grid min-h-screen bg-[#f7f1e8] lg:grid-cols-[1.1fr_0.9fr]"><section className="relative hidden overflow-hidden bg-[#1b1b1b] p-12 text-[#f7f1e8] lg:flex lg:flex-col lg:justify-between"><div><p className="eyebrow text-[#f04438]">Tanu Singh / secure workspace</p><h1 className="mt-6 max-w-xl font-serif text-[clamp(4rem,6vw,7.2rem)] leading-[0.82] tracking-[-0.07em]">Control the work<br /><em className="text-[#f04438]">behind the signal.</em></h1></div><p className="max-w-sm border-l border-[#f04438] pl-5 font-manrope text-sm leading-7 text-[#d6cec2]">This private workspace is for managing leads, client briefs, projects, case studies, and the content shown on the public portfolio.</p></section><main className="grid place-items-center p-5 sm:p-10"><div className="w-full max-w-md"><a href="/" className="inline-flex items-center gap-3 font-serif text-2xl tracking-[-0.05em]">tanu <em className="text-[#f04438]">singh</em></a><p className="eyebrow mt-14 text-[#f04438]">Administrator access</p><h2 className="mt-4 font-serif text-5xl leading-[0.88] tracking-[-0.06em]">Welcome back.</h2><p className="mt-5 font-manrope text-sm leading-6 text-[#5a554f]">Sign in with the local administrator credentials to open the portfolio control room.</p><form onSubmit={submitLocalLogin} className="mt-9 space-y-5"><label className="block font-manrope text-[10px] font-extrabold uppercase tracking-[0.13em] text-[#5a554f]">Username<input value={username} onChange={event => setUsername(event.target.value)} autoComplete="username" required className="mt-2 h-12 w-full border border-[#1b1b1b]/20 bg-white px-3 font-manrope text-sm outline-none focus:border-[#f04438]" /></label><label className="block font-manrope text-[10px] font-extrabold uppercase tracking-[0.13em] text-[#5a554f]">Password<input value={password} onChange={event => setPassword(event.target.value)} type="password" autoComplete="current-password" required className="mt-2 h-12 w-full border border-[#1b1b1b]/20 bg-white px-3 font-manrope text-sm outline-none focus:border-[#f04438]" /></label>{loginError && <p role="alert" className="font-manrope text-xs font-semibold text-[#c93a30]">{loginError}</p>}<button type="submit" disabled={localLogin.isPending} className="flex w-full items-center justify-center gap-2 bg-[#f04438] px-4 py-3.5 font-manrope text-xs font-extrabold text-white transition-transform active:scale-[0.97] disabled:opacity-60">{localLogin.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <LockKeyhole className="h-4 w-4" />}{localLogin.isPending ? "Signing in…" : "Open control room"}</button></form></div></main></div>;
  if (user.role !== "admin") return <DashboardLayout><div className="grid min-h-[65vh] place-items-center bg-[#f7f1e8] p-6"><div className="max-w-lg border border-[#1b1b1b]/15 bg-white p-8 text-center"><LockKeyhole className="mx-auto h-8 w-8 text-[#f04438]" /><h1 className="mt-5 font-serif text-4xl tracking-[-0.05em]">Admin access only.</h1><p className="mt-4 font-manrope text-sm leading-6 text-[#5a554f]">This workspace is restricted to the local portfolio administrator session.</p></div></div></DashboardLayout>;
  return <DashboardLayout><AdminContent /></DashboardLayout>;
}
