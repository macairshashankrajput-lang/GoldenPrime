/**
 * DESIGN REMINDER — Signal & Story:
 * Journal pages retain the portfolio's warm editorial rhythm, ink-and-coral signals, and personal imagery.
 * Keep the writing specific, reflective, and honest about Tanu's practical learning journey.
 */
import { ArrowDownRight, ArrowUpRight, BookOpen } from "lucide-react";
import { Link } from "wouter";

const articles = [
  {
    slug: "seo-foundations",
    category: "SEO notes",
    readTime: "4 min read",
    title: "What an SEO project taught me about starting with intent.",
    excerpt: "A practical reflection on moving from a keyword list to a more useful question: what is a person actually trying to find?",
    image: "/portfolio-assets/tanu-seo-signal-collage.webp",
    alt: "Annotated editorial collage representing SEO research and search intent",
  },
  {
    slug: "social-content",
    category: "Content notes",
    readTime: "3 min read",
    title: "A simple lens for making social posts feel more considered.",
    excerpt: "A short working framework for turning a broad idea into a post with a clearer purpose, message, and visual rhythm.",
    image: "/portfolio-assets/tanu-social-gallery-02.webp",
    alt: "Editorial social content concept with layered visual hierarchy",
  },
  {
    slug: "practice-notes",
    category: "Practice notes",
    readTime: "2 min read",
    title: "Why staying curious is a useful marketing skill.",
    excerpt: "The small habit of asking why something works—and what could make it more useful—has shaped how I learn digital marketing.",
    image: "/portfolio-assets/tanu-social-content-collage.webp",
    alt: "Tanu Singh in a bright floral streetscape",
  },
  {
    slug: "building-a-client-demo",
    category: "Build notes",
    readTime: "3 min read",
    title: "What a client demo website taught me about keeping the workflow clear.",
    excerpt: "A reflection on the GlobeFares demo project and how design, deployment, and version control can support a more practical web-building process.",
    image: "/portfolio-assets/tanu-hero-growth-still-life.webp",
    alt: "Editorial still life representing a focused digital project workflow",
  },
  {
    slug: "toolkit-with-intent",
    category: "Tool notes",
    readTime: "3 min read",
    title: "A marketing toolkit works best when each tool has a clear job.",
    excerpt: "How I think about using tools such as WordPress, Rank Math, Canva, CapCut, Google Ads, and Google Workspace without letting the toolkit lead the strategy.",
    image: "/portfolio-assets/tanu-social-gallery-01.webp",
    alt: "Editorial social content study in coral and ink",
  },
  {
    slug: "from-brief-to-blueprint",
    category: "Freelance notes",
    readTime: "4 min read",
    title: "From a rough brief to a digital blueprint: start where the friction is.",
    excerpt: "An end-to-end project does not need to begin with a huge plan. It begins by making the business problem visible, then choosing the next useful build, campaign, workflow, or data step.",
    image: "/portfolio-assets/tanu-social-gallery-03.webp",
    alt: "Editorial content study representing an organised digital blueprint",
  },
  {
    slug: "automation-with-a-purpose",
    category: "Automation notes",
    readTime: "3 min read",
    title: "Automation is only useful when it gives people better time back.",
    excerpt: "A practical reflection on treating scripts and workflow automations as ways to reduce repeat work, clarify handoffs, and leave more room for the decisions that need a person.",
    image: "/portfolio-assets/tanu-social-gallery-02.webp",
    alt: "Editorial content study representing an automated workflow",
  },
  {
    slug: "data-that-decides",
    category: "Data notes",
    readTime: "4 min read",
    title: "Data visualisation should make the next decision easier to see.",
    excerpt: "A good dashboard is not a wall of numbers. It gives a team a clearer view of what is changing, what needs attention, and what should happen next.",
    image: "/portfolio-assets/tanu-hero-growth-still-life.webp",
    alt: "Editorial still life representing analytical and reporting work",
  },
];

export default function Journal() {
  return (
    <div className="min-h-screen overflow-x-hidden bg-[#f7f1e8] text-[#1b1b1b]">
      <header className="border-b border-[#1b1b1b]/10 bg-[#f7f1e8]/92 backdrop-blur-xl">
        <div className="mx-auto flex h-[76px] max-w-[1440px] items-center justify-between px-5 sm:px-8 lg:px-12">
          <Link href="/" className="group flex items-center gap-3" aria-label="Back to Tanu Singh home">
            <img src="/portfolio-assets/tanu-signal-mark.webp" alt="Tanu Singh signal mark" className="h-9 w-9 object-contain transition-transform duration-300 group-hover:rotate-6" />
            <span className="font-serif text-[1.38rem] leading-none tracking-[-0.06em]">tanu <em className="text-[#f04438]">singh</em></span>
          </Link>
          <Link href="/" className="inline-flex items-center gap-2 font-manrope text-xs font-extrabold text-[#1b1b1b]">Back to portfolio <ArrowUpRight className="h-4 w-4 text-[#f04438]" /></Link>
        </div>
      </header>

      <main>
        <section className="relative overflow-hidden border-b border-[#1b1b1b]/10 px-5 py-20 sm:px-8 lg:px-12 lg:py-28">
          <div className="hero-grain pointer-events-none absolute inset-0" />
          <div className="relative mx-auto grid max-w-[1440px] gap-12 lg:grid-cols-12 lg:items-end">
            <div className="lg:col-span-7">
              <p className="eyebrow">The field journal</p>
              <h1 className="mt-5 max-w-[770px] font-serif text-[clamp(4rem,9vw,9rem)] leading-[0.81] tracking-[-0.078em]">Notes from a<br /><em className="text-[#f04438]">marketing practice</em><span className="text-[#f04438]">.</span></h1>
            </div>
            <div className="border-l-2 border-[#f04438] pl-5 lg:col-span-3 lg:col-start-10">
              <p className="font-manrope text-base leading-7 text-[#4f4a44]">Short, honest reflections on what I am learning through SEO, social content, and hands-on project work.</p>
            </div>
          </div>
        </section>

        <section className="bg-[#1b1b1b] px-5 py-6 text-[#f7f1e8] sm:px-8 lg:px-12">
          <div className="mx-auto flex max-w-[1440px] items-center gap-4 font-manrope text-[10px] font-extrabold uppercase tracking-[0.16em]"><BookOpen className="h-4 w-4 text-[#f04438]" /> Learning in public · Search, content, and creative momentum</div>
        </section>

        <section className="px-5 py-20 sm:px-8 lg:px-12 lg:py-32">
          <div className="mx-auto max-w-[1440px]">
            <div className="mb-12 flex items-center justify-between border-b border-[#1b1b1b]/15 pb-5 lg:mb-16"><p className="eyebrow">Latest notes</p><p className="font-manrope text-xs font-bold text-[#5a554f]">08 entries</p></div>
            <div className="grid gap-10 lg:grid-cols-3 lg:gap-12">
              {articles.map((article, index) => (
                <Link key={article.slug} href={`/journal/${article.slug}`} className={`journal-teaser group ${index === 0 ? "lg:mt-12" : index === 2 ? "lg:mt-24" : ""}`}>
                  <img src={article.image} alt={article.alt} className="aspect-[4/5] w-full object-cover" />
                  <div className="mt-5 border-t border-[#1b1b1b]/15 pt-4">
                    <p className="eyebrow text-[#f04438]">{article.category} · {article.readTime}</p>
                    <h2 className="mt-3 font-serif text-[2.1rem] leading-[0.94] tracking-[-0.05em]">{article.title}</h2>
                    <p className="mt-4 font-manrope text-sm leading-6 text-[#5a554f]">{article.excerpt}</p>
                    <span className="mt-6 inline-flex items-center gap-2 font-manrope text-xs font-extrabold">Read entry <ArrowDownRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" /></span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        <section className="bg-[#f04438] px-5 py-16 text-white sm:px-8 lg:px-12 lg:py-20">
          <div className="mx-auto grid max-w-[1440px] gap-8 lg:grid-cols-12 lg:items-center">
            <p className="font-serif text-[clamp(2.8rem,5vw,5.4rem)] leading-[0.9] tracking-[-0.06em] lg:col-span-8">Have a project that needs a little more direction?</p>
            <Link href="/#contact" className="inline-flex items-center gap-3 border-b border-white/70 pb-2 font-manrope text-sm font-extrabold lg:col-span-2 lg:col-start-11">Start a conversation <ArrowUpRight className="h-4 w-4" /></Link>
          </div>
        </section>
      </main>
    </div>
  );
}
