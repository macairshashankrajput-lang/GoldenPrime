/**
 * DESIGN REMINDER — Signal & Story:
 * Contemporary editorial portfolio; use ink, paper cream, and signal coral with intentional asymmetry.
 * Every element should clarify proof, process, or a route to collaborate.
 */
import {
  ArrowDownRight,
  ArrowUpRight,
  BarChart3,
  BookOpen,
  Bot,
  Check,
  Code2,
  Compass,
  Database,
  Menu,
  Megaphone,
  Search,
  Sparkles,
  Workflow,
  X,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState, type FormEvent } from "react";

const navItems = [
  { label: "Services", href: "#services" },
  { label: "Case studies", href: "/case-studies" },
  { label: "Gallery", href: "#gallery" },
  { label: "Capabilities", href: "#capabilities" },
  { label: "About", href: "#about" },
  { label: "Journal", href: "/journal" },
];

const strengths = [
  {
    number: "01",
    title: "Research first",
    text: "Start with the audience, the business friction, and the information a decision-maker actually needs next.",
    icon: Search,
  },
  {
    number: "02",
    title: "Build with purpose",
    text: "Shape marketing, websites, systems, and content around a clear action—not a decorative deliverable.",
    icon: Sparkles,
  },
  {
    number: "03",
    title: "Improve in the open",
    text: "Use practical feedback, evidence, and iteration to turn an initial release into a stronger next version.",
    icon: Compass,
  },
];

const seoFocus = [
  "Keyword research and search intent",
  "On-page optimisation principles",
  "Content relevance and page structure",
  "Foundational SEO review and learning",
];

const socialProcess = [
  ["01", "Listen", "Start with the brand, audience, and content opportunity."],
  ["02", "Shape", "Turn an idea into a focused post concept with a clear message."],
  ["03", "Refine", "Balance visual rhythm, relevance, and an action worth taking."],
];

const freelanceServices = [
  { number: "01", title: "Digital foundations", text: "Map the business need, shape the online presence, and create a practical roadmap from first idea to next release.", icon: Compass },
  { number: "02", title: "Marketing & SEO", text: "Build clearer discoverability through SEO, search intent, content direction, social media, and campaign-ready messaging.", icon: Megaphone },
  { number: "03", title: "Websites & applications", text: "Create focused websites, client demos, and business-facing application experiences around the people who will use them.", icon: Code2 },
  { number: "04", title: "Automation & scripts", text: "Reduce repeat work with useful automations, lightweight scripts, and connected workflows that keep work moving.", icon: Bot },
  { number: "05", title: "Data engineering", text: "Bring scattered data into a clearer, more usable structure so teams can make better decisions from it.", icon: Database },
  { number: "06", title: "Data visualisation", text: "Turn complex information into readable dashboards and visual stories that reveal what needs attention next.", icon: BarChart3 },
];

export default function Home() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [formStatus, setFormStatus] = useState("");
  const consultationMutation = trpc.consultation.submit.useMutation();
  const { data: managedProjects = [] } = trpc.publicContent.projects.useQuery();
  const { data: managedSiteDetails = [] } = trpc.publicContent.siteDetails.useQuery();
  const siteDetail = (key: string, fallback: string) => managedSiteDetails.find(detail => detail.detailKey === key)?.value || fallback;
  const contactHeadline = siteDetail("contact-headline", "Let’s give your next idea a stronger signal.");
  const contactIntro = siteDetail("contact-intro", "Looking for support with foundational SEO or thoughtful social content? I’d love to hear what you’re working on.");
  const contactEmail = siteDetail("contact-email", "seo.tanusingh@gmail.com");

  const closeMenu = () => setIsMenuOpen(false);

  const handleContactSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const clientName = String(formData.get("clientName") || "");
    const email = String(formData.get("email") || "");
    const business = String(formData.get("business") || "");
    const service = String(formData.get("service") || "");
    const stage = String(formData.get("stage") || "");
    const goal = String(formData.get("goal") || "");
    const budget = String(formData.get("budget") || "");
    const timeline = String(formData.get("timeline") || "");
    const requirements = String(formData.get("requirements") || "");
    const subject = encodeURIComponent(`Project brief from ${clientName}: ${service}`);
    const body = encodeURIComponent(`Name: ${clientName}\nEmail: ${email}\nBusiness / project: ${business}\nService needed: ${service}\nCurrent stage: ${stage}\nPrimary goal: ${goal}\nBudget range: ${budget}\nPreferred timeline: ${timeline}\n\nProject requirements:\n${requirements}`);

    try {
      await consultationMutation.mutateAsync({
        name: clientName,
        email,
        business,
        service,
        stage,
        goal,
        budget,
        timeline,
        requirements,
        website: "",
      });
      setFormStatus("Your enquiry was recorded. Opening your default email app with the project brief filled in.");
    } catch {
      setFormStatus("Opening your default email app with the project brief filled in. You can still send it directly.");
    }
    window.location.href = `mailto:${contactEmail}?subject=${subject}&body=${body}`;
  };

  return (
    <div className="site-shell overflow-x-hidden bg-[#f7f1e8] text-[#1b1b1b]">
      <header className="fixed inset-x-0 top-0 z-50 border-b border-[#1b1b1b]/10 bg-[#f7f1e8]/92 backdrop-blur-xl">
        <div className="mx-auto flex h-[76px] max-w-[1440px] items-center justify-between px-5 sm:px-8 lg:px-12">
          <a href="#top" className="group flex items-center gap-3" aria-label="Tanu Singh home">
            <img
              src="/portfolio-assets/tanu-signal-mark.webp"
              alt="Tanu Singh signal mark"
              className="h-9 w-9 object-contain transition-transform duration-300 group-hover:rotate-6"
            />
            <span className="font-serif text-[1.38rem] leading-none tracking-[-0.06em] text-[#1b1b1b]">tanu <em className="text-[#f04438]">singh</em></span>
          </a>

          <nav className="hidden items-center gap-8 lg:flex" aria-label="Primary navigation">
            {navItems.map((item) => (
              <a key={item.href} href={item.href} className="nav-link">
                {item.label}
              </a>
            ))}
          </nav>

          <a href="#contact" className="hidden items-center gap-2 text-sm font-extrabold text-[#1b1b1b] lg:flex">
            Let&apos;s talk <ArrowUpRight className="h-4 w-4 text-[#f04438]" />
          </a>

          <button
            type="button"
            aria-label={isMenuOpen ? "Close navigation" : "Open navigation"}
            aria-expanded={isMenuOpen}
            onClick={() => setIsMenuOpen((open) => !open)}
            className="grid h-10 w-10 place-items-center rounded-full border border-[#1b1b1b]/15 transition-colors hover:border-[#f04438] hover:text-[#f04438] lg:hidden"
          >
            {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {isMenuOpen && (
          <nav className="border-t border-[#1b1b1b]/10 bg-[#f7f1e8] px-5 py-5 shadow-[0_16px_30px_rgba(39,33,26,0.1)] lg:hidden" aria-label="Mobile navigation">
            <div className="mx-auto flex max-w-[1440px] flex-col gap-4 px-0 sm:px-3">
              {navItems.map((item) => (
                <a key={item.href} href={item.href} onClick={closeMenu} className="font-serif text-3xl leading-none">
                  {item.label}
                </a>
              ))}
              <a href="#contact" onClick={closeMenu} className="mt-2 inline-flex items-center gap-2 text-sm font-extrabold text-[#f04438]">
                Let&apos;s talk <ArrowUpRight className="h-4 w-4" />
              </a>
            </div>
          </nav>
        )}
      </header>

      <main id="top">
        <section className="relative min-h-[810px] overflow-hidden border-b border-[#1b1b1b]/10 pt-[76px] lg:min-h-[860px]">
          <div className="hero-grain pointer-events-none absolute inset-0" />
          <div className="relative mx-auto grid min-h-[734px] max-w-[1440px] grid-cols-1 lg:min-h-[784px] lg:grid-cols-12">
            <div className="relative z-10 flex flex-col justify-between px-5 pb-12 pt-16 sm:px-8 sm:pt-24 lg:col-span-7 lg:px-12 lg:pb-16 lg:pt-28">
              <div className="rise-in flex items-center gap-3 text-[10px] font-extrabold uppercase tracking-[0.22em] text-[#59544d]">
                <span className="h-2 w-2 rounded-full bg-[#f04438]" />
                Independent digital practice · 2026
              </div>

              <div className="relative mt-12 max-w-[770px] lg:mt-0">
                <p className="rise-in-delayed mb-5 font-manrope text-sm font-bold uppercase tracking-[0.19em] text-[#f04438] sm:text-base">
                  Strategy · build · automation · data
                </p>
                <h1 className="display-title rise-in-long text-[clamp(4.3rem,9.3vw,9.7rem)] leading-[0.82] tracking-[-0.075em] text-[#1b1b1b]">
                  Make your next
                  <span className="relative ml-[0.07em] inline-block text-[#f04438]">
                    search
                    <svg className="absolute -bottom-3 left-0 w-full" viewBox="0 0 292 20" fill="none" aria-hidden="true">
                      <path d="M3 15.8C69.7 4.4 157.9 4.7 289 12" stroke="currentColor" strokeWidth="5.5" strokeLinecap="round" />
                    </svg>
                  </span>
                  <br />
                  <span className="ml-[0.25em]">and system—</span>
                  <br />
                  count.
                </h1>
              </div>

              <div className="rise-in-long flex flex-col items-start gap-7 sm:flex-row sm:items-end sm:justify-between">
                <p className="max-w-[340px] font-manrope text-base leading-7 text-[#4f4a44]">
                  I&apos;m <strong className="font-extrabold text-[#1b1b1b]">Tanu Singh</strong>, a freelance digital practitioner who helps businesses turn scattered ideas into useful marketing, web, workflow, and data foundations.
                </p>
                <a href="/case-studies" className="cta-button group">
                  Explore case studies
                  <span className="grid h-7 w-7 place-items-center rounded-full bg-[#1b1b1b] text-[#f7f1e8] transition-transform duration-300 group-hover:translate-x-1">
                    <ArrowDownRight className="h-4 w-4" />
                  </span>
                </a>
              </div>
            </div>

            <div className="relative min-h-[340px] overflow-hidden border-t border-[#1b1b1b]/10 lg:col-span-5 lg:min-h-0 lg:border-l lg:border-t-0">
              <img
                src="/portfolio-assets/tanu-social-content-collage.webp"
                alt="Tanu Singh seated in a creator-focused editorial portrait"
                className="h-full w-full object-cover object-[54%_center]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#1b1b1b]/25 via-transparent to-transparent" />
              <div className="absolute bottom-5 right-5 flex items-center gap-3 bg-[#f7f1e8]/95 px-4 py-3 font-manrope text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#1b1b1b] backdrop-blur-sm sm:bottom-8 sm:right-8">
                <span className="h-2 w-2 rounded-full bg-[#f04438]" />
                Practical, end to end
              </div>
            </div>
          </div>

          <div className="absolute bottom-0 left-5 hidden items-center gap-3 pb-6 font-manrope text-[10px] font-bold uppercase tracking-[0.17em] text-[#625d55] sm:left-8 lg:flex lg:left-12">
            Scroll to explore <span className="inline-block h-px w-12 bg-[#625d55]" />
          </div>
        </section>

        <section className="border-b border-[#1b1b1b]/10 bg-[#1b1b1b] px-5 py-6 text-[#f7f1e8] sm:px-8 lg:px-12">
          <div className="ticker-track mx-auto flex max-w-[1440px] items-center justify-between gap-6 overflow-hidden whitespace-nowrap font-manrope text-[11px] font-extrabold uppercase tracking-[0.16em] sm:text-xs">
            <span>Strategy before stack</span><span className="text-[#f04438]">✦</span><span>Builds that move work forward</span><span className="text-[#f04438]">✦</span><span>Systems with a human centre</span><span className="text-[#f04438]">✦</span><span>Evidence before claims</span>
          </div>
        </section>

        <section className="dashboard-strip border-b border-[#1b1b1b]/10 bg-[#ede5d8] py-8 sm:py-10">
          <div className="mx-auto flex max-w-[1440px] items-end justify-between gap-6 px-5 sm:px-8 lg:px-12">
            <div><p className="eyebrow">Practice dashboard</p><h2 className="mt-2 font-serif text-3xl tracking-[-0.05em] sm:text-4xl">A working view of the portfolio.</h2></div>
            <p className="hidden font-manrope text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#5a554f] sm:block">Swipe / scroll to explore →</p>
          </div>
          <div className="dashboard-scroll mt-7 flex gap-4 overflow-x-auto px-5 pb-2 sm:px-8 lg:px-12">
            <article className="dashboard-card dashboard-card-signal"><p className="eyebrow text-white/80">Current practice</p><h3>Digital systems</h3><p>Marketing, build, automation, and data work connected around a practical business need.</p><span>01</span></article>
            <article className="dashboard-card"><p className="eyebrow">SEO learning lab</p><h3>V-Trims Design</h3><p>Keyword research, intent mapping, and page-structure thinking applied to a real-world SEO brief.</p><span>02</span></article>
            <article className="dashboard-card"><p className="eyebrow">Website workflow</p><h3>GlobeFares</h3><p>Client demo website practice using Vercel, GitHub, and Canva to move from idea to shareable build.</p><span>03</span></article>
            <article className="dashboard-card"><p className="eyebrow">Operating toolkit</p><h3>Search to systems</h3><p>WordPress · Rank Math · Canva · Google Ads · CapCut · Google Workspace</p><span>04</span></article>
            <article className="dashboard-card"><p className="eyebrow">Working principle</p><h3>Map · build · evolve</h3><p>Look for the friction, make the clearest improvement, then learn from the next release.</p><span>05</span></article>
          </div>
        </section>

        <section className="section-rule bg-[#f7f1e8] px-5 py-16 sm:px-8 lg:px-12 lg:py-24">
          <div className="personal-story mx-auto grid max-w-[1440px] gap-8 lg:grid-cols-12 lg:gap-12">
            <div className="relative min-h-[430px] overflow-hidden sm:min-h-[560px] lg:col-span-5">
              <img src="/portfolio-assets/tanu-social-content-collage.webp" alt="Tanu Singh in a bright blue and white streetscape" className="h-full w-full object-cover object-center" />
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#1b1b1b]/70 to-transparent p-6 pt-24 sm:p-8 sm:pt-32">
                <p className="font-manrope text-[10px] font-extrabold uppercase tracking-[0.18em] text-white/80">The person behind the practice</p>
                <p className="mt-2 max-w-[300px] font-serif text-3xl leading-[0.96] tracking-[-0.04em] text-white">A curious, systems-aware partner for the next useful move.</p>
              </div>
            </div>
            <div className="flex flex-col justify-between lg:col-span-6 lg:col-start-7 lg:py-8">
              <div>
                <p className="eyebrow">Digital work, connected deliberately</p>
                <h2 className="mt-5 max-w-[660px] font-serif text-[clamp(3.1rem,5.8vw,6.6rem)] leading-[0.84] tracking-[-0.068em]">Good digital work makes the next <em className="text-[#f04438]">decision</em> easier.</h2>
              </div>
              <div className="mt-10 grid gap-7 border-t border-[#1b1b1b]/15 pt-7 sm:grid-cols-[1fr_170px] sm:items-end lg:mt-16">
                <p className="font-manrope text-sm leading-7 text-[#4f4a44]">From a search query to an onboarding flow, I focus on the small choices that make a business easier to find, easier to trust, and easier to run.</p>
                <img src="/portfolio-assets/tanu-social-content-collage.webp" alt="Tanu Singh outdoors under a blue sky" className="h-48 w-full object-cover object-center sm:h-56" />
              </div>
            </div>
          </div>
        </section>

        <section id="work" className="section-rule bg-[#f7f1e8] px-5 py-20 sm:px-8 lg:px-12 lg:py-32">
          <div className="mx-auto max-w-[1440px]">
            <div className="grid gap-8 lg:grid-cols-12 lg:gap-12">
              <div className="lg:col-span-4">
                <p className="eyebrow">Case study / 01</p>
                <h2 className="section-title mt-5 max-w-[440px]">A study in<br /><em>search intent.</em></h2>
              </div>
              <div className="flex flex-col justify-end lg:col-span-6 lg:col-start-7">
                <p className="max-w-[600px] font-manrope text-lg leading-8 text-[#4f4a44] sm:text-xl">
                  After completing my Digital Marketing course, I applied its core SEO concepts to a practical project for <strong className="font-extrabold text-[#1b1b1b]">V-Trims Design</strong>. The work became a useful bridge from theory to method: exploring search intent, page relevance, and content structure with more discipline.
                </p>
              </div>
            </div>

            <div className="case-study-grid mt-14 grid gap-8 lg:mt-20 lg:grid-cols-12 lg:gap-12">
              <div className="relative min-h-[465px] overflow-hidden lg:col-span-7 lg:min-h-[610px]">
                <img src="/portfolio-assets/tanu-case-study-seo-strategy.webp" alt="Editorial visual representing SEO research, search intent, and content structure" className="h-full w-full object-cover" />
                <div className="absolute left-5 top-5 flex h-20 w-20 -rotate-12 flex-col items-center justify-center rounded-full bg-[#f04438] text-center font-manrope text-[9px] font-extrabold uppercase leading-[1.15] tracking-[0.11em] text-white shadow-[0_8px_20px_rgba(240,68,56,0.24)] sm:left-8 sm:top-8">
                  V-Trims<br />Design<br />SEO lab
                </div>
                <div className="absolute bottom-5 right-5 max-w-[215px] border-l-2 border-[#f04438] bg-[#f7f1e8]/95 p-4 font-manrope backdrop-blur-sm sm:bottom-8 sm:right-8">
                  <p className="text-[9px] font-extrabold uppercase tracking-[0.16em] text-[#f04438]">Applied learning / 01</p>
                  <p className="mt-2 text-xs font-bold leading-5 text-[#1b1b1b]">Search intent → useful structure → future measurement</p>
                </div>
              </div>

              <div className="flex flex-col justify-between lg:col-span-5 lg:py-3">
                <div>
                  <div className="mb-8 flex items-center justify-between border-y border-[#1b1b1b]/15 py-4 font-manrope text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#5a554f]">
                    <span>Case-study lens</span>
                    <span>Applied learning</span>
                  </div>
                  <h3 className="font-serif text-4xl leading-[0.97] tracking-[-0.05em] sm:text-5xl">SEO begins with the question behind the query.</h3>
                  <p className="mt-6 max-w-[480px] font-manrope text-base leading-7 text-[#4f4a44]">
                    I translated course learning into a working SEO sequence: understand what a visitor may be looking for, structure a page around that need, and prepare the signals worth reviewing later.
                  </p>
                </div>

                <div className="mt-12 lg:mt-0">
                  <p className="eyebrow mb-5">Focus areas</p>
                  <ul className="space-y-3">
                    {seoFocus.map((item) => (
                      <li key={item} className="flex items-start gap-3 border-t border-[#1b1b1b]/12 pt-3 font-manrope text-sm font-semibold text-[#36322e]">
                        <Check className="mt-[1px] h-4 w-4 shrink-0 text-[#f04438]" />
                        {item}
                      </li>
                    ))}
                  </ul>
                  <div className="metrics-panel mt-8">
                    <div className="flex items-center justify-between gap-5"><p className="eyebrow text-[#f04438]">Campaign measurement / next layer</p><span className="rounded-full bg-[#ede5d8] px-2 py-1 font-manrope text-[9px] font-extrabold uppercase tracking-[0.12em] text-[#5a554f]">Baseline-led</span></div>
                    <p className="mt-3 font-manrope text-xs leading-5 text-[#5a554f]">This was a practical learning project. Analytics, ranking, and revenue outcomes were not included in the supplied project materials, so the case study focuses on method rather than unsupported growth claims.</p>
                    <div className="mt-5 grid grid-cols-3 gap-px bg-[#1b1b1b]/15">
                      <div className="metrics-cell"><strong>Intent map</strong><span>Group priority topics around the questions a page needs to answer.</span></div>
                      <div className="metrics-cell"><strong>Baseline review</strong><span>Capture an initial view before comparing future organic activity.</span></div>
                      <div className="metrics-cell"><strong>Page signals</strong><span>Review index coverage, CTR, and on-page actions when data is available.</span></div>
                    </div>
                    <a href="/case-studies/v-trims-design-seo" className="mt-6 inline-flex items-center gap-2 border-b border-[#1b1b1b]/30 pb-2 font-manrope text-xs font-extrabold transition-colors hover:border-[#f04438] hover:text-[#f04438]">Read the full case file <ArrowUpRight className="h-4 w-4" /></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="capabilities" className="section-rule bg-[#ede5d8] px-5 py-20 sm:px-8 lg:px-12 lg:py-32">
          <div className="mx-auto max-w-[1440px]">
            <div className="flex flex-col justify-between gap-8 border-b border-[#1b1b1b]/15 pb-12 lg:flex-row lg:items-end lg:pb-16">
              <div>
                <p className="eyebrow">How I work</p>
                <h2 className="section-title mt-5">A practical method<br />for <em>useful progress.</em></h2>
              </div>
              <p className="max-w-[360px] font-manrope text-base leading-7 text-[#5a554f]">A good outcome starts with a better brief: what is getting in the way, what should change, and what is the smallest useful move now?</p>
            </div>

            <div className="grid divide-y divide-[#1b1b1b]/15 lg:grid-cols-3 lg:divide-x lg:divide-y-0">
              {strengths.map((strength, index) => {
                const Icon = strength.icon;
                return (
                  <article key={strength.number} className={`group relative py-10 ${index === 0 ? "lg:pr-10" : "lg:px-10"} ${index === 2 ? "lg:pl-10" : ""}`}>
                    <div className="flex items-start justify-between">
                      <span className="font-manrope text-[11px] font-extrabold tracking-[0.14em] text-[#f04438]">{strength.number}</span>
                      <Icon className="h-6 w-6 text-[#1b1b1b] transition-transform duration-300 group-hover:-translate-y-1 group-hover:translate-x-1" />
                    </div>
                    <h3 className="mt-20 font-serif text-[2.3rem] leading-none tracking-[-0.05em]">{strength.title}</h3>
                    <p className="mt-5 max-w-[330px] font-manrope text-sm leading-6 text-[#5a554f]">{strength.text}</p>
                    <div className="mt-8 h-1 w-10 bg-[#f04438] transition-all duration-300 group-hover:w-20" />
                  </article>
                );
              })}
            </div>
          </div>
        </section>

        <section id="services" className="section-rule bg-[#1b1b1b] px-5 py-20 text-[#f7f1e8] sm:px-8 lg:px-12 lg:py-32">
          <div className="mx-auto max-w-[1440px]">
            <div className="grid gap-10 border-b border-[#f7f1e8]/20 pb-12 lg:grid-cols-12 lg:items-end lg:pb-16">
              <div className="lg:col-span-8"><p className="eyebrow text-[#f04438]">Freelance digital transformation</p><h2 className="section-title mt-5 text-[#f7f1e8]">From rough brief<br />to <em className="text-[#f04438]">working system.</em></h2></div>
              <p className="max-w-[380px] font-manrope text-sm leading-7 text-[#d6cec2] lg:col-span-3 lg:col-start-10">For founders and teams who need more than one isolated deliverable. I can begin where the friction is, then shape the marketing, build, automation, or data work that moves the business forward.</p>
            </div>
            <div className="service-grid mt-12 grid gap-x-0 gap-y-0 border-t border-[#f7f1e8]/20 lg:mt-16 lg:grid-cols-3">
              {freelanceServices.map((service) => {
                const Icon = service.icon;
                return <article key={service.number} className="service-card group"><span className="font-manrope text-[10px] font-extrabold tracking-[0.16em] text-[#f04438]">{service.number}</span><Icon className="absolute right-6 top-6 h-5 w-5 text-[#f7f1e8] transition-transform duration-300 group-hover:-translate-y-1 group-hover:translate-x-1" /><h3>{service.title}</h3><p>{service.text}</p><div className="service-signal" /></article>;
              })}
            </div>
            <div className="mt-10 flex flex-col gap-4 border-t border-[#f7f1e8]/20 pt-6 sm:flex-row sm:items-center sm:justify-between"><p className="font-manrope text-xs leading-6 text-[#d6cec2]">Inspired by Vernika’s Map → Build → Evolve operating approach, adapted into a freelance practice for focused projects and ongoing collaboration.</p><a href="#contact" className="inline-flex shrink-0 items-center gap-2 border-b border-[#f04438] pb-2 font-manrope text-xs font-extrabold text-[#f7f1e8]">Discuss your brief <ArrowUpRight className="h-4 w-4 text-[#f04438]" /></a></div>
          </div>
        </section>

        <section className="relative overflow-hidden bg-[#1b1b1b] px-5 py-20 text-[#f7f1e8] sm:px-8 lg:px-12 lg:py-32">
          <div className="relative mx-auto grid max-w-[1440px] gap-12 lg:grid-cols-12 lg:gap-12">
            <div className="lg:col-span-5">
              <p className="eyebrow text-[#f04438]">Content as a business signal</p>
              <h2 className="section-title mt-5 text-[#f7f1e8]">Content with a job to <em className="text-[#f04438]">do.</em></h2>
              <p className="mt-8 max-w-[425px] font-manrope text-base leading-7 text-[#d6cec2]">Whether the goal is recognition, explanation, consideration, or action, I shape content around the one useful thing a viewer should understand or do next.</p>
              <a href="#contact" className="mt-10 inline-flex items-center gap-3 border-b border-[#f7f1e8]/45 pb-2 font-manrope text-sm font-extrabold text-[#f7f1e8] transition-colors hover:border-[#f04438] hover:text-[#f04438]">
                Shape a content brief <ArrowUpRight className="h-4 w-4" />
              </a>
            </div>

            <div className="relative lg:col-span-7">
              <img src="/portfolio-assets/tanu-social-content-collage.webp" alt="Creative editorial collage representing social media content concepts" className="h-[420px] w-full object-cover sm:h-[520px]" />
              <div className="absolute -bottom-5 -left-3 max-w-[195px] bg-[#f04438] p-5 text-white sm:-left-7 sm:p-6">
                <p className="font-manrope text-[10px] font-extrabold uppercase tracking-[0.16em]">Content approach</p>
                <p className="mt-3 font-serif text-xl leading-[1.02]">One clear signal, made memorable.</p>
              </div>
              <img src="/portfolio-assets/tanu-social-content-collage.webp" alt="Tanu Singh in a bright setting with pink florals" className="absolute -bottom-12 right-5 hidden h-48 w-36 border-4 border-[#1b1b1b] object-cover sm:block lg:right-10" />
            </div>
          </div>

          <div className="relative mx-auto mt-24 max-w-[1440px] border-t border-[#f7f1e8]/20 pt-8 lg:mt-32">
            <div className="grid gap-7 md:grid-cols-3 md:gap-0 md:divide-x md:divide-[#f7f1e8]/20">
              {socialProcess.map(([number, title, text], index) => (
                <div key={number} className={`${index === 0 ? "md:pr-8" : "md:px-8"} ${index === 2 ? "md:pl-8" : ""}`}>
                  <span className="font-manrope text-[10px] font-extrabold tracking-[0.15em] text-[#f04438]">{number}</span>
                  <h3 className="mt-5 font-serif text-3xl tracking-[-0.04em]">{title}</h3>
                  <p className="mt-3 max-w-[320px] font-manrope text-sm leading-6 text-[#d6cec2]">{text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="gallery" className="section-rule bg-[#f7f1e8] px-5 py-20 sm:px-8 lg:px-12 lg:py-32">
          <div className="mx-auto max-w-[1440px]">
            <div className="grid gap-8 border-b border-[#1b1b1b]/15 pb-12 lg:grid-cols-12 lg:items-end lg:gap-12 lg:pb-16">
              <div className="lg:col-span-7">
                <p className="eyebrow">Visual project studies</p>
                <h2 className="section-title mt-5">Case thinking,<br /><em>made visible.</em></h2>
              </div>
              <p className="max-w-[385px] font-manrope text-sm leading-7 text-[#5a554f] lg:col-span-3 lg:col-start-10">Each visual study gives a project approach a clear frame—from a search-intent system to an automation flow or a decision-ready reporting view.</p>
            </div>

            <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:mt-16 lg:grid-cols-3 lg:gap-8">
              <figure className="gallery-card group lg:mt-16" tabIndex={0}>
                <div className="gallery-image-wrap"><img src="/portfolio-assets/tanu-case-study-seo-strategy.webp" alt="Editorial SEO strategy case-study visual" className="gallery-image" /><span className="gallery-overlay"><span>SEO<br />study</span><ArrowUpRight className="h-5 w-5" /></span></div>
                <figcaption className="mt-5 flex items-start justify-between gap-5 border-t border-[#1b1b1b]/15 pt-4">
                  <div><p className="eyebrow text-[#f04438]">Case study / 01</p><p className="mt-2 font-serif text-2xl tracking-[-0.04em]">Search-intent system</p></div>
                  <ArrowUpRight className="mt-1 h-5 w-5 shrink-0 transition-transform duration-300 group-hover:-translate-y-1 group-hover:translate-x-1" />
                </figcaption>
              </figure>

              <figure className="gallery-card group" tabIndex={0}>
                <div className="gallery-image-wrap"><img src="/portfolio-assets/tanu-case-study-digital-blueprint.webp" alt="Editorial digital transformation case-study visual" className="gallery-image" /><span className="gallery-overlay"><span>Digital<br />blueprint</span><ArrowUpRight className="h-5 w-5" /></span></div>
                <figcaption className="mt-5 flex items-start justify-between gap-5 border-t border-[#1b1b1b]/15 pt-4">
                  <div><p className="eyebrow text-[#f04438]">Case study / 02</p><p className="mt-2 font-serif text-2xl tracking-[-0.04em]">Digital foundation</p></div>
                  <ArrowUpRight className="mt-1 h-5 w-5 shrink-0 transition-transform duration-300 group-hover:-translate-y-1 group-hover:translate-x-1" />
                </figcaption>
              </figure>

              <figure className="gallery-card group sm:col-span-2 lg:col-span-1 lg:mt-24" tabIndex={0}>
                <div className="gallery-image-wrap"><img src="/portfolio-assets/tanu-case-study-data-visualization.webp" alt="Editorial data visualisation case-study visual" className="gallery-image" /><span className="gallery-overlay"><span>Decision<br />dashboard</span><ArrowUpRight className="h-5 w-5" /></span></div>
                <figcaption className="mt-5 flex items-start justify-between gap-5 border-t border-[#1b1b1b]/15 pt-4">
                  <div><p className="eyebrow text-[#f04438]">Case study / 03</p><p className="mt-2 font-serif text-2xl tracking-[-0.04em]">Decision-ready data</p></div>
                  <ArrowUpRight className="mt-1 h-5 w-5 shrink-0 transition-transform duration-300 group-hover:-translate-y-1 group-hover:translate-x-1" />
                </figcaption>
              </figure>
            </div>
          </div>
        </section>

        <section id="about" className="section-rule bg-[#f7f1e8] px-5 py-20 sm:px-8 lg:px-12 lg:py-32">
          <div className="mx-auto grid max-w-[1440px] gap-12 lg:grid-cols-12 lg:gap-12">
            <div className="lg:col-span-4">
              <p className="eyebrow">A little about me</p>
              <div className="relative mt-8 max-w-[335px] overflow-hidden bg-[#e7dccb]">
                <img src="/portfolio-assets/tanu-hero-growth-still-life.webp" alt="Professional portrait of Tanu Singh seated in a café" className="aspect-[4/5] w-full object-cover object-center" />
                <div className="absolute bottom-0 right-0 bg-[#1b1b1b] px-4 py-3 font-manrope text-[9px] font-extrabold uppercase tracking-[0.14em] text-[#f7f1e8]">Tanu Singh<br /><span className="text-[#f04438]">Digital marketing</span></div>
              </div>
              <p className="mt-7 max-w-[280px] font-manrope text-xs leading-5 text-[#5a554f]">I bring research discipline, practical systems thinking, and an interest in making ambitious digital work feel more manageable.</p>
            </div>
            <div className="lg:col-span-7 lg:col-start-6">
              <p className="font-serif text-[clamp(2.6rem,5vw,5.25rem)] leading-[0.94] tracking-[-0.06em] text-[#1b1b1b]">
                I work at the intersection of <em className="text-[#f04438]">visibility</em>, usable systems, and decision-ready information.
              </p>
              <div className="mt-10 grid gap-7 border-t border-[#1b1b1b]/15 pt-8 sm:grid-cols-2">
                <p className="font-manrope text-sm leading-7 text-[#4f4a44]">My Digital Marketing course gave me a strong starting framework. The V-Trims Design project gave me a real applied context. I am extending that foundation through freelance-style case studies across marketing, websites, workflows, and data—always with a clear evidence boundary.</p>
                <div>
                  <p className="eyebrow mb-4">Working style</p>
                  <div className="flex flex-wrap gap-2">
                    {["Research-led", "Systems-aware", "Clear communicator", "Iterative"].map((trait) => <span key={trait} className="tag-pill">{trait}</span>)}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="section-rule bg-[#ede5d8] px-5 py-20 sm:px-8 lg:px-12 lg:py-32">
          <div className="mx-auto max-w-[1440px]">
            <div className="flex flex-col justify-between gap-8 border-b border-[#1b1b1b]/15 pb-12 lg:flex-row lg:items-end lg:pb-16">
              <div>
                <p className="eyebrow">From the journal</p>
                <h2 className="section-title mt-5">Notes on the<br /><em>work in progress.</em></h2>
              </div>
              <a href="/case-studies" className="cta-button group">Explore case studies <span className="grid h-7 w-7 place-items-center rounded-full bg-[#1b1b1b] text-[#f7f1e8] transition-transform duration-300 group-hover:translate-x-1"><BookOpen className="h-4 w-4" /></span></a>
            </div>
            <div className="mt-12 grid gap-8 lg:mt-16 lg:grid-cols-3 lg:gap-10">
              <a href="/journal/seo-foundations" className="journal-teaser group lg:mt-10">
                <img src="/portfolio-assets/tanu-seo-signal-collage.webp" alt="Annotated editorial collage representing SEO research and search intent" className="aspect-[4/5] w-full object-cover" />
                <div className="mt-5 border-t border-[#1b1b1b]/15 pt-4"><p className="eyebrow text-[#f04438]">SEO notes · 4 min read</p><h3 className="mt-2 font-serif text-3xl leading-[0.95] tracking-[-0.05em]">What an SEO project taught me about starting with intent.</h3><span className="mt-5 inline-flex items-center gap-2 font-manrope text-xs font-extrabold">Read note <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-1 group-hover:translate-x-1" /></span></div>
              </a>
              <a href="/journal/social-content" className="journal-teaser group">
                <img src="/portfolio-assets/tanu-social-gallery-02.webp" alt="Editorial social content concept showing visual hierarchy and creative rhythm" className="aspect-[4/5] w-full object-cover" />
                <div className="mt-5 border-t border-[#1b1b1b]/15 pt-4"><p className="eyebrow text-[#f04438]">Content notes · 3 min read</p><h3 className="mt-2 font-serif text-3xl leading-[0.95] tracking-[-0.05em]">A simple lens for making social posts feel more considered.</h3><span className="mt-5 inline-flex items-center gap-2 font-manrope text-xs font-extrabold">Read note <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-1 group-hover:translate-x-1" /></span></div>
              </a>
              <a href="/journal" className="journal-teaser group lg:mt-20">
                <img src="/portfolio-assets/tanu-social-content-collage.webp" alt="Tanu Singh in a floral streetscape" className="aspect-[4/5] w-full object-cover" />
                <div className="mt-5 border-t border-[#1b1b1b]/15 pt-4"><p className="eyebrow text-[#f04438]">Practice note · 2 min read</p><h3 className="mt-2 font-serif text-3xl leading-[0.95] tracking-[-0.05em]">Why staying curious is a useful marketing skill.</h3><span className="mt-5 inline-flex items-center gap-2 font-manrope text-xs font-extrabold">Explore notes <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-1 group-hover:translate-x-1" /></span></div>
              </a>
            </div>
          </div>
        </section>

        {managedProjects.length > 0 && <section className="section-rule bg-[#f7f1e8] px-5 py-20 sm:px-8 lg:px-12 lg:py-32">
          <div className="mx-auto max-w-[1440px]">
            <div className="flex flex-col justify-between gap-7 border-b border-[#1b1b1b]/15 pb-10 lg:flex-row lg:items-end lg:pb-14"><div><p className="eyebrow">Managed project ledger</p><h2 className="section-title mt-5">Fresh work,<br /><em>published with context.</em></h2></div><p className="max-w-sm font-manrope text-sm leading-6 text-[#5a554f]">These project cards are managed from the private portfolio workspace and appear here only when they are published.</p></div>
            <div className="mt-10 grid gap-6 md:grid-cols-2 lg:mt-14 lg:grid-cols-3">{managedProjects.map(project => <article key={project.id} className="group border border-[#1b1b1b]/15 bg-white p-5 transition-transform duration-300 hover:-translate-y-1"><p className="eyebrow text-[#f04438]">{project.category}</p>{project.imageUrl && <img src={project.imageUrl} alt="" className="mt-5 aspect-[16/9] w-full object-cover" />}<h3 className="mt-5 font-serif text-3xl leading-[0.95] tracking-[-0.05em]">{project.title}</h3><p className="mt-4 font-manrope text-sm leading-6 text-[#5a554f]">{project.summary}</p><span className="mt-6 inline-flex items-center gap-2 font-manrope text-xs font-extrabold">Published project <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-1 group-hover:translate-x-1" /></span></article>)}</div>
          </div>
        </section>}

        {managedSiteDetails.length > 0 && <section className="section-rule bg-[#ede5d8] px-5 py-14 sm:px-8 lg:px-12 lg:py-20"><div className="mx-auto max-w-[1440px]"><p className="eyebrow">Studio details</p><div className="mt-7 grid gap-5 md:grid-cols-2 lg:grid-cols-3">{managedSiteDetails.filter(detail => !["contact-headline", "contact-intro", "contact-email"].includes(detail.detailKey)).map(detail => <article key={detail.id} className="border-t border-[#1b1b1b]/15 pt-4"><p className="font-manrope text-[10px] font-extrabold uppercase tracking-[0.14em] text-[#f04438]">{detail.section}</p><h3 className="mt-2 font-serif text-2xl tracking-[-0.04em]">{detail.label}</h3><p className="mt-3 font-manrope text-sm leading-6 text-[#5a554f]">{detail.value}</p></article>)}</div></div></section>}

        <section id="contact" className="bg-[#f04438] px-5 py-20 text-white sm:px-8 lg:px-12 lg:py-28">
          <div className="mx-auto max-w-[1440px]">
            <div className="grid gap-10 lg:grid-cols-12 lg:items-end">
              <div className="lg:col-span-8">
                <p className="font-manrope text-[10px] font-extrabold uppercase tracking-[0.2em] text-white/80">Open to opportunities & collaborations</p>
                <h2 className="mt-5 max-w-[880px] font-serif text-[clamp(3.8rem,8vw,8rem)] leading-[0.83] tracking-[-0.075em]">{contactHeadline}</h2>
              </div>
              <div className="lg:col-span-3 lg:col-start-10">
                <p className="font-manrope text-sm leading-6 text-white/90">{contactIntro}</p>
                <div className="mt-7 space-y-3 font-manrope text-sm font-extrabold">
                  <a href={`mailto:${contactEmail}`} className="contact-link">{contactEmail} <ArrowUpRight className="h-4 w-4" /></a>
                  <a href="https://www.linkedin.com/in/tanusinghchauhan" target="_blank" rel="noreferrer" className="contact-link">Connect on LinkedIn <ArrowUpRight className="h-4 w-4" /></a>
                </div>
              </div>
            </div>

            <form onSubmit={handleContactSubmit} className="contact-form mt-14 grid gap-x-8 gap-y-6 border-t border-white/35 pt-8 lg:mt-16 lg:grid-cols-12 lg:pt-10">
              <div className="lg:col-span-3">
                <p className="font-serif text-3xl leading-none tracking-[-0.04em]">Send an enquiry.</p>
                <p className="mt-3 max-w-[245px] font-manrope text-xs leading-5 text-white/80">Tell me what you are building. When you submit, your own default email app—such as Gmail—opens with this project brief ready to send.</p>
              </div>
              <div className="grid gap-x-6 gap-y-6 sm:grid-cols-2 lg:col-span-8 lg:col-start-5">
                <input name="website" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden="true" />
                <label className="contact-field"><span>Your name</span><input name="clientName" type="text" autoComplete="name" required placeholder="Your name" className="contact-input" /></label>
                <label className="contact-field"><span>Email address</span><input name="email" type="email" autoComplete="email" required placeholder="you@example.com" className="contact-input" /></label>
                <label className="contact-field"><span>Business / project name</span><input name="business" type="text" required placeholder="Your business or project" className="contact-input" /></label>
                <label className="contact-field"><span>Service needed</span><select name="service" required defaultValue="" className="contact-input"><option value="" disabled>Select a service</option><option>Digital transformation from scratch</option><option>Digital marketing & SEO</option><option>Website development</option><option>Application development</option><option>Automation tools or scripts</option><option>Data engineering</option><option>Data visualisation</option><option>Not sure yet — need a discovery call</option></select></label>
                <label className="contact-field"><span>Current stage</span><select name="stage" required defaultValue="" className="contact-input"><option value="" disabled>Select a stage</option><option>Starting from an idea</option><option>Existing business needing a digital reset</option><option>Existing system needing improvement</option><option>Ready to launch</option></select></label>
                <label className="contact-field"><span>Preferred timeline</span><select name="timeline" required defaultValue="" className="contact-input"><option value="" disabled>Select a timeline</option><option>Within 2 weeks</option><option>Within 1 month</option><option>Within 2–3 months</option><option>Exploring options</option></select></label>
                <label className="contact-field"><span>Primary goal</span><input name="goal" type="text" required placeholder="What should improve?" className="contact-input" /></label>
                <label className="contact-field"><span>Budget range</span><select name="budget" required defaultValue="" className="contact-input"><option value="" disabled>Select a range</option><option>Under ₹25,000</option><option>₹25,000–₹75,000</option><option>₹75,000–₹2,00,000</option><option>₹2,00,000+</option><option>To be discussed</option></select></label>
                <label className="contact-field sm:col-span-2"><span>Project requirements</span><textarea name="requirements" required rows={5} placeholder="Share the context, problem, audience, and anything else that would help..." className="contact-input contact-textarea" /></label>
                <div className="flex flex-col items-start gap-3 sm:col-span-2 sm:flex-row sm:items-center sm:justify-between"><button type="submit" className="contact-submit">Open my email app <ArrowUpRight className="h-4 w-4" /></button><p aria-live="polite" className="max-w-[320px] font-manrope text-[11px] font-semibold leading-5 text-white/85">{formStatus || "This form does not send email through the site; it prepares a message in your own email app."}</p></div>
              </div>
            </form>
          </div>
        </section>
      </main>

      <footer className="bg-[#1b1b1b] px-5 py-7 text-[#f7f1e8] sm:px-8 lg:px-12">
        <div className="mx-auto flex max-w-[1440px] flex-col justify-between gap-4 sm:flex-row sm:items-center">
          <div className="flex items-center gap-3"><img src="/portfolio-assets/tanu-signal-mark.webp" alt="" className="h-8 w-8 object-contain" /><span className="font-serif text-xl tracking-[-0.06em] text-[#f7f1e8]">tanu <em className="text-[#f04438]">singh</em></span></div>
          <div className="flex flex-col gap-3 font-manrope text-[10px] font-bold uppercase tracking-[0.14em] text-[#c7bfb4] sm:flex-row sm:gap-8"><p>© 2026 Tanu Singh</p><p>Digital marketing · SEO · Social content</p></div>
        </div>
      </footer>
    </div>
  );
}
