/**
 * DESIGN REMINDER — Signal & Story:
 * Case-study browsing should feel like a strategy publication: paper-cream space, ink hierarchy, coral signals,
 * and visible evidence boundaries. Illustrative studies must never be presented as verified client outcomes.
 */
import { ArrowDownRight, ArrowUpRight, BookOpen } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";

const studies = [
  {
    slug: "v-trims-design-seo",
    eyebrow: "Applied learning project · SEO",
    title: "V-Trims Design: turning course learning into a search-focused practice.",
    description: "A real practical SEO project that brought keyword research, search intent, on-page structure, and content relevance into one working method.",
    note: "No traffic, ranking, or revenue outcomes are claimed because baseline and post-project data were not supplied.",
    image: "/portfolio-assets/tanu-case-study-seo-strategy.webp",
  },
  {
    slug: "digital-foundation",
    eyebrow: "Illustrative capability study · Digital transformation",
    title: "From scattered business activity to a clearer digital foundation.",
    description: "A relatable framework for a small business that needs a stronger online presence, clearer client journey, and a practical roadmap for what to build first.",
    note: "An illustrative project framework, not a paid client engagement or a claimed business outcome.",
    image: "/portfolio-assets/tanu-case-study-digital-blueprint.webp",
  },
  {
    slug: "automation-workflow",
    eyebrow: "Illustrative capability study · Automation",
    title: "Making repeat work visible before making it automatic.",
    description: "A workflow concept for identifying handoff friction, defining a clear trigger, and building lightweight automation around an existing business process.",
    note: "An illustrative project framework; no client automation or time-saving metric is claimed.",
    image: "/portfolio-assets/tanu-case-study-automation-workflow.webp",
  },
  {
    slug: "decision-dashboard",
    eyebrow: "Illustrative capability study · Data visualisation",
    title: "A reporting view designed around the next decision—not the biggest data dump.",
    description: "A practical dashboard concept that moves from disconnected source information toward a smaller set of decision-ready signals.",
    note: "An illustrative project framework; no proprietary data or performance result is represented.",
    image: "/portfolio-assets/tanu-case-study-data-visualization.webp",
  },
];

export default function CaseStudies() {
  const { data: managedStudies = [] } = trpc.publicContent.caseStudies.useQuery();
  const allStudies = [
    ...studies,
    ...managedStudies.map(study => ({
      slug: study.slug,
      eyebrow: study.eyebrow,
      title: study.title,
      description: study.summary,
      note: study.evidenceNote,
      image: study.heroImage || "/portfolio-assets/tanu-case-study-digital-blueprint.webp",
    })),
  ];
  return (
    <div className="min-h-screen overflow-x-hidden bg-[#f7f1e8] text-[#1b1b1b]">
      <header className="border-b border-[#1b1b1b]/10 bg-[#f7f1e8]/92 backdrop-blur-xl">
        <div className="mx-auto flex h-[76px] max-w-[1440px] items-center justify-between px-5 sm:px-8 lg:px-12">
          <Link href="/" className="group flex items-center gap-3" aria-label="Tanu Singh home"><img src="/portfolio-assets/tanu-signal-mark.webp" alt="Tanu Singh signal mark" className="h-9 w-9 object-contain transition-transform duration-300 group-hover:rotate-6" /><span className="font-serif text-[1.38rem] leading-none tracking-[-0.06em]">tanu <em className="text-[#f04438]">singh</em></span></Link>
          <Link href="/" className="inline-flex items-center gap-2 font-manrope text-xs font-extrabold">Back to portfolio <ArrowUpRight className="h-4 w-4 text-[#f04438]" /></Link>
        </div>
      </header>

      <main>
        <section className="border-b border-[#1b1b1b]/10 px-5 py-20 sm:px-8 lg:px-12 lg:py-28">
          <div className="mx-auto grid max-w-[1440px] gap-12 lg:grid-cols-12 lg:items-end">
            <div className="lg:col-span-8"><p className="eyebrow">Selected case studies</p><h1 className="mt-5 max-w-[900px] font-serif text-[clamp(4.1rem,8vw,8.7rem)] leading-[0.81] tracking-[-0.078em]">Useful work, shown with <em className="text-[#f04438]">context.</em></h1></div>
            <p className="border-l-2 border-[#f04438] pl-5 font-manrope text-base leading-7 text-[#4f4a44] lg:col-span-3 lg:col-start-10">Each study makes its evidence boundary clear. Real project experience is identified; capability studies are framed as practical, illustrative project approaches.</p>
          </div>
        </section>

        <section className="bg-[#1b1b1b] px-5 py-6 text-[#f7f1e8] sm:px-8 lg:px-12"><div className="mx-auto flex max-w-[1440px] items-center gap-3 font-manrope text-[10px] font-extrabold uppercase tracking-[0.16em]"><BookOpen className="h-4 w-4 text-[#f04438]" /> Scope · process · deliverables · evidence note</div></section>

        <section className="px-5 py-20 sm:px-8 lg:px-12 lg:py-32">
          <div className="mx-auto max-w-[1440px]">
            <div className="grid gap-10 lg:grid-cols-2 lg:gap-x-12 lg:gap-y-20">
              {allStudies.map((study, index) => (
                <Link key={study.slug} href={`/case-studies/${study.slug}`} className={`journal-teaser group ${index % 2 === 0 ? "lg:mt-10" : ""}`}>
                  <div className="relative overflow-hidden bg-[#ede5d8]"><img src={study.image} alt="Editorial visual for the case study" className="aspect-[4/5] w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]" /><span className="absolute bottom-5 left-5 bg-[#f7f1e8] px-3 py-2 font-manrope text-[9px] font-extrabold uppercase tracking-[0.13em] text-[#1b1b1b]">0{index + 1} / case file</span></div>
                  <div className="mt-5 border-t border-[#1b1b1b]/15 pt-4"><p className="eyebrow text-[#f04438]">{study.eyebrow}</p><h2 className="mt-3 max-w-[580px] font-serif text-[clamp(2.3rem,4vw,4.3rem)] leading-[0.92] tracking-[-0.06em]">{study.title}</h2><p className="mt-5 max-w-[600px] font-manrope text-sm leading-7 text-[#4f4a44]">{study.description}</p><p className="mt-4 border-l-2 border-[#1b1b1b]/20 pl-3 font-manrope text-[11px] font-semibold leading-5 text-[#6a645d]">{study.note}</p><span className="mt-6 inline-flex items-center gap-2 font-manrope text-xs font-extrabold">Read case file <ArrowDownRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" /></span></div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
