# Design Direction — Tanu Singh Digital Marketing Portfolio

## Three visual approaches considered

### 1. Signal & Story
**Very Brief Intro:** A warm editorial portfolio that treats strategy as a compelling narrative, balancing precise metrics with energetic creative work. It should feel intelligent, human, and ready to collaborate.

**Probability:** 0.07

### 2. Studio Index
**Very Brief Intro:** A quiet, gallery-like design with oversized typography, archival labels, and monochrome structure. It would convey a restrained creative studio sensibility.

**Probability:** 0.04

### 3. Growth Field Notes
**Very Brief Intro:** A tactile notebook-inspired layout with bright data signals and imperfect editorial details. It would position the portfolio as an approachable record of practical marketing experimentation.

**Probability:** 0.09

---

## Chosen approach: Signal & Story

### Design Movement
**Contemporary editorial design** with the self-assured clarity of a strategy publication and the warmth of an independent creative studio.

### Core Principles
1. Put the work before the decoration: each page moment should clarify capability, process, or an invitation to collaborate.
2. Pair analytical signals with expressive editorial gestures to communicate both SEO rigor and social creativity.
3. Use deliberate asymmetry, generous whitespace, and strong typographic contrast rather than generic centered blocks.
4. Keep every interaction concise, tactile, and purposeful.

### Color Philosophy
A soft **paper cream** foundation makes the site human and approachable, while **ink black** gives the work credibility and legibility. A saturated **signal coral** creates deliberate moments of action, progress, and creative energy. Muted moss is reserved for supporting “growth” cues, never for decoration alone.

### Layout Paradigm
An **editorial story stack** rather than a conventional centered landing page. Full-bleed type and visual moments are interrupted by slim index rails, offset cards, hand-marked emphasis, and large side annotations.

### Signature Elements
1. Coral circular stamps and underlines that identify key outcomes and actions.
2. Compact “field note” labels with uppercase metadata and numeric index markers.
3. A tactile paper grain with delicate rule lines that divide the page without boxed-in sections.

### Interaction Philosophy
Interactions should feel like moving through a well-made campaign brief: navigation scrolls directly to the relevant proof, cards gently lift to reveal intent, and buttons compress slightly on press. No decorative interaction should compete with reading.

### Animation
Use a 600ms editorial reveal for primary hero details and 180–240ms motion for utility interactions. Scroll-linked elements should use only subtle translate and opacity transitions. Underlines should draw in on hover, with a visible reduced-motion fallback.

### Typography System
**DM Serif Display** is used for high-impact editorial headlines and highlighted phrases. **Manrope** carries the navigation, labels, metrics, and body text in a clear, conversational voice. Headlines use tight tracking and large scale; labels use small uppercase text with generous letter spacing.

### Brand Essence
**Tanu Singh helps emerging brands turn discoverability and daily content into focused digital momentum.**

Personality: **strategic, warm, observant**.

### Brand Voice
Headlines are specific and energetic; CTAs are collaborative and low-pressure; microcopy explains what the visitor can expect next.

Example headline: “Make your next search—and scroll—count.”

Example CTA: “Tell me what you are building.”

### Wordmark & Logo
The logo is an abstract **T/S signal mark**: an interlocking coral arc and dark directional bar suggesting upward momentum, used alongside a custom lowercase wordmark with editorial character.

### Signature Brand Color
**Signal Coral — #F04438**

## Style Decisions

* The image rhythm should be **one human moment, two work-proof moments**: portraits create warmth, while SEO artefacts, content studies, and process details establish professional credibility.
* **Signal Coral** is reserved for actions, key insights, proof points, and forward momentum rather than generic decoration.
* Journal articles retain the field-note system with coral indices, rule-led sections, and visible takeaway annotations.
