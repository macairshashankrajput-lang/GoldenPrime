# Supplied Photo Curation Notes

| File | Visual finding | Proposed use |
| --- | --- | --- |
| WhatsAppImage2026-08-05at7.35.41PM.jpeg | Strong, professionally lit portrait against a dark backdrop; warm rose attire and clear face create an editorial feel. | Primary About-section portrait or a prominent image in the hero story stack. |
| WhatsAppImage2026-08-10at1.22.56PM(3).jpeg | Full-length, composed personal portrait in a restaurant-like setting; light blazer gives an approachable professional tone. | Supporting personal-story image in the expanded home page or About page. |
| 7D3F0C9A-EB28-4C40-AB81-96A8B4CE1244_1_105_c.jpeg | Bright outdoor portrait with a blue sky and headphones; relaxed and energetic personal tone. | Supporting image for a blog-card feature or “outside the brief” home-page moment. |
| 2A00D55F-89B6-47D3-B102-E8BBADB7E366_1_105_c.jpeg | Light-filled, travel-style portrait with blue architectural details and strong composition. | Visual break in the home-page story or an image-led blog card. |
| 6BB6BA7D-6B12-4102-B006-75689BB25732_1_105_c.jpeg | Candid full-length portrait in a bright blue-and-white environment; pink florals offer a lively accent. | Colorful supporting portrait for the About page or a personal-note section. |
| 78E6383F-9F1B-4017-8EFF-D3EFB8F85FEC_1_105_c.jpeg | High-angle outdoor portrait with a blue book and strong blue pavement; natural “learning in motion” story. | Lead image for a practical-learning blog-card feature. |
| 709DDAE8-DB4B-4960-AF59-7983E77A8978.jpeg | High-contrast seated portrait in a graphic “I AM A CREATOR” setting; strongest self-directed creative signal in the set. | Image-led hero or primary About-section portrait, where the dark background can create a powerful contrast moment. |
| 77CBF171-4863-4B70-B8C2-D3047B4EBF49_1_105_c.jpeg | Relaxed but polished café portrait in a grey blazer with warm architectural light. | Ideal professional headshot for the About section and a welcoming visual on the Contact page. |
