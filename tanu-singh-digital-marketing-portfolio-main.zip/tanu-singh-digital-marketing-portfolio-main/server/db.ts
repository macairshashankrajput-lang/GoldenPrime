import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import type { MySql2Database } from "drizzle-orm/mysql2";
import * as schema from "../drizzle/schema";
import { InsertUser, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

const SUPABASE_URL = "https://rglfqxunnmlwpbdyhdtq.supabase.co";

let _authDb: MySql2Database<typeof schema> | null = null;

// The pre-existing Manus OAuth user record continues to use the template's
// system database. Portfolio business data is stored in Supabase below.
export async function getDb() {
  if (!_authDb && process.env.DATABASE_URL) {
    try {
      _authDb = drizzle(process.env.DATABASE_URL) as unknown as MySql2Database<typeof schema>;
    } catch (error) {
      console.warn("[Auth database] Failed to initialize:", error);
      _authDb = null;
    }
  }
  return _authDb;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  for (const field of ["name", "email", "loginMethod"] as const) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  values.role = user.role ?? (user.openId === ENV.ownerOpenId ? "admin" : "user");
  values.lastSignedIn = user.lastSignedIn ?? new Date();
  updateSet.role = values.role;
  updateSet.lastSignedIn = values.lastSignedIn;
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

function getSupabaseKey() {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!key) throw new Error("Supabase service role key is not configured");
  return key;
}

async function supabaseRequest<T>(path: string, init: RequestInit = {}): Promise<T> {
  const key = getSupabaseKey();
  const response = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    ...init,
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
      ...(init.headers ?? {}),
    },
  });
  if (!response.ok) {
    const message = await response.text();
    throw new Error(`Supabase request failed (${response.status}): ${message.slice(0, 240)}`);
  }
  const text = await response.text();
  return (text ? JSON.parse(text) : null) as T;
}

type SupabaseLead = { id: number; name: string; email: string; business: string; source: string; status: "new" | "contacted" | "qualified" | "archived"; created_at: string; updated_at: string };
type SupabaseRequest = { id: number; lead_id: number; service: string; stage: string; goal: string; budget: string; timeline: string; requirements: string; status: "new" | "reviewing" | "scheduled" | "closed"; created_at: string; updated_at: string };
type SupabaseProject = { id: number; title: string; slug: string; category: string; summary: string; image_url: string | null; status: "draft" | "published"; created_at: string; updated_at: string };
type SupabaseCaseStudy = { id: number; slug: string; eyebrow: string; title: string; summary: string; hero_image: string | null; scope: string; process: string; evidence_note: string; status: "draft" | "published"; created_at: string; updated_at: string };
type SupabaseSiteDetail = { id: number; section: string; detail_key: string; label: string; value: string; updated_at: string };

const asTime = (value: string) => new Date(value).valueOf();
const mapLead = (row: SupabaseLead) => ({ id: row.id, name: row.name, email: row.email, business: row.business, source: row.source, status: row.status, createdAt: asTime(row.created_at), updatedAt: asTime(row.updated_at) });
const mapProject = (row: SupabaseProject) => ({ id: row.id, title: row.title, slug: row.slug, category: row.category, summary: row.summary, imageUrl: row.image_url, status: row.status, createdAt: asTime(row.created_at), updatedAt: asTime(row.updated_at) });
const mapCaseStudy = (row: SupabaseCaseStudy) => ({ id: row.id, slug: row.slug, eyebrow: row.eyebrow, title: row.title, summary: row.summary, heroImage: row.hero_image, scope: row.scope, process: row.process, evidenceNote: row.evidence_note, status: row.status, createdAt: asTime(row.created_at), updatedAt: asTime(row.updated_at) });
const mapSiteDetail = (row: SupabaseSiteDetail) => ({ id: row.id, section: row.section, detailKey: row.detail_key, label: row.label, value: row.value, updatedAt: asTime(row.updated_at) });

export type ConsultationSubmission = { name: string; email: string; business: string; service: string; stage: string; goal: string; budget: string; timeline: string; requirements: string };

export async function createConsultationSubmission(input: ConsultationSubmission) {
  const [lead] = await supabaseRequest<SupabaseLead[]>("leads", {
    method: "POST",
    headers: { Prefer: "return=representation" },
    body: JSON.stringify({ name: input.name, email: input.email, business: input.business, source: "portfolio", status: "new" }),
  });
  if (!lead) throw new Error("Unable to create lead");
  const [request] = await supabaseRequest<SupabaseRequest[]>("consultation_requests", {
    method: "POST",
    headers: { Prefer: "return=representation" },
    body: JSON.stringify({ lead_id: lead.id, service: input.service, stage: input.stage, goal: input.goal, budget: input.budget, timeline: input.timeline, requirements: input.requirements, status: "new" }),
  });
  if (!request) throw new Error("Unable to create consultation request");
  return { leadId: lead.id, requestId: request.id };
}

export type LeadFilters = { search?: string; startDate?: number; endDate?: number };

function matchesFilters(row: { name?: string; email?: string; business?: string; service?: string; createdAt: number }, filters: LeadFilters) {
  const term = filters.search?.trim().toLowerCase();
  const haystack = [row.name, row.email, row.business, row.service].filter(Boolean).join(" ").toLowerCase();
  return (!term || haystack.includes(term)) && (!filters.startDate || row.createdAt >= filters.startDate) && (!filters.endDate || row.createdAt <= filters.endDate);
}

export async function listLeads(filters: LeadFilters = {}) {
  const rows = await supabaseRequest<SupabaseLead[]>("leads?select=*&order=created_at.desc");
  return rows.map(mapLead).filter(row => matchesFilters(row, filters));
}

export async function listConsultationRequests(filters: LeadFilters = {}) {
  const [requestRows, leadRows] = await Promise.all([
    supabaseRequest<SupabaseRequest[]>("consultation_requests?select=*&order=created_at.desc"),
    supabaseRequest<SupabaseLead[]>("leads?select=*"),
  ]);
  const leadById = new Map(leadRows.map(row => [row.id, row]));
  return requestRows.map(row => {
    const lead = leadById.get(row.lead_id);
    return { id: row.id, leadId: row.lead_id, service: row.service, stage: row.stage, goal: row.goal, budget: row.budget, timeline: row.timeline, requirements: row.requirements, status: row.status, createdAt: asTime(row.created_at), updatedAt: asTime(row.updated_at), leadName: lead?.name ?? "Deleted lead", leadEmail: lead?.email ?? "", business: lead?.business ?? "" };
  }).filter(row => matchesFilters({ name: row.leadName, email: row.leadEmail, business: row.business, service: row.service, createdAt: row.createdAt }, filters));
}

export async function updateLeadStatus(id: number, status: "new" | "contacted" | "qualified" | "archived") {
  await supabaseRequest(`leads?id=eq.${id}`, { method: "PATCH", body: JSON.stringify({ status, updated_at: new Date().toISOString() }) });
}

export async function updateConsultationStatus(id: number, status: "new" | "reviewing" | "scheduled" | "closed") {
  await supabaseRequest(`consultation_requests?id=eq.${id}`, { method: "PATCH", body: JSON.stringify({ status, updated_at: new Date().toISOString() }) });
}

export async function deleteLead(id: number) { await supabaseRequest(`leads?id=eq.${id}`, { method: "DELETE" }); }
export async function deleteConsultationRequest(id: number) { await supabaseRequest(`consultation_requests?id=eq.${id}`, { method: "DELETE" }); }

export type ManagedProjectInput = { title: string; slug: string; category: string; summary: string; imageUrl?: string | null; status: "draft" | "published" };
export async function listProjects(includeDrafts = false) {
  const filter = includeDrafts ? "" : "&status=eq.published";
  const rows = await supabaseRequest<SupabaseProject[]>(`projects?select=*&order=updated_at.desc${filter}`);
  return rows.map(mapProject);
}
export async function createProject(input: ManagedProjectInput) { await supabaseRequest("projects", { method: "POST", body: JSON.stringify({ title: input.title, slug: input.slug, category: input.category, summary: input.summary, image_url: input.imageUrl ?? null, status: input.status }) }); }
export async function updateProject(id: number, input: ManagedProjectInput) { await supabaseRequest(`projects?id=eq.${id}`, { method: "PATCH", body: JSON.stringify({ title: input.title, slug: input.slug, category: input.category, summary: input.summary, image_url: input.imageUrl ?? null, status: input.status, updated_at: new Date().toISOString() }) }); }
export async function deleteProject(id: number) { await supabaseRequest(`projects?id=eq.${id}`, { method: "DELETE" }); }

export type ManagedCaseStudyInput = { slug: string; eyebrow: string; title: string; summary: string; heroImage?: string | null; scope: string; process: string; evidenceNote: string; status: "draft" | "published" };
export async function listCaseStudies(includeDrafts = false) {
  const filter = includeDrafts ? "" : "&status=eq.published";
  const rows = await supabaseRequest<SupabaseCaseStudy[]>(`case_studies?select=*&order=updated_at.desc${filter}`);
  return rows.map(mapCaseStudy);
}
export async function createCaseStudy(input: ManagedCaseStudyInput) { await supabaseRequest("case_studies", { method: "POST", body: JSON.stringify({ slug: input.slug, eyebrow: input.eyebrow, title: input.title, summary: input.summary, hero_image: input.heroImage ?? null, scope: input.scope, process: input.process, evidence_note: input.evidenceNote, status: input.status }) }); }
export async function updateCaseStudy(id: number, input: ManagedCaseStudyInput) { await supabaseRequest(`case_studies?id=eq.${id}`, { method: "PATCH", body: JSON.stringify({ slug: input.slug, eyebrow: input.eyebrow, title: input.title, summary: input.summary, hero_image: input.heroImage ?? null, scope: input.scope, process: input.process, evidence_note: input.evidenceNote, status: input.status, updated_at: new Date().toISOString() }) }); }
export async function deleteCaseStudy(id: number) { await supabaseRequest(`case_studies?id=eq.${id}`, { method: "DELETE" }); }

export type ManagedSiteDetailInput = { section: string; detailKey: string; label: string; value: string };
export async function listSiteDetails() {
  const rows = await supabaseRequest<SupabaseSiteDetail[]>("site_details?select=*&order=section.asc,detail_key.asc");
  return rows.map(mapSiteDetail);
}
export async function createSiteDetail(input: ManagedSiteDetailInput) { await supabaseRequest("site_details", { method: "POST", body: JSON.stringify({ section: input.section, detail_key: input.detailKey, label: input.label, value: input.value }) }); }
export async function updateSiteDetail(id: number, input: ManagedSiteDetailInput) { await supabaseRequest(`site_details?id=eq.${id}`, { method: "PATCH", body: JSON.stringify({ section: input.section, detail_key: input.detailKey, label: input.label, value: input.value, updated_at: new Date().toISOString() }) }); }
export async function deleteSiteDetail(id: number) { await supabaseRequest(`site_details?id=eq.${id}`, { method: "DELETE" }); }
