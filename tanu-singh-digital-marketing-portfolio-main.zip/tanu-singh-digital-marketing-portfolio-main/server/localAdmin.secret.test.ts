import { describe, expect, it } from "vitest";
import { TRPCError } from "@trpc/server";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { LOCAL_ADMIN_COOKIE } from "./localAdmin";

describe("local admin credential endpoint", () => {
  it("accepts the configured server-side credentials and returns a secure local session cookie", async () => {
    const cookies: Array<{ name: string; value: string; options: Record<string, unknown> }> = [];
    const ctx: TrpcContext = {
      user: null,
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: { cookie: (name: string, value: string, options: Record<string, unknown>) => cookies.push({ name, value, options }) } as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);
    const result = await caller.localAdmin.login({ username: "seotanusingh", password: process.env.ADMIN_PASSWORD! });

    expect(result).toEqual({ success: true });
    expect(cookies[0]?.name).toBe(LOCAL_ADMIN_COOKIE);
    expect(cookies[0]?.options).toMatchObject({ httpOnly: true, sameSite: "none", secure: true });
  });

  it("rejects an invalid password without issuing an administrator cookie", async () => {
    const cookies: Array<{ name: string; value: string; options: Record<string, unknown> }> = [];
    const ctx: TrpcContext = {
      user: null,
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: { cookie: (name: string, value: string, options: Record<string, unknown>) => cookies.push({ name, value, options }) } as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);

    await expect(caller.localAdmin.login({ username: "seotanusingh", password: "not-the-password" }))
      .rejects.toMatchObject<Partial<TRPCError>>({ code: "UNAUTHORIZED" });
    expect(cookies).toHaveLength(0);
  });
});
