import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  createCaseStudy,
  createConsultationSubmission,
  createProject,
  createSiteDetail,
  deleteCaseStudy,
  deleteConsultationRequest,
  deleteLead,
  deleteProject,
  deleteSiteDetail,
  listCaseStudies,
  listConsultationRequests,
  listLeads,
  listProjects,
  listSiteDetails,
  updateCaseStudy,
  updateConsultationStatus,
  updateLeadStatus,
  updateProject,
  updateSiteDetail,
} from "./db";
import { getSessionCookieOptions } from "./_core/cookies";
import { clearLocalAdminSession, isValidLocalAdminCredential, startLocalAdminSession } from "./localAdmin";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";

const optionalString = z.string().trim().max(10_000).optional();
const filtersInput = z.object({
  search: z.string().trim().max(160).optional(),
  startDate: z.number().int().nonnegative().optional(),
  endDate: z.number().int().nonnegative().optional(),
}).optional();

const projectInput = z.object({
  title: z.string().trim().min(2).max(240),
  slug: z.string().trim().regex(/^[a-z0-9-]+$/).max(180),
  category: z.string().trim().min(2).max(120),
  summary: z.string().trim().min(8).max(10_000),
  imageUrl: optionalString,
  status: z.enum(["draft", "published"]),
});

const caseStudyInput = z.object({
  slug: z.string().trim().regex(/^[a-z0-9-]+$/).max(180),
  eyebrow: z.string().trim().min(2).max(220),
  title: z.string().trim().min(2).max(280),
  summary: z.string().trim().min(8).max(10_000),
  heroImage: optionalString,
  scope: z.string().trim().min(2).max(20_000),
  process: z.string().trim().min(2).max(20_000),
  evidenceNote: z.string().trim().min(2).max(10_000),
  status: z.enum(["draft", "published"]),
});

const siteDetailInput = z.object({
  section: z.string().trim().min(2).max(120),
  detailKey: z.string().trim().regex(/^[a-z0-9-]+$/).max(160),
  label: z.string().trim().min(2).max(200),
  value: z.string().trim().min(1).max(20_000),
});

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      clearLocalAdminSession(ctx.req, ctx.res);
      return {
        success: true,
      } as const;
    }),
  }),
  localAdmin: router({
    login: publicProcedure.input(z.object({
      username: z.string().trim().min(1).max(160),
      password: z.string().min(1).max(512),
    })).mutation(async ({ input, ctx }) => {
      if (!isValidLocalAdminCredential(input.username, input.password)) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid administrator credentials" });
      }
      await startLocalAdminSession(ctx.req, ctx.res);
      return { success: true } as const;
    }),
  }),
  consultation: router({
    submit: publicProcedure.input(z.object({
      name: z.string().trim().min(2).max(160),
      email: z.string().trim().email().max(320),
      business: z.string().trim().min(2).max(240),
      service: z.string().trim().min(2).max(160),
      stage: z.string().trim().min(2).max(160),
      goal: z.string().trim().min(2).max(10_000),
      budget: z.string().trim().min(2).max(120),
      timeline: z.string().trim().min(2).max(120),
      requirements: z.string().trim().min(2).max(20_000),
      website: z.string().max(0).optional(),
    })).mutation(async ({ input }) => {
      if (input.website) return { accepted: true };
      await createConsultationSubmission(input);
      return { accepted: true };
    }),
  }),
  publicContent: router({
    projects: publicProcedure.query(() => listProjects(false)),
    caseStudies: publicProcedure.query(() => listCaseStudies(false)),
    siteDetails: publicProcedure.query(() => listSiteDetails()),
  }),
  admin: router({
    leads: adminProcedure.input(filtersInput).query(({ input }) => listLeads(input ?? {})),
    consultationRequests: adminProcedure.input(filtersInput).query(({ input }) => listConsultationRequests(input ?? {})),
    updateLeadStatus: adminProcedure.input(z.object({ id: z.number().int().positive(), status: z.enum(["new", "contacted", "qualified", "archived"]) })).mutation(({ input }) => updateLeadStatus(input.id, input.status)),
    updateConsultationStatus: adminProcedure.input(z.object({ id: z.number().int().positive(), status: z.enum(["new", "reviewing", "scheduled", "closed"]) })).mutation(({ input }) => updateConsultationStatus(input.id, input.status)),
    deleteLead: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ input }) => deleteLead(input.id)),
    deleteConsultationRequest: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ input }) => deleteConsultationRequest(input.id)),
    projects: adminProcedure.query(() => listProjects(true)),
    createProject: adminProcedure.input(projectInput).mutation(({ input }) => createProject(input)),
    updateProject: adminProcedure.input(z.object({ id: z.number().int().positive(), data: projectInput })).mutation(({ input }) => updateProject(input.id, input.data)),
    deleteProject: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ input }) => deleteProject(input.id)),
    caseStudies: adminProcedure.query(() => listCaseStudies(true)),
    createCaseStudy: adminProcedure.input(caseStudyInput).mutation(({ input }) => createCaseStudy(input)),
    updateCaseStudy: adminProcedure.input(z.object({ id: z.number().int().positive(), data: caseStudyInput })).mutation(({ input }) => updateCaseStudy(input.id, input.data)),
    deleteCaseStudy: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ input }) => deleteCaseStudy(input.id)),
    siteDetails: adminProcedure.query(() => listSiteDetails()),
    createSiteDetail: adminProcedure.input(siteDetailInput).mutation(({ input }) => createSiteDetail(input)),
    updateSiteDetail: adminProcedure.input(z.object({ id: z.number().int().positive(), data: siteDetailInput })).mutation(({ input }) => updateSiteDetail(input.id, input.data)),
    deleteSiteDetail: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ input }) => deleteSiteDetail(input.id)),
  }),
});

export type AppRouter = typeof appRouter;
