import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createContext(role: "admin" | "user" | null): TrpcContext {
  return {
    user: role
      ? {
          id: 1,
          openId: "test-user",
          name: "Test User",
          email: "test@example.com",
          loginMethod: "manus",
          role,
          createdAt: new Date(),
          updatedAt: new Date(),
          lastSignedIn: new Date(),
        }
      : null,
    req: {} as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("admin dashboard security", () => {
  it("rejects dashboard data access for a signed-in non-admin user", async () => {
    const caller = appRouter.createCaller(createContext("user"));
    await expect(caller.admin.leads()).rejects.toMatchObject({
      code: "FORBIDDEN",
      message: "You do not have required permission (10002)",
    });
  });

  it("rejects malformed public consultation submissions before database persistence", async () => {
    const caller = appRouter.createCaller(createContext(null));
    await expect(caller.consultation.submit({
      name: "T",
      email: "not-an-email",
      business: "",
      service: "SEO",
      stage: "Idea",
      goal: "Grow",
      budget: "₹25,000",
      timeline: "1 month",
      requirements: "Help",
    })).rejects.toBeDefined();
  });
});
