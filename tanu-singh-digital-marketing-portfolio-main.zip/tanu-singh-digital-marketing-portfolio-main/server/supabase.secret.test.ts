import { describe, expect, it } from "vitest";

const supabaseUrl = "https://rglfqxunnmlwpbdyhdtq.supabase.co";

describe("Supabase server credential", () => {
  it("authenticates a lightweight read of the protected leads table", async () => {
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    expect(serviceRoleKey).toBeTruthy();

    const response = await fetch(`${supabaseUrl}/rest/v1/leads?select=id&limit=1`, {
      headers: {
        apikey: serviceRoleKey!,
        Authorization: `Bearer ${serviceRoleKey!}`,
      },
    });

    expect(response.status).toBe(200);
  }, 15_000);
});
