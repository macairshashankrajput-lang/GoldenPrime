import { timingSafeEqual } from "node:crypto";
import { parse } from "cookie";
import { SignJWT, jwtVerify } from "jose";
import type { Request, Response } from "express";
import type { User } from "../drizzle/schema";
import { getSessionCookieOptions } from "./_core/cookies";

export const LOCAL_ADMIN_COOKIE = "tanu_local_admin";
const LOCAL_ADMIN_SESSION_MS = 1000 * 60 * 60 * 8;

function signingKey() {
  const key = process.env.JWT_SECRET;
  if (!key) throw new Error("JWT_SECRET is not configured");
  return new TextEncoder().encode(key);
}

function safeEquals(actual: string, expected: string) {
  const actualBuffer = Buffer.from(actual);
  const expectedBuffer = Buffer.from(expected);
  return actualBuffer.length === expectedBuffer.length && timingSafeEqual(actualBuffer, expectedBuffer);
}

export function isValidLocalAdminCredential(username: string, password: string) {
  const expectedUsername = process.env.ADMIN_USERNAME;
  const expectedPassword = process.env.ADMIN_PASSWORD;
  if (!expectedUsername || !expectedPassword) return false;
  return safeEquals(username, expectedUsername) && safeEquals(password, expectedPassword);
}

export async function startLocalAdminSession(req: Request, res: Response) {
  const token = await new SignJWT({ role: "admin", loginMethod: "local" })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject("local-admin")
    .setIssuedAt()
    .setExpirationTime("8h")
    .sign(signingKey());

  res.cookie(LOCAL_ADMIN_COOKIE, token, {
    ...getSessionCookieOptions(req),
    maxAge: LOCAL_ADMIN_SESSION_MS,
  });
}

export function clearLocalAdminSession(req: Request, res: Response) {
  res.clearCookie(LOCAL_ADMIN_COOKIE, { ...getSessionCookieOptions(req), maxAge: -1 });
}

export async function getLocalAdminUser(req: Request): Promise<User | null> {
  const cookieHeader = req.headers.cookie;
  if (!cookieHeader) return null;
  const token = parse(cookieHeader)[LOCAL_ADMIN_COOKIE];
  if (!token) return null;

  try {
    const { payload } = await jwtVerify(token, signingKey());
    if (payload.sub !== "local-admin" || payload.role !== "admin") return null;
    const issuedAt = (payload.iat ?? Math.floor(Date.now() / 1000)) * 1000;
    return {
      id: 0,
      openId: "local-admin",
      name: "Portfolio Administrator",
      email: null,
      loginMethod: "local",
      role: "admin",
      createdAt: new Date(issuedAt),
      updatedAt: new Date(),
      lastSignedIn: new Date(issuedAt),
    };
  } catch {
    return null;
  }
}
