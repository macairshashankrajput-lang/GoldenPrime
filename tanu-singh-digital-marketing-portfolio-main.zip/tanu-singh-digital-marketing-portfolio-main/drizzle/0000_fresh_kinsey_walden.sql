CREATE TABLE `case_studies` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(180) NOT NULL,
	`eyebrow` varchar(220) NOT NULL,
	`title` varchar(280) NOT NULL,
	`summary` text NOT NULL,
	`heroImage` text,
	`scope` text NOT NULL,
	`process` text NOT NULL,
	`evidenceNote` text NOT NULL,
	`status` enum('draft','published') NOT NULL DEFAULT 'draft',
	`createdAt` bigint NOT NULL,
	`updatedAt` bigint NOT NULL,
	CONSTRAINT `case_studies_id` PRIMARY KEY(`id`),
	CONSTRAINT `case_studies_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `consultation_requests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`leadId` int NOT NULL,
	`service` varchar(160) NOT NULL,
	`stage` varchar(160) NOT NULL,
	`goal` text NOT NULL,
	`budget` varchar(120) NOT NULL,
	`timeline` varchar(120) NOT NULL,
	`requirements` text NOT NULL,
	`status` enum('new','reviewing','scheduled','closed') NOT NULL DEFAULT 'new',
	`createdAt` bigint NOT NULL,
	`updatedAt` bigint NOT NULL,
	CONSTRAINT `consultation_requests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `leads` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(160) NOT NULL,
	`email` varchar(320) NOT NULL,
	`business` varchar(240) NOT NULL,
	`source` varchar(80) NOT NULL DEFAULT 'portfolio',
	`status` enum('new','contacted','qualified','archived') NOT NULL DEFAULT 'new',
	`createdAt` bigint NOT NULL,
	`updatedAt` bigint NOT NULL,
	CONSTRAINT `leads_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `projects` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(240) NOT NULL,
	`slug` varchar(180) NOT NULL,
	`category` varchar(120) NOT NULL,
	`summary` text NOT NULL,
	`imageUrl` text,
	`status` enum('draft','published') NOT NULL DEFAULT 'draft',
	`createdAt` bigint NOT NULL,
	`updatedAt` bigint NOT NULL,
	CONSTRAINT `projects_id` PRIMARY KEY(`id`),
	CONSTRAINT `projects_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `site_details` (
	`id` int AUTO_INCREMENT NOT NULL,
	`section` varchar(120) NOT NULL,
	`detailKey` varchar(160) NOT NULL,
	`label` varchar(200) NOT NULL,
	`value` text NOT NULL,
	`updatedAt` bigint NOT NULL,
	CONSTRAINT `site_details_id` PRIMARY KEY(`id`),
	CONSTRAINT `site_details_detailKey_unique` UNIQUE(`detailKey`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
