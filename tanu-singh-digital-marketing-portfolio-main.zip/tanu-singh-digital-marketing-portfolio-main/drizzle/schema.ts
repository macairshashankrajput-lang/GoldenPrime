import { bigint, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const leads = mysqlTable("leads", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  business: varchar("business", { length: 240 }).notNull(),
  source: varchar("source", { length: 80 }).notNull().default("portfolio"),
  status: mysqlEnum("status", ["new", "contacted", "qualified", "archived"]).notNull().default("new"),
  createdAt: bigint("createdAt", { mode: "number" }).notNull(),
  updatedAt: bigint("updatedAt", { mode: "number" }).notNull(),
});

export const consultationRequests = mysqlTable("consultation_requests", {
  id: int("id").autoincrement().primaryKey(),
  leadId: int("leadId").notNull(),
  service: varchar("service", { length: 160 }).notNull(),
  stage: varchar("stage", { length: 160 }).notNull(),
  goal: text("goal").notNull(),
  budget: varchar("budget", { length: 120 }).notNull(),
  timeline: varchar("timeline", { length: 120 }).notNull(),
  requirements: text("requirements").notNull(),
  status: mysqlEnum("status", ["new", "reviewing", "scheduled", "closed"]).notNull().default("new"),
  createdAt: bigint("createdAt", { mode: "number" }).notNull(),
  updatedAt: bigint("updatedAt", { mode: "number" }).notNull(),
});

export const projects = mysqlTable("projects", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 240 }).notNull(),
  slug: varchar("slug", { length: 180 }).notNull().unique(),
  category: varchar("category", { length: 120 }).notNull(),
  summary: text("summary").notNull(),
  imageUrl: text("imageUrl"),
  status: mysqlEnum("status", ["draft", "published"]).notNull().default("draft"),
  createdAt: bigint("createdAt", { mode: "number" }).notNull(),
  updatedAt: bigint("updatedAt", { mode: "number" }).notNull(),
});

export const caseStudies = mysqlTable("case_studies", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 180 }).notNull().unique(),
  eyebrow: varchar("eyebrow", { length: 220 }).notNull(),
  title: varchar("title", { length: 280 }).notNull(),
  summary: text("summary").notNull(),
  heroImage: text("heroImage"),
  scope: text("scope").notNull(),
  process: text("process").notNull(),
  evidenceNote: text("evidenceNote").notNull(),
  status: mysqlEnum("status", ["draft", "published"]).notNull().default("draft"),
  createdAt: bigint("createdAt", { mode: "number" }).notNull(),
  updatedAt: bigint("updatedAt", { mode: "number" }).notNull(),
});

export const siteDetails = mysqlTable("site_details", {
  id: int("id").autoincrement().primaryKey(),
  section: varchar("section", { length: 120 }).notNull(),
  detailKey: varchar("detailKey", { length: 160 }).notNull().unique(),
  label: varchar("label", { length: 200 }).notNull(),
  value: text("value").notNull(),
  updatedAt: bigint("updatedAt", { mode: "number" }).notNull(),
});

export type Lead = typeof leads.$inferSelect;
export type ConsultationRequest = typeof consultationRequests.$inferSelect;
export type Project = typeof projects.$inferSelect;
export type CaseStudy = typeof caseStudies.$inferSelect;
export type SiteDetail = typeof siteDetails.$inferSelect;
