# Verified Portfolio Details

## Current professional focus

Tanu Singh is an SEO Executive at Growth Zone in Noida as of February 2026. Her background also includes SEO work at Margaux Tech, digital marketing experience at SkillCircle, and earlier training experience at NSPL.

## Relevant practical work

* **V-Trims Design SEO project:** keyword-focused work and blog-related SEO activity for [vtrimsdesign.com](https://vtrimsdesign.com/).
* **GlobeFares website project:** a client demo website deployed with Vercel, with GitHub and Canva used in the workflow.

## Tools and skill areas

SEO research and on-page principles, WordPress, Rank Math SEO, Canva, CapCut, Google Ads, Google Workspace, GitHub, Vercel, Supabase, content writing, social media marketing, analysis, and basic web development.

## Qualifications highlighted in the supplied documents

Digital Marketing and SEO training through SkillCircle and UPSDM; Google Ads and ecommerce training; LinkedIn Content and Creative Design certification; MA from KDC in 2023 and BA from RMLAU in 2019.

## Contact and service integration

The user’s preferred public contact email remains **seo.tanusingh@gmail.com** and the supplied LinkedIn profile is **linkedin.com/in/tanusinghchauhan**.

The supplied Google Form URL redirected to a Google sign-in screen in the portfolio browser on 23 August 2026, so it is not currently accessible as a public no-login enquiry form. It needs to be published for anyone with the link before it can be embedded or linked as a direct public contact channel.
